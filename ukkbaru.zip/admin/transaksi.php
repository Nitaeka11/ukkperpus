<?php
/* =========================================================
   TRANSAKSI.PHP — Data Transaksi, Pencarian, Filter & Tambah Manual
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);

// Proses Tambah Peminjaman Manual
if (isset($_POST['tambah_pinjam'])) {
    $id_anggota      = (int)$_POST['id_anggota'];
    $id_buku         = (int)$_POST['id_buku'];
    $tgl_pinjam      = $_POST['tgl_pinjam'];
    $tgl_hrs_kembali = $_POST['tgl_hrs_kembali'];

    $stmt_ins = mysqli_prepare($conn, "INSERT INTO peminjaman (id_anggota, id_buku, tgl_pinjam, tgl_hrs_kembali, status) VALUES (?, ?, ?, ?, 'Dipinjam')");
    mysqli_stmt_bind_param($stmt_ins, "iiss", $id_anggota, $id_buku, $tgl_pinjam, $tgl_hrs_kembali);
    
    if (mysqli_stmt_execute($stmt_ins)) {
        $_SESSION['pesan'] = "Transaksi peminjaman manual berhasil ditambahkan!";
        $_SESSION['pesan_tipe'] = "success";
    } else {
        $_SESSION['pesan'] = "Gagal menambahkan transaksi.";
        $_SESSION['pesan_tipe'] = "danger";
    }
    header("location: transaksi.php");
    exit();
}

// Logika Pencarian & Filter
$search = mysqli_real_escape_string($conn, $_GET['search'] ?? '');
$status_filter = mysqli_real_escape_string($conn, $_GET['status'] ?? '');

$query = "SELECT p.*, b.judul_buku, b.kode_buku, a.nama_lengkap AS nama_anggota 
          FROM peminjaman p 
          JOIN buku b ON p.id_buku = b.id_buku 
          JOIN anggota a ON p.id_anggota = a.id_anggota 
          WHERE 1=1";

if (!empty($search)) {
    $query .= " AND (a.nama_lengkap LIKE '%$search%' OR b.judul_buku LIKE '%$search%')";
}

if (!empty($status_filter)) {
    $query .= " AND p.status = '$status_filter'";
}

$query .= " ORDER BY p.id_peminjaman DESC";
$result = mysqli_query($conn, $query);

// Ambil data untuk opsi select di Modal Tambah
$data_anggota = mysqli_query($conn, "SELECT id_anggota, nama_lengkap FROM anggota ORDER BY nama_lengkap ASC");
$data_buku = mysqli_query($conn, "SELECT id_buku, judul_buku, stok FROM buku WHERE stok > 0 ORDER BY judul_buku ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Transaksi Peminjaman - Admin Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-bg: #121629;
            --primary-color: #4f46e5;
            --bg-body: #f4f5f7;
        }
        body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; padding-top: 20px; }
        .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
        .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
        .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
        .sidebar a:hover, .sidebar a.active { color: #fff; background: var(--primary-color); }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.03); border-radius: 15px; }
    </style>
</head>
<body>

    <!-- SIDEBAR ADMIN -->
    <div class="sidebar">
        <div>
            <h4><i class="fa-solid fa-shield-halved text-warning"></i> Admin Panel</h4>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
                <a href="buku.php" class="<?= $current_page == 'buku.php' ? 'active' : '' ?>"><i class="fas fa-book"></i> Data Buku</a>
                <a href="anggota.php" class="<?= $current_page == 'anggota.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> Data Anggota</a>
                <a href="petugas.php" class="<?= $current_page == 'petugas.php' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Data Petugas</a>
                <a href="transaksi.php" class="<?= $current_page == 'transaksi.php' ? 'active' : '' ?>"><i class="fas fa-exchange-alt"></i> Transaksi</a>
                <a href="denda.php" class="<?= $current_page == 'denda.php' ? 'active' : '' ?>"><i class="fas fa-money-bill-wave"></i> Manajemen Denda</a>
                <a href="notifikasi.php" class="<?= $current_page == 'notifikasi.php' ? 'active' : '' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
                <a href="laporan.php" class="<?= $current_page == 'laporan.php' ? 'active' : '' ?>"><i class="fas fa-file-alt"></i> Laporan</a>
            </div>
        </div>
        <div class="sidebar-footer">
            <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Data Transaksi Peminjaman Buku</h3>
                    <p class="text-muted mb-0">Kelola dan pantau seluruh aktivitas peminjaman serta pengembalian buku siswa.</p>
                </div>
                <button class="btn btn-primary fw-bold px-3 py-2" data-bs-toggle="modal" data-bs-target="#modalTambahPinjam">
                    <i class="fa-solid fa-plus me-2"></i> Tambah Peminjaman
                </button>
            </div>

            <?php if (isset($_SESSION['pesan'])): ?>
                <div class="alert alert-<?= $_SESSION['pesan_tipe'] == 'success' ? 'success' : 'danger' ?> alert-dismissible fade show">
                    <?= htmlspecialchars($_SESSION['pesan']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['pesan'], $_SESSION['pesan_tipe']); ?>
            <?php endif; ?>

            <!-- FORM PENCARIAN & FILTER -->
            <div class="card p-3 mb-4">
                <form method="GET" action="" class="row g-3 align-items-center">
                    <div class="col-md-6">
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-search text-muted"></i></span>
                            <input type="text" class="form-control border-start-0" name="search" placeholder="Cari nama siswa atau judul buku..." value="<?= htmlspecialchars($search) ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <select name="status" class="form-select">
                            <option value="">-- Semua Status --</option>
                            <option value="Dipinjam" <?= $status_filter == 'Dipinjam' ? 'selected' : '' ?>>Dipinjam</option>
                            <option value="Dikembalikan" <?= $status_filter == 'Dikembalikan' ? 'selected' : '' ?>>Dikembalikan</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-dark w-100">Filter</button>
                        <a href="transaksi.php" class="btn btn-outline-secondary" title="Reset"><i class="fa-solid fa-rotate"></i></a>
                    </div>
                </form>
            </div>

            <!-- TABEL TRANSAKSI -->
            <div class="card p-4">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Nama Peminjam</th>
                                <th>Judul Buku</th>
                                <th>Tgl Pinjam</th>
                                <th>Jatuh Tempo</th>
                                <th>Tgl Kembali</th>
                                <th>Status</th>
                                <th>Denda</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                                <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><strong><?= htmlspecialchars($row['nama_anggota']) ?></strong></td>
                                    <td><?= htmlspecialchars($row['judul_buku']) ?> <br><small class="text-muted">Kode: <?= htmlspecialchars($row['kode_buku']) ?></small></td>
                                    <td><?= htmlspecialchars($row['tgl_pinjam']) ?></td>
                                    <td><?= htmlspecialchars($row['tgl_hrs_kembali'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($row['tanggal_dikembalikan'] ?? '-') ?></td>
                                    <td>
                                        <?php if ($row['status'] == 'Dipinjam'): ?>
                                            <span class="badge bg-primary">Dipinjam</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Dikembalikan</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($row['total_denda']) && (float)$row['total_denda'] > 0): ?>
                                            <span class="text-danger fw-bold">Rp <?= number_format((float)$row['total_denda'], 0, ',', '.') ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">Tidak ada data transaksi yang ditemukan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL TAMBAH PEMINJAMAN MANUAL -->
    <div class="modal fade" id="modalTambahPinjam" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold">Tambah Peminjaman Buku</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Pilih Anggota / Siswa</label>
                            <select name="id_anggota" class="form-select" required>
                                <option value="">-- Pilih Siswa --</option>
                                <?php while ($a = mysqli_fetch_assoc($data_anggota)): ?>
                                    <option value="<?= $a['id_anggota'] ?>"><?= htmlspecialchars($a['nama_lengkap']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Pilih Buku</label>
                            <select name="id_buku" class="form-select" required>
                                <option value="">-- Pilih Buku Tersedia --</option>
                                <?php while ($b = mysqli_fetch_assoc($data_buku)): ?>
                                    <option value="<?= $b['id_buku'] ?>"><?= htmlspecialchars($b['judul_buku']) ?> (Stok: <?= $b['stok'] ?>)</option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tanggal Pinjam</label>
                            <input type="date" name="tgl_pinjam" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tanggal Batas Tempo (Jatuh Tempo)</label>
                            <input type="date" name="tgl_hrs_kembali" class="form-control" value="<?= date('Y-m-d', strtotime('+7 days')) ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="tambah_pinjam" class="btn btn-primary">Simpan Transaksi</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>