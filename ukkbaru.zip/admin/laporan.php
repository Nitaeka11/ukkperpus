<?php
/* =========================================================
   LAPORAN.PHP — Pusat Laporan Eksekutif (Admin)
   FIX: Tampilkan SEMUA transaksi (Dipinjam + Dikembalikan)
   Query: LEFT JOIN + tanpa filter status, supaya data
   yang tanggal_dikembalikan-nya terisi tapi status-nya
   NULL tetap muncul di tabel.
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

// --- Statistik utama ---
$total_buku    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM buku"))['jml'] ?? 0;
$total_anggota = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM anggota"))['jml'] ?? 0;
$sedang_dipinjam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM peminjaman WHERE status = 'Dipinjam'"))['jml'] ?? 0;
$telah_dikembalikan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS jml FROM peminjaman WHERE tanggal_dikembalikan IS NOT NULL"))['jml'] ?? 0;

// --- Data rinci transaksi peminjaman (SEMUA DATA) ---
// LEFT JOIN: biar data nggak hilang kalau anggota/buku terhapus
$data_transaksi = mysqli_query($conn, "
    SELECT p.id_peminjaman, p.status, p.tgl_pinjam, p.tanggal_dikembalikan,
           a.nama_lengkap, a.kode_anggota,
           b.kode_buku, b.judul_buku
    FROM peminjaman p
    LEFT JOIN anggota a ON p.id_anggota = a.id_anggota
    LEFT JOIN buku b ON p.id_buku = b.id_buku
    ORDER BY p.id_peminjaman DESC
");

$current_page = basename($_SERVER['PHP_SELF']);

$tanggal_cetak = date('d F Y');
$bulan_indo = ['January'=>'Januari','February'=>'Februari','March'=>'Maret','April'=>'April','May'=>'Mei','June'=>'Juni','July'=>'Juli','August'=>'Agustus','September'=>'September','October'=>'Oktober','November'=>'November','December'=>'Desember'];
foreach ($bulan_indo as $en => $id) { $tanggal_cetak = str_replace($en, $id, $tanggal_cetak); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Laporan Kepala Sekolah - SMP Negeri 2 Sanden</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #f1f5f9; font-family: 'Inter', 'Segoe UI', Arial, sans-serif; }

  /* ========== SIDEBAR (seragam di semua halaman admin) ========== */
  .sidebar {
    position: fixed;
    top: 0; left: 0;
    width: 260px;
    height: 100vh;
    background-color: #121629;
    color: #fff;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    z-index: 1000;
    padding-top: 20px;
    overflow-y: auto;
  }
  .sidebar h4 {
    color: #fff;
    text-align: center;
    font-weight: bold;
    margin-bottom: 30px;
    font-size: 1.1rem;
    padding: 0 15px;
  }
  .sidebar-menu {
    padding: 0 15px;
    flex-grow: 1;
    list-style: none;
    margin: 0;
  }
  .sidebar a {
    padding: 12px 15px;
    text-decoration: none;
    font-size: 15px;
    color: #94a3b8;
    display: flex;
    align-items: center;
    gap: 12px;
    transition: 0.3s;
    border-radius: 10px;
    margin-bottom: 5px;
    font-weight: 500;
  }
  .sidebar a:hover, .sidebar a.active {
    color: #fff;
    background: #4f46e5;
  }

  .sidebar-footer {
    padding: 20px;
    border-top: 1px solid rgba(255,255,255,0.06);
  }
  .sidebar-footer a {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #94a3b8;
    text-decoration: none;
    font-weight: 500;
    font-size: 15px;
    padding: 10px 15px;
    border-radius: 10px;
    transition: all 0.2s;
  }
  .sidebar-footer a:hover { background: rgba(239,68,68,0.12); color: #ef4444; }

  /* ========== MAIN CONTENT ========== */
  .main-content {
    margin-left: 260px;
    min-height: 100vh;
    padding: 30px 32px;
  }

  /* Top bar */
  .top-card {
    background: #fff;
    border-radius: 16px;
    padding: 22px 28px;
    box-shadow: 0 4px 20px rgba(0,0,0,.04);
    margin-bottom: 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 14px;
  }
  .top-card h3 { font-weight: 800; margin-bottom: 4px; color: #0f172a; }
  .top-card p { color: #64748b; margin: 0; font-size: 0.95rem; }

  .btn-cetak {
    background: #2563eb; color: #fff; border: none;
    padding: 10px 20px; border-radius: 10px;
    font-weight: 600; font-size: 0.9rem;
    display: inline-flex; align-items: center; gap: 8px;
    transition: all 0.2s;
  }
  .btn-cetak:hover { background: #1d4ed8; transform: translateY(-1px); }
  .btn-dash {
    background: #fff; border: 1px solid #e2e8f0;
    padding: 10px 20px; border-radius: 10px;
    font-weight: 600; font-size: 0.9rem;
    text-decoration: none; color: #334155;
    display: inline-flex; align-items: center; gap: 8px;
    transition: all 0.2s;
  }
  .btn-dash:hover { background: #f8fafc; border-color: #cbd5e1; }

  /* Content card */
  .content-card {
    background: #fff;
    border-radius: 16px;
    padding: 32px 36px;
    box-shadow: 0 4px 20px rgba(0,0,0,.04);
  }
  .badge-judul {
    background: #4f46e5; color: #fff;
    padding: 6px 18px; border-radius: 20px;
    font-size: 12px; font-weight: 700; letter-spacing: .03em;
    display: inline-block;
  }
  .judul-utama { text-align: center; font-weight: 800; font-size: 1.65rem; margin: 16px 0 4px; color: #0f172a; }
  .sub-judul { text-align: center; color: #64748b; margin-bottom: 28px; font-size: 0.95rem; }

  /* Statistik */
  .stat-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-bottom: 32px;
  }
  .stat-box {
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 20px 22px;
    background: #fff;
    transition: transform 0.2s, box-shadow 0.2s;
  }
  .stat-box:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.06); }
  .stat-box .label { font-size: 13px; color: #475569; display: flex; align-items: center; gap: 8px; margin-bottom: 10px; font-weight: 500; }
  .stat-box .value { font-size: 28px; font-weight: 800; color: #0f172a; }

  /* Tabel */
  .section-title { font-weight: 700; font-size: 1.05rem; color: #0f172a; margin-bottom: 16px; display: flex; align-items: center; gap: 10px; }
  table.laporan-table { width: 100%; border-collapse: collapse; }
  table.laporan-table thead th {
    background: #0f172a; color: #fff;
    padding: 14px 16px; font-size: 12px;
    text-transform: uppercase; text-align: left;
    font-weight: 600; letter-spacing: 0.3px;
  }
  table.laporan-table tbody td {
    padding: 14px 16px; font-size: 13.5px;
    border-bottom: 1px solid #f1f5f9; color: #334155;
    vertical-align: middle;
  }
  table.laporan-table tbody tr:nth-child(even) { background: #f8fafc; }
  table.laporan-table tbody tr:hover { background: #f1f5f9; }

  .badge-status { padding: 5px 14px; border-radius: 20px; font-size: 11.5px; font-weight: 700; display: inline-block; }
  .badge-dipinjam { background: #dbeafe; color: #1d4ed8; }
  .badge-dikembalikan { background: #dcfce7; color: #15803d; }
  .badge-ditolak { background: #fee2e2; color: #b91c1c; }
  .badge-menunggu { background: #fef3c7; color: #b45309; }

  /* Footer */
  .info-validasi {
    background: #f8fafc; border: 1px solid #e2e8f0;
    border-radius: 12px; padding: 18px 22px;
    font-size: 13px; color: #475569; line-height: 1.6;
  }
  .ttd-block { text-align: center; padding-top: 10px; }
  .ttd-block .jabatan { font-size: 0.95rem; color: #334155; margin-bottom: 4px; }
  .ttd-block .nama { font-weight: 800; text-decoration: underline; margin-top: 70px; margin-bottom: 2px; color: #0f172a; }
  .ttd-block .nip { font-size: 0.85rem; color: #64748b; }

  /* Print */
  @media print {
    .sidebar, .btn-cetak, .btn-dash, .no-print { display: none !important; }
    .main-content { margin-left: 0; padding: 20px; }
    .top-card, .content-card { box-shadow: none; border: 1px solid #e2e8f0; }
  }

  /* Responsive */
  @media (max-width: 1200px) {
    .stat-row { grid-template-columns: repeat(2, 1fr); }
  }
  @media (max-width: 768px) {
    .sidebar { width: 220px; }
    .main-content { margin-left: 220px; padding: 20px; }
    .stat-row { grid-template-columns: 1fr; }
  }
</style>
</head>
<body>

<!-- ==================== SIDEBAR ==================== -->
<div class="sidebar">
    <div>
        <h4><i class="fa-solid fa-shield-halved text-warning"></i> ADMIN PANEL</h4>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="buku.php" class="<?= $current_page == 'buku.php' ? 'active' : '' ?>"><i class="fas fa-book"></i> Data Buku</a>
            <a href="anggota.php" class="<?= $current_page == 'anggota.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> Data Anggota</a>
            <a href="petugas.php" class="<?= $current_page == 'petugas.php' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Data Petugas</a>
            <a href="transaksi.php" class="<?= $current_page == 'transaksi.php' ? 'active' : '' ?>"><i class="fas fa-exchange-alt"></i> Transaksi</a>
            <a href="denda.php" class="<?= $current_page == 'denda.php' ? 'active' : '' ?>"><i class="fas fa-money-bill-wave"></i> Manajemen Denda</a>
            <a href="notifikasi.php" class="<?= $current_page == 'notifikasi.php' ? 'active' : '' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
            <a href="laporan.php" class="<?= $current_page == 'laporan.php' ? 'active' : '' ?>"><i class="fas fa-file-alt"></i> Laporan</a>
        </div>
    </div>
    <div class="sidebar-footer">
        <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
        </a>
    </div>
</div>

<!-- ==================== MAIN CONTENT ==================== -->
<div class="main-content">

  <div class="top-card">
    <div>
      <h3>Pusat Laporan Eksekutif</h3>
      <p>Laporan Resmi Berkala untuk Kepala SMP Negeri 2 Sanden</p>
    </div>
    <div class="d-flex gap-2 no-print">
      <button class="btn-cetak" onclick="window.print()">
        <i class="fa-solid fa-print"></i> Cetak / Ekspor Berkas
      </button>
      <a href="dashboard.php" class="btn-dash">
        <i class="fa-solid fa-arrow-left"></i> Dashboard
      </a>
    </div>
  </div>

  <div class="content-card">
    <div class="text-center">
      <span class="badge-judul">LAPORAN AKUNTABILITAS PERPUSTAKAAN</span>
    </div>
    <div class="judul-utama">REKAPITULASI SIRKULASI &amp; ASET PERPUSTAKAAN</div>
    <div class="sub-judul">Kepada Yth. Kepala SMP Negeri 2 Sanden | Dicetak pada: <?= $tanggal_cetak ?></div>

    <!-- Statistik -->
    <div class="stat-row">
      <div class="stat-box">
        <div class="label"><i class="fa-solid fa-book text-primary"></i> Total Koleksi Buku</div>
        <div class="value"><?= $total_buku ?></div>
      </div>
      <div class="stat-box">
        <div class="label"><i class="fa-solid fa-users text-success"></i> Total Anggota Siswa</div>
        <div class="value"><?= $total_anggota ?></div>
      </div>
      <div class="stat-box">
        <div class="label"><i class="fa-solid fa-clock text-warning"></i> Sedang Dipinjam</div>
        <div class="value" style="color:#f59e0b;"><?= $sedang_dipinjam ?></div>
      </div>
      <div class="stat-box">
        <div class="label"><i class="fa-solid fa-circle-check text-info"></i> Telah Dikembalikan</div>
        <div class="value" style="color:#0891b2;"><?= $telah_dikembalikan ?></div>
      </div>
    </div>

    <!-- Tabel -->
    <div class="section-title">
      <i class="fa-solid fa-table text-primary"></i> Tabel Rincian Data Transaksi Peminjaman Buku
    </div>
    <div class="table-responsive mb-4">
      <table class="laporan-table">
        <thead>
          <tr>
            <th>No</th>
            <th>ID Peminjaman</th>
            <th>Anggota / Siswa</th>
            <th>Kode Buku</th>
            <th>Judul Buku</th>
            <th>Tanggal Peminjaman</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($data_transaksi && mysqli_num_rows($data_transaksi) > 0): $no = 1; ?>
            <?php while ($row = mysqli_fetch_assoc($data_transaksi)):
                // FIX: Kalau status kosong tapi tanggal_dikembalikan ada = Dikembalikan
                $status_raw = trim($row['status'] ?? '');
                $sudah_kembali = !empty($row['tanggal_dikembalikan']);

                if ($sudah_kembali && empty($status_raw)) {
                    $label = 'Dikembalikan';
                    $kelas = 'badge-dikembalikan';
                } else {
                    $kelas = [
                        'Dipinjam' => 'badge-dipinjam',
                        'Menunggu' => 'badge-menunggu',
                        'Ditolak' => 'badge-ditolak',
                    ][$status_raw] ?? 'badge-menunggu';
                    $label = $status_raw ?: 'Tidak Diketahui';
                }
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td class="fw-bold">#<?= $row['id_peminjaman'] ?></td>
                <td>
                  <?= htmlspecialchars($row['nama_lengkap'] ?? '-') ?>
                  <?php if (!empty($row['kode_anggota'])): ?>
                    <span class="text-muted small">(<?= htmlspecialchars($row['kode_anggota']) ?>)</span>
                  <?php endif; ?>
                </td>
                <td><?= htmlspecialchars($row['kode_buku'] ?? '-') ?></td>
                <td><?= htmlspecialchars($row['judul_buku'] ?? '-') ?></td>
                <td><?= !empty($row['tgl_pinjam']) ? date('d/m/Y', strtotime($row['tgl_pinjam'])) : '-' ?></td>
                <td><span class="badge-status <?= $kelas ?>"><?= htmlspecialchars($label) ?></span></td>
            </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="7" class="text-center py-4 text-muted">Tidak ada data transaksi peminjaman.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Footer Laporan -->
    <div class="row align-items-end">
      <div class="col-md-7">
        <div class="info-validasi">
          <i class="fa-solid fa-circle-info text-primary me-2"></i>
          <strong>Informasi Validasi Sistem:</strong><br>
          Laporan ini sah dan dihasilkan secara otomatis melalui modul sistem informasi perpustakaan digital SMP Negeri 2 Sanden, tanpa memerlukan tanda tangan basah/cap instansi untuk versi digital.
        </div>
      </div>
      <div class="col-md-5">
        <div class="ttd-block">
          <div class="text-muted mb-1">Sanden, <?= $tanggal_cetak ?></div>
          <div class="jabatan">Mengetahui,</div>
          <div class="fw-bold" style="color:#334155;">Kepala SMP Negeri 2 Sanden</div>
          <div class="nama">Drs. H. Kepala Sekolah, M.Pd.</div>
          <div class="nip">NIP. 19680512 199403 1 005</div>
        </div>
      </div>
    </div>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>