<?php
session_start();
$current_page = basename($_SERVER['PHP_SELF']);

// =========================================================
// KONEKSI DATABASE
// =========================================================
$host = "localhost";
$user = "root";
$pass = "";
$db   = "perpusku";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

$folder_cover = "uploads/"; // folder tempat simpan cover buku (admin/uploads)
if (!is_dir($folder_cover)) {
    mkdir($folder_cover, 0777, true);
}

$notif = "";
$notif_type = "success";

// =========================================================
// TAMBAH BUKU
// =========================================================
if (isset($_POST['tambah'])) {
    $kode_buku    = $_POST['kode_buku'];
    $isbn         = $_POST['isbn'];
    $judul_buku   = $_POST['judul_buku'];
    $id_kategori  = $_POST['id_kategori'];
    $pengarang    = $_POST['pengarang'];
    $penerbit     = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $rak          = $_POST['rak'];
    $lokasi_rak   = $_POST['lokasi_rak'];
    $stok         = intval($_POST['stok']);

    $id_cover = null;
    if (isset($_FILES['id_cover']) && $_FILES['id_cover']['error'] == 0) {
        $ext = pathinfo($_FILES['id_cover']['name'], PATHINFO_EXTENSION);
        $id_cover = uniqid() . "." . $ext;
        move_uploaded_file($_FILES['id_cover']['tmp_name'], $folder_cover . $id_cover);
    }

    $stmt = $conn->prepare("INSERT INTO buku (id_cover, kode_buku, isbn, judul_buku, id_kategori, pengarang, penerbit, tahun_terbit, rak, lokasi_rak, stok)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssssi", $id_cover, $kode_buku, $isbn, $judul_buku, $id_kategori, $pengarang, $penerbit, $tahun_terbit, $rak, $lokasi_rak, $stok);

    if ($stmt->execute()) {
        $notif = "Buku baru berhasil ditambahkan.";
    } else {
        $notif = "Gagal menambahkan buku: " . $stmt->error;
        $notif_type = "danger";
    }
    $stmt->close();
}

// =========================================================
// EDIT BUKU
// =========================================================
if (isset($_POST['edit'])) {
    $id_buku      = intval($_POST['id_buku']);
    $kode_buku    = $_POST['kode_buku'];
    $isbn         = $_POST['isbn'];
    $judul_buku   = $_POST['judul_buku'];
    $id_kategori  = $_POST['id_kategori'];
    $pengarang    = $_POST['pengarang'];
    $penerbit     = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $rak          = $_POST['rak'];
    $lokasi_rak   = $_POST['lokasi_rak'];
    $stok         = intval($_POST['stok']);

    if (isset($_FILES['id_cover']) && $_FILES['id_cover']['error'] == 0) {
        $ext = pathinfo($_FILES['id_cover']['name'], PATHINFO_EXTENSION);
        $id_cover = uniqid() . "." . $ext;
        move_uploaded_file($_FILES['id_cover']['tmp_name'], $folder_cover . $id_cover);

        $stmt = $conn->prepare("UPDATE buku SET id_cover=?, kode_buku=?, isbn=?, judul_buku=?, id_kategori=?, pengarang=?, penerbit=?, tahun_terbit=?, rak=?, lokasi_rak=?, stok=? WHERE id_buku=?");
        $stmt->bind_param("ssssssssssii", $id_cover, $kode_buku, $isbn, $judul_buku, $id_kategori, $pengarang, $penerbit, $tahun_terbit, $rak, $lokasi_rak, $stok, $id_buku);
    } else {
        $stmt = $conn->prepare("UPDATE buku SET kode_buku=?, isbn=?, judul_buku=?, id_kategori=?, pengarang=?, penerbit=?, tahun_terbit=?, rak=?, lokasi_rak=?, stok=? WHERE id_buku=?");
        $stmt->bind_param("sssssssssii", $kode_buku, $isbn, $judul_buku, $id_kategori, $pengarang, $penerbit, $tahun_terbit, $rak, $lokasi_rak, $stok, $id_buku);
    }

    if ($stmt->execute()) {
        $notif = "Data buku berhasil diperbarui.";
    } else {
        $notif = "Gagal memperbarui buku: " . $stmt->error;
        $notif_type = "danger";
    }
    $stmt->close();
}

// =========================================================
// HAPUS BUKU
// =========================================================
if (isset($_GET['hapus'])) {
    $id_buku = intval($_GET['hapus']);

    $cek = $conn->query("SELECT id_cover FROM buku WHERE id_buku=$id_buku");
    if ($row = $cek->fetch_assoc()) {
        if (!empty($row['id_cover']) && file_exists($folder_cover . $row['id_cover'])) {
            unlink($folder_cover . $row['id_cover']);
        }
    }

    if ($conn->query("DELETE FROM buku WHERE id_buku=$id_buku")) {
        $notif = "Buku berhasil dihapus.";
    } else {
        $notif = "Gagal menghapus buku: " . $conn->error;
        $notif_type = "danger";
    }
}

// =========================================================
// AMBIL DATA KATEGORI (untuk dropdown)
// =========================================================
$kategori_list = [];
$res_kategori = $conn->query("SELECT id_kategori, nama_kategori FROM kategori ORDER BY nama_kategori ASC");
if ($res_kategori) {
    while ($k = $res_kategori->fetch_assoc()) {
        $kategori_list[] = $k;
    }
}

// =========================================================
// PENCARIAN & AMBIL DATA BUKU + RATING DARI TABEL ULASAN
// =========================================================
$keyword = isset($_GET['cari']) ? trim($_GET['cari']) : "";

$sql = "SELECT b.*, k.nama_kategori, 
               COALESCE(AVG(u.rating), 0) AS rata_rating, 
               COUNT(u.id_ulasan) AS total_ulasan
        FROM buku b 
        LEFT JOIN kategori k ON b.id_kategori = k.id_kategori
        LEFT JOIN ulasan u ON b.id_buku = u.id_buku";

if ($keyword !== "") {
    $keyword_esc = $conn->real_escape_string($keyword);
    $sql .= " WHERE b.judul_buku LIKE '%$keyword_esc%' 
              OR b.kode_buku LIKE '%$keyword_esc%' 
              OR b.pengarang LIKE '%$keyword_esc%'";
}

$sql .= " GROUP BY b.id_buku ORDER BY b.id_buku ASC";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Manajemen Buku - Perpustakaan</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    body {
        background: #f4f6fa;
        font-family: 'Segoe UI', sans-serif;
    }
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }
    .page-header h2 {
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 2px;
    }
    .page-header p {
        color: #64748b;
        margin: 0;
    }
    .btn-dashboard {
        background: #0f172a;
        color: #fff;
        border-radius: 8px;
        padding: 10px 20px;
        font-weight: 500;
        text-decoration: none;
    }
    .btn-dashboard:hover { background: #1e293b; color: #fff; }

    .card-panel {
        background: #fff;
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    }
    .card-panel-header {
        background: #0f172a;
        color: #fff;
        padding: 18px 24px;
        border-bottom: 4px solid #f59e0b;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
    }
    .card-panel-header h5 {
        margin: 0;
        font-weight: 700;
    }
    .btn-tambah {
        background: #f59e0b;
        color: #1e293b;
        border: none;
        font-weight: 600;
        padding: 8px 16px;
        border-radius: 8px;
    }
    .btn-tambah:hover { background: #d97706; color: #fff; }

    table thead th {
        background: #0f172a;
        color: #fff;
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: .03em;
        border: none;
        padding: 12px 16px;
        vertical-align: middle;
    }
    table tbody td {
        padding: 14px 16px;
        vertical-align: middle;
        font-size: 14px;
    }
    table tbody tr:hover { background: #f8fafc; }

    .kode-badge {
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        padding: 3px 10px;
        font-size: 12px;
        font-weight: 600;
        color: #334155;
    }
    .cover-thumb {
        width: 42px;
        height: 56px;
        object-fit: cover;
        border-radius: 4px;
        border: 1px solid #e2e8f0;
    }
    .badge-stok {
        padding: 5px 14px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 13px;
        color: #fff;
    }
    .stok-habis { background: #ef4444; }
    .stok-sedikit { background: #f59e0b; }
    .stok-aman { background: #22c55e; }

    .search-box {
        max-width: 280px;
    }
    .action-btn {
        border: none;
        background: transparent;
        font-size: 16px;
        margin: 0 3px;
    }
    .action-btn.edit { color: #3b82f6; }
    .action-btn.delete { color: #ef4444; }

    /* ==== SIDEBAR (seragam di semua halaman admin) ==== */
    .sidebar {
        width: 260px; height: 100vh; background-color: #121629;
        position: fixed; top: 0; left: 0; color: #fff;
        display: flex; flex-direction: column; justify-content: space-between;
        z-index: 1000; padding-top: 20px; overflow-y: auto;
    }
    .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
    .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
    .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
    .sidebar a:hover, .sidebar a.active { color: #fff; background: #4f46e5; }
    .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
    .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; }
    .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
    .main-content { margin-left: 260px; }
    @media (max-width: 768px) {
        .sidebar { width: 220px; }
        .main-content { margin-left: 220px; }
    }
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div>
        <h4><i class="fa-solid fa-shield-halved text-warning"></i> ADMIN PANEL</h4>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="buku.php" class="<?= $current_page == 'buku.php' ? 'active' : '' ?>"><i class="fas fa-book"></i> Data Buku</a>
            <a href="anggota.php" class="<?= $current_page == 'anggota.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> Data Anggota</a>
            <a href="petugas.php" class="<?= $current_page == 'petugas.php' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Data Petugas</a>
            <a href="transaksi.php" class="<?= $current_page == 'transaksi.php' ? 'active' : '' ?>"><i class="fas fa-exchange-alt"></i> Transaksi</a>
            <a href="denda.php" class="<?= $current_page == 'denda.php' ? 'active' : '' ?>"><i class="fas fa-money-bill-wave"></i> Manajemen Denda</a>
            <a href="notifikasi.php" class="<?= $current_page == 'notifikasi.php' ? 'active' : '' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
            <a href="laporan.php" class="<?= $current_page == 'laporan.php' ? 'active' : '' ?>"><i class="fas fa-file-alt"></i> Laporan</a>
        </div>
    </div>
    <div class="sidebar-footer">
        <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </div>
</div>

<div class="main-content">
<div class="container-fluid py-4 px-4">

    <div class="page-header">
        <div>
            <h2>📖 Manajemen Data Buku</h2>
            <p>Daftar inventaris buku perpustakaan digital.</p>
        </div>
        <a href="dashboard.php" class="btn-dashboard"><i class="bi bi-arrow-left"></i> Dashboard</a>
    </div>

    <?php if ($notif): ?>
        <div class="alert alert-<?= $notif_type ?> alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($notif) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card-panel">
        <div class="card-panel-header">
            <h5>Daftar Buku Tersedia</h5>
            <div class="d-flex gap-2 align-items-center">
                <form method="GET" class="d-flex search-box">
                    <input type="text" name="cari" class="form-control form-control-sm" placeholder="Cari judul, kode, penulis..." value="<?= htmlspecialchars($keyword) ?>">
                    <button class="btn btn-sm btn-light ms-1"><i class="bi bi-search"></i></button>
                </form>
                <button class="btn-tambah" data-bs-toggle="modal" data-bs-target="#modalTambah">
                    <i class="bi bi-plus-lg"></i> Tambah Buku
                </button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Cover</th>
                        <th>Judul Buku</th>
                        <th>Kode Buku</th>
                        <th>ISBN</th>
                        <th>Kategori</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Tahun</th>
                        <th>Rak</th>
                        <th>Lokasi</th>
                        <th>Stok</th>
                        <th>Rating</th> <!-- Kolom Rating Ditambahkan -->
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                if ($result && $result->num_rows > 0):
                    $no = 1;
                    while ($row = $result->fetch_assoc()):
                        $stok = intval($row['stok']);
                        if ($stok <= 0) {
                            $stok_class = "stok-habis";
                            $stok_label = "Habis";
                        } elseif ($stok <= 3) {
                            $stok_class = "stok-sedikit";
                            $stok_label = $stok;
                        } else {
                            $stok_class = "stok-aman";
                            $stok_label = $stok;
                        }
                        $cover_src = !empty($row['id_cover']) ? $folder_cover . $row['id_cover'] : 'assets/no-cover.png';
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td>
                            <img src="<?= htmlspecialchars($cover_src) ?>" class="cover-thumb" onerror="this.src='https://via.placeholder.com/42x56?text=No+Img'">
                        </td>
                        <td><strong><?= htmlspecialchars($row['judul_buku']) ?></strong></td>
                        <td><span class="kode-badge"><?= htmlspecialchars($row['kode_buku']) ?></span></td>
                        <td><?= htmlspecialchars($row['isbn']) ?></td>
                        <td><?= htmlspecialchars($row['nama_kategori'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($row['pengarang']) ?></td>
                        <td><?= htmlspecialchars($row['penerbit']) ?></td>
                        <td><?= htmlspecialchars($row['tahun_terbit']) ?></td>
                        <td><?= htmlspecialchars($row['rak']) ?></td>
                        <td><?= htmlspecialchars($row['lokasi_rak']) ?></td>
                        <td><span class="badge-stok <?= $stok_class ?>"><?= $stok_label ?></span></td>
                        
                        <!-- Menampilkan Rating -->
                        <td>
                            <span class="text-warning fw-bold">⭐ <?= number_format($row['rata_rating'], 1) ?></span>
                            <small class="text-muted">(<?= $row['total_ulasan'] ?>)</small>
                        </td>

                        <td>
                            <button class="action-btn edit"
                                data-bs-toggle="modal" data-bs-target="#modalEdit"
                                data-id="<?= $row['id_buku'] ?>"
                                data-kode="<?= htmlspecialchars($row['kode_buku']) ?>"
                                data-isbn="<?= htmlspecialchars($row['isbn']) ?>"
                                data-judul="<?= htmlspecialchars($row['judul_buku']) ?>"
                                data-kategori="<?= $row['id_kategori'] ?>"
                                data-pengarang="<?= htmlspecialchars($row['pengarang']) ?>"
                                data-penerbit="<?= htmlspecialchars($row['penerbit']) ?>"
                                data-tahun="<?= htmlspecialchars($row['tahun_terbit']) ?>"
                                data-rak="<?= htmlspecialchars($row['rak']) ?>"
                                data-lokasi="<?= htmlspecialchars($row['lokasi_rak']) ?>"
                                data-stok="<?= $stok ?>"
                                title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            <a href="?hapus=<?= $row['id_buku'] ?>" class="action-btn delete" title="Hapus"
                               onclick="return confirm('Yakin ingin menghapus buku \'<?= htmlspecialchars(addslashes($row['judul_buku'])) ?>\'?');">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr>
                        <td colspan="14" class="text-center text-muted py-4">Belum ada data buku.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- MODAL TAMBAH -->
<div class="modal fade" id="modalTambah" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="POST" enctype="multipart/form-data">
        <div class="modal-header">
          <h5 class="modal-title">Tambah Buku Baru</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body row g-3">
            <div class="col-md-6">
                <label class="form-label">Kode Buku</label>
                <input type="text" name="kode_buku" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">ISBN</label>
                <input type="text" name="isbn" class="form-control">
            </div>
            <div class="col-md-12">
                <label class="form-label">Judul Buku</label>
                <input type="text" name="judul_buku" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Kategori</label>
                <select name="id_kategori" class="form-select" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($kategori_list as $k): ?>
                        <option value="<?= $k['id_kategori'] ?>"><?= htmlspecialchars($k['nama_kategori']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Penulis</label>
                <input type="text" name="pengarang" class="form-control">
            </div>
            <div class="col-md-6">
                <label class="form-label">Penerbit</label>
                <input type="text" name="penerbit" class="form-control">
            </div>
            <div class="col-md-6">
                <label class="form-label">Tahun Terbit</label>
                <input type="number" name="tahun_terbit" class="form-control" min="1900" max="2100">
            </div>
            <div class="col-md-4">
                <label class="form-label">Rak</label>
                <input type="text" name="rak" class="form-control">
            </div>
            <div class="col-md-4">
                <label class="form-label">Lokasi Rak</label>
                <input type="text" name="lokasi_rak" class="form-control">
            </div>
            <div class="col-md-4">
                <label class="form-label">Stok</label>
                <input type="number" name="stok" class="form-control" min="0" value="0" required>
            </div>
            <div class="col-md-12">
                <label class="form-label">Cover Buku</label>
                <input type="file" name="id_cover" class="form-control" accept="image/*">
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" name="tambah" class="btn btn-warning">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- MODAL EDIT -->
<div class="modal fade" id="modalEdit" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id_buku" id="edit_id_buku">
        <div class="modal-header">
          <h5 class="modal-title">Edit Data Buku</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body row g-3">
            <div class="col-md-6">
                <label class="form-label">Kode Buku</label>
                <input type="text" name="kode_buku" id="edit_kode_buku" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">ISBN</label>
                <input type="text" name="isbn" id="edit_isbn" class="form-control">
            </div>
            <div class="col-md-12">
                <label class="form-label">Judul Buku</label>
                <input type="text" name="judul_buku" id="edit_judul_buku" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Kategori</label>
                <select name="id_kategori" id="edit_id_kategori" class="form-select" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($kategori_list as $k): ?>
                        <option value="<?= $k['id_kategori'] ?>"><?= htmlspecialchars($k['nama_kategori']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Penulis</label>
                <input type="text" name="pengarang" id="edit_pengarang" class="form-control">
            </div>
            <div class="col-md-6">
                <label class="form-label">Penerbit</label>
                <input type="text" name="penerbit" id="edit_penerbit" class="form-control">
            </div>
            <div class="col-md-6">
                <label class="form-label">Tahun Terbit</label>
                <input type="number" name="tahun_terbit" id="edit_tahun_terbit" class="form-control" min="1900" max="2100">
            </div>
            <div class="col-md-4">
                <label class="form-label">Rak</label>
                <input type="text" name="rak" id="edit_rak" class="form-control">
            </div>
            <div class="col-md-4">
                <label class="form-label">Lokasi Rak</label>
                <input type="text" name="lokasi_rak" id="edit_lokasi_rak" class="form-control">
            </div>
            <div class="col-md-4">
                <label class="form-label">Stok</label>
                <input type="number" name="stok" id="edit_stok" class="form-control" min="0" required>
            </div>
            <div class="col-md-12">
                <label class="form-label">Cover Baru (kosongkan jika tidak ganti)</label>
                <input type="file" name="id_cover" class="form-control" accept="image/*">
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" name="edit" class="btn btn-warning">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.action-btn.edit').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.getElementById('edit_id_buku').value      = btn.dataset.id;
            document.getElementById('edit_kode_buku').value    = btn.dataset.kode;
            document.getElementById('edit_isbn').value         = btn.dataset.isbn;
            document.getElementById('edit_judul_buku').value   = btn.dataset.judul;
            document.getElementById('edit_id_kategori').value  = btn.dataset.kategori;
            document.getElementById('edit_pengarang').value    = btn.dataset.pengarang;
            document.getElementById('edit_penerbit').value     = btn.dataset.penerbit;
            document.getElementById('edit_tahun_terbit').value = btn.dataset.tahun;
            document.getElementById('edit_rak').value          = btn.dataset.rak;
            document.getElementById('edit_lokasi_rak').value   = btn.dataset.lokasi;
            document.getElementById('edit_stok').value         = btn.dataset.stok;
        });
    });
});
</script>
</body>
</html>
<?php $conn->close(); ?>