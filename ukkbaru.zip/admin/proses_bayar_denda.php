<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

$id_peminjaman = (int)($_GET['id'] ?? 0);
$status_ubah   = $_GET['status'] ?? 'lunas';

if ($id_peminjaman > 0) {
    $status_baru = ($status_ubah == 'batal') ? 'Belum Lunas' : 'Lunas';
    
    $stmt = mysqli_prepare($conn, "UPDATE peminjaman SET status_denda = ? WHERE id_peminjaman = ?");
    mysqli_stmt_bind_param($stmt, "si", $status_baru, $id_peminjaman);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['pesan'] = "Status pembayaran denda berhasil diperbarui menjadi $status_baru.";
        $_SESSION['pesan_tipe'] = "success";
    } else {
        $_SESSION['pesan'] = "Gagal memperbarui status denda.";
        $_SESSION['pesan_tipe'] = "error";
    }
}

header("location: denda.php");
exit();