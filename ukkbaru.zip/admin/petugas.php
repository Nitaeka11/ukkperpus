<?php
session_start();
require_once '../config/koneksi.php';
$current_page = basename($_SERVER['PHP_SELF']);

// ========== PROSES TAMBAH ==========
if (isset($_POST['tambah'])) {
    $nama_petugas = mysqli_real_escape_string($conn, $_POST['nama_petugas']);
    $username     = mysqli_real_escape_string($conn, $_POST['username']);
    $email        = mysqli_real_escape_string($conn, $_POST['email']);
    $no_hp        = mysqli_real_escape_string($conn, $_POST['no_hp']);
    $password     = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Cek username/email duplikat
    $cek = mysqli_query($conn, "SELECT id_petugas FROM petugas WHERE username='$username' OR email='$email'");
    if (mysqli_num_rows($cek) > 0) {
        $_SESSION['alert'] = ['type' => 'danger', 'msg' => 'Username atau Email sudah terdaftar!'];
    } else {
        $query = "INSERT INTO petugas (nama_petugas, username, email, no_hp, password) 
                  VALUES ('$nama_petugas', '$username', '$email', '$no_hp', '$password')";
        if (mysqli_query($conn, $query)) {
            $_SESSION['alert'] = ['type' => 'success', 'msg' => 'Data petugas berhasil ditambahkan!'];
        } else {
            $_SESSION['alert'] = ['type' => 'danger', 'msg' => 'Gagal menambahkan: ' . mysqli_error($conn)];
        }
    }
    header("Location: petugas.php");
    exit;
}

// ========== PROSES EDIT ==========
if (isset($_POST['edit'])) {
    $id_petugas   = mysqli_real_escape_string($conn, $_POST['id_petugas']);
    $nama_petugas = mysqli_real_escape_string($conn, $_POST['nama_petugas']);
    $username     = mysqli_real_escape_string($conn, $_POST['username']);
    $email        = mysqli_real_escape_string($conn, $_POST['email']);
    $no_hp        = mysqli_real_escape_string($conn, $_POST['no_hp']);

    // Cek duplikat (kecuali dirinya sendiri)
    $cek = mysqli_query($conn, "SELECT id_petugas FROM petugas WHERE (username='$username' OR email='$email') AND id_petugas!='$id_petugas'");
    if (mysqli_num_rows($cek) > 0) {
        $_SESSION['alert'] = ['type' => 'danger', 'msg' => 'Username atau Email sudah digunakan petugas lain!'];
    } else {
        $query = "UPDATE petugas SET 
                    nama_petugas='$nama_petugas', 
                    username='$username', 
                    email='$email', 
                    no_hp='$no_hp'";
        
        // Update password hanya jika diisi
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $query .= ", password='$password'";
        }
        $query .= " WHERE id_petugas='$id_petugas'";
        
        if (mysqli_query($conn, $query)) {
            $_SESSION['alert'] = ['type' => 'success', 'msg' => 'Data petugas berhasil diperbarui!'];
        } else {
            $_SESSION['alert'] = ['type' => 'danger', 'msg' => 'Gagal memperbarui: ' . mysqli_error($conn)];
        }
    }
    header("Location: petugas.php");
    exit;
}

// ========== PROSES HAPUS ==========
if (isset($_GET['hapus'])) {
    $id_petugas = mysqli_real_escape_string($conn, $_GET['hapus']);
    
    // Jangan hapus diri sendiri
    if ($id_petugas == ($_SESSION['id_petugas'] ?? 0)) {
        $_SESSION['alert'] = ['type' => 'danger', 'msg' => 'Tidak bisa menghapus akun sendiri!'];
    } else {
        $query = "DELETE FROM petugas WHERE id_petugas='$id_petugas'";
        if (mysqli_query($conn, $query)) {
            $_SESSION['alert'] = ['type' => 'success', 'msg' => 'Data petugas berhasil dihapus!'];
        } else {
            $_SESSION['alert'] = ['type' => 'danger', 'msg' => 'Gagal menghapus: ' . mysqli_error($conn)];
        }
    }
    header("Location: petugas.php");
    exit;
}

// ========== AMBIL DATA ==========
$query  = "SELECT * FROM petugas ORDER BY id_petugas DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Petugas - Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');
        
        * { font-family: 'Poppins', sans-serif; }
        body { background: #f0f4f8; min-height: 100vh; }

        /* Header */
        .page-header { margin-bottom: 24px; }
        .page-title { 
            font-size: 1.6rem; font-weight: 800; color: #1e293b; 
            letter-spacing: -0.5px; margin-bottom: 2px;
        }
        .page-sub { color: #64748b; font-size: 0.9rem; }
        .btn-dash {
            background: #1e293b; color: #fff; border: none;
            border-radius: 50px; padding: 10px 24px;
            font-weight: 600; font-size: 0.9rem;
            text-decoration: none; display: inline-flex;
            align-items: center; gap: 8px; transition: .3s;
        }
        .btn-dash:hover { background: #334155; color: #fff; transform: translateY(-1px); }

        /* Alert */
        .alert-custom {
            border-radius: 16px; border: none;
            padding: 14px 20px; margin-bottom: 24px;
            font-weight: 500; font-size: 0.9rem;
            display: flex; align-items: center; gap: 10px;
        }
        .alert-custom.alert-success { background: #dcfce7; color: #166534; }
        .alert-custom.alert-danger { background: #fee2e2; color: #991b1b; }

        /* Card Form */
        .card-form {
            background: #fff; border-radius: 24px;
            padding: 32px; margin-bottom: 28px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.04);
            border: 1px solid rgba(0,0,0,0.03);
        }
        .card-form h5 {
            font-weight: 700; color: #1e293b;
            margin-bottom: 24px; font-size: 1.1rem;
        }
        .form-label {
            font-size: 0.78rem; font-weight: 700;
            color: #475569; text-transform: uppercase;
            letter-spacing: 0.5px; margin-bottom: 6px;
        }
        .form-control {
            border-radius: 14px; border: 2px solid #e2e8f0;
            padding: 12px 16px; font-size: 0.9rem;
            color: #334155; transition: .2s;
        }
        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 4px rgba(59,130,246,0.1);
        }

        .btn-simpan {
            background: #22c55e; color: #fff; border: none;
            border-radius: 14px; padding: 14px 32px;
            font-weight: 700; font-size: 0.95rem;
            display: inline-flex; align-items: center; gap: 8px;
            transition: .3s;
        }
        .btn-simpan:hover {
            background: #16a34a; transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(34,197,94,0.3);
        }

        /* Table Card */
        .table-card {
            background: #fff; border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 4px 24px rgba(0,0,0,0.04);
            border: 1px solid rgba(0,0,0,0.03);
        }
        .table-header {
            background: #1e293b; color: #fff;
            padding: 22px 32px;
            border-bottom: 4px solid #fbbf24;
        }
        .table-header h4 { margin: 0; font-weight: 700; font-size: 1.15rem; }

        .table-custom { margin: 0; }
        .table-custom thead th {
            background: #0f172a; color: #94a3b8;
            font-weight: 700; font-size: 0.72rem;
            text-transform: uppercase; letter-spacing: 0.8px;
            padding: 18px 16px; border: none;
            white-space: nowrap;
        }
        .table-custom tbody td {
            padding: 18px 16px; vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
            color: #334155; font-size: 0.88rem;
        }
        .table-custom tbody tr { transition: .15s; }
        .table-custom tbody tr:hover { background: #f8fafc; }

        /* Badges */
        .b-username {
            background: #f1f5f9; color: #475569;
            padding: 5px 12px; border-radius: 8px;
            font-weight: 600; font-size: 0.8rem;
        }

        /* Action Buttons */
        .btn-act {
            width: 36px; height: 36px; border-radius: 10px;
            border: none; display: inline-flex;
            align-items: center; justify-content: center;
            margin: 0 3px; transition: .2s; color: #fff;
            font-size: 0.9rem;
        }
        .btn-act:hover { transform: scale(1.1); }
        .btn-edit { background: #f59e0b; }
        .btn-edit:hover { background: #d97706; }
        .btn-del { background: #ef4444; }
        .btn-del:hover { background: #dc2626; }

        /* Modal */
        .modal-header { background: #1e293b; color: #fff; }
        .modal-header .btn-close { filter: invert(1); }
        .btn-update {
            background: #4f46e5; color: #fff; border: none;
            border-radius: 12px; padding: 10px 24px;
            font-weight: 700;
        }
        .btn-update:hover { background: #4338ca; }

        .empty-state { text-align: center; padding: 50px 20px; color: #94a3b8; }
        .empty-state i { font-size: 3rem; margin-bottom: 12px; display: block; }

        /* ==== SIDEBAR (seragam di semua halaman admin) ==== */
        .sidebar {
            width: 260px; height: 100vh; background-color: #121629;
            position: fixed; top: 0; left: 0; color: #fff;
            display: flex; flex-direction: column; justify-content: space-between;
            z-index: 1000; padding-top: 20px; overflow-y: auto;
        }
        .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
        .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
        .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
        .sidebar a:hover, .sidebar a.active { color: #fff; background: #4f46e5; }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; }
        @media (max-width: 768px) {
            .sidebar { width: 220px; }
            .main-content { margin-left: 220px; }
        }
    </style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div>
        <h4><i class="fa-solid fa-shield-halved text-warning"></i> ADMIN PANEL</h4>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="buku.php" class="<?= $current_page == 'buku.php' ? 'active' : '' ?>"><i class="fas fa-book"></i> Data Buku</a>
            <a href="anggota.php" class="<?= $current_page == 'anggota.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> Data Anggota</a>
            <a href="petugas.php" class="<?= $current_page == 'petugas.php' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Data Petugas</a>
            <a href="transaksi.php" class="<?= $current_page == 'transaksi.php' ? 'active' : '' ?>"><i class="fas fa-exchange-alt"></i> Transaksi</a>
            <a href="denda.php" class="<?= $current_page == 'denda.php' ? 'active' : '' ?>"><i class="fas fa-money-bill-wave"></i> Manajemen Denda</a>
            <a href="notifikasi.php" class="<?= $current_page == 'notifikasi.php' ? 'active' : '' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
            <a href="laporan.php" class="<?= $current_page == 'laporan.php' ? 'active' : '' ?>"><i class="fas fa-file-alt"></i> Laporan</a>
        </div>
    </div>
    <div class="sidebar-footer">
        <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </div>
</div>

<div class="main-content">
<div class="container-fluid py-4 px-4">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center page-header">
        <div>
            <div class="page-title"><i class="bi bi-person-badge-fill text-warning me-2"></i>Manajemen Data Petugas</div>
            <div class="page-sub">Daftar petugas pengelola sistem perpustakaan.</div>
        </div>
        <a href="dashboard.php" class="btn-dash">
            <i class="bi bi-arrow-left"></i> Dashboard
        </a>
    </div>

    <!-- Alert -->
    <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert']['type']; ?> alert-custom alert-dismissible fade show">
            <i class="bi bi-<?php echo $_SESSION['alert']['type']=='success'?'check-circle-fill':'x-circle-fill'; ?>"></i>
            <?php echo $_SESSION['alert']['msg']; ?>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <!-- Form Tambah -->
    <div class="card-form">
        <h5><i class="bi bi-plus-lg text-primary me-2"></i>Tambah Petugas Baru</h5>
        <form method="POST" action="">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="nama_petugas" class="form-control" placeholder="Siti Aminah, S.Pd" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" placeholder="petugas1" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="petugas@sekolah.sch.id" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">No. HP</label>
                    <input type="text" name="no_hp" class="form-control" placeholder="081234567890" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Minimal 6 karakter" required minlength="6">
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" name="tambah" class="btn-simpan">
                    <i class="bi bi-save"></i> Simpan Data
                </button>
            </div>
        </form>
    </div>

    <!-- Tabel -->
    <div class="table-card">
        <div class="table-header">
            <h4><i class="bi bi-table me-2"></i>Data Petugas Perpustakaan</h4>
        </div>
        <div class="table-responsive">
            <table class="table table-custom">
                <thead>
                    <tr>
                        <th class="text-center" width="5%">NO</th>
                        <th width="25%">NAMA PETUGAS</th>
                        <th width="15%">USERNAME</th>
                        <th width="28%">EMAIL</th>
                        <th width="17%">NO HP</th>
                        <th class="text-center" width="12%">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    if (mysqli_num_rows($result) > 0):
                        while ($row = mysqli_fetch_assoc($result)): 
                    ?>
                    <tr>
                        <td class="text-center fw-bold text-muted"><?php echo $no++; ?></td>
                        <td class="fw-semibold text-dark"><?php echo htmlspecialchars($row['nama_petugas']); ?></td>
                        <td><span class="b-username"><?php echo htmlspecialchars($row['username']); ?></span></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['no_hp']); ?></td>
                        <td class="text-center">
                            <button class="btn-act btn-edit" data-bs-toggle="modal" data-bs-target="#edit<?php echo $row['id_petugas']; ?>" title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            <a href="?hapus=<?php echo $row['id_petugas']; ?>" class="btn-act btn-del" 
                               onclick="return confirm('Yakin hapus data <?php echo $row['nama_petugas']; ?>?')" title="Hapus">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>

                    <!-- Modal Edit -->
                    <div class="modal fade" id="edit<?php echo $row['id_petugas']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i>Edit Data Petugas</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <form method="POST" action="">
                                    <div class="modal-body">
                                        <input type="hidden" name="id_petugas" value="<?php echo $row['id_petugas']; ?>">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label class="form-label">Nama Lengkap</label>
                                                <input type="text" name="nama_petugas" class="form-control" value="<?php echo $row['nama_petugas']; ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Username</label>
                                                <input type="text" name="username" class="form-control" value="<?php echo $row['username']; ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Email</label>
                                                <input type="email" name="email" class="form-control" value="<?php echo $row['email']; ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">No. HP</label>
                                                <input type="text" name="no_hp" class="form-control" value="<?php echo $row['no_hp']; ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Password Baru <small class="text-muted">(Kosongkan jika tidak diubah)</small></label>
                                                <input type="password" name="password" class="form-control" placeholder="Minimal 6 karakter" minlength="6">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary rounded-3" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" name="edit" class="btn-update"><i class="bi bi-check-lg me-1"></i>Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <h5>Belum ada data petugas</h5>
                                <p>Silakan tambahkan data petugas baru.</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>