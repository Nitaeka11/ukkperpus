<?php
/* =========================================================
   DENDA.PHP — Manajemen & Pembayaran Denda (Admin)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

$nama_admin = $_SESSION['nama'] ?? 'Administrator';
$current_page = basename($_SERVER['PHP_SELF']);

// Pastikan ada kolom status_denda di tabel peminjaman, jika belum buat secara otomatis/aman
$cek_kolom = mysqli_query($conn, "SHOW COLUMNS FROM peminjaman LIKE 'status_denda'");
if (mysqli_num_rows($cek_kolom) == 0) {
    mysqli_query($conn, "ALTER TABLE peminjaman ADD COLUMN status_denda VARCHAR(20) DEFAULT 'Belum Lunas'");
}

// Ambil data transaksi yang memiliki denda (> 0)
$query = "SELECT p.*, b.judul_buku, b.kode_buku, a.nama_lengkap AS nama_anggota 
          FROM peminjaman p 
          JOIN buku b ON p.id_buku = b.id_buku 
          JOIN anggota a ON p.id_anggota = a.id_anggota 
          WHERE p.total_denda > 0 
          ORDER BY p.id_peminjaman DESC";
$result = mysqli_query($conn, $query);

// Hitung total denda yang terkumpul & yang belum dibayar
$q_total = mysqli_query($conn, "SELECT 
    SUM(CASE WHEN status_denda = 'Lunas' THEN total_denda ELSE 0 END) AS total_lunas,
    SUM(CASE WHEN status_denda != 'Lunas' OR status_denda IS NULL THEN total_denda ELSE 0 END) AS total_belum_lunas
    FROM peminjaman WHERE total_denda > 0");
$rekap = mysqli_fetch_assoc($q_total);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Denda - Admin Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-bg: #121629;
            --primary-color: #4f46e5;
            --bg-body: #f4f5f7;
        }
        body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; padding-top: 20px; }
        .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
        .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
        .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
        .sidebar a:hover, .sidebar a.active { color: #fff; background: var(--primary-color); }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.03); border-radius: 15px; }
    </style>
</head>
<body>

    <!-- SIDEBAR ADMIN -->
    <div class="sidebar">
        <div>
            <h4><i class="fa-solid fa-shield-halved text-warning"></i> ADMIN PANEL</h4>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
                <a href="buku.php" class="<?= $current_page == 'buku.php' ? 'active' : '' ?>"><i class="fas fa-book"></i> Data Buku</a>
                <a href="anggota.php" class="<?= $current_page == 'anggota.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> Data Anggota</a>
                <a href="petugas.php" class="<?= $current_page == 'petugas.php' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Data Petugas</a>
                <a href="transaksi.php" class="<?= $current_page == 'transaksi.php' ? 'active' : '' ?>"><i class="fas fa-exchange-alt"></i> Transaksi</a>
                <a href="denda.php" class="<?= $current_page == 'denda.php' ? 'active' : '' ?>"><i class="fas fa-money-bill-wave"></i> Manajemen Denda</a>
                <a href="notifikasi.php" class="<?= $current_page == 'notifikasi.php' ? 'active' : '' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
                <a href="laporan.php" class="<?= $current_page == 'laporan.php' ? 'active' : '' ?>"><i class="fas fa-file-alt"></i> Laporan</a>
            </div>
        </div>
        <div class="sidebar-footer">
            <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <h3 class="fw-bold mb-1">Manajemen & Pembayaran Denda</h3>
            <p class="text-muted mb-4">Kelola pencatatan denda keterlambatan pengembalian buku siswa.</p>

            <?php if (isset($_SESSION['pesan'])): ?>
                <div class="alert alert-<?= $_SESSION['pesan_tipe'] == 'success' ? 'success' : 'danger' ?> alert-dismissible fade show">
                    <?= htmlspecialchars($_SESSION['pesan']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['pesan'], $_SESSION['pesan_tipe']); ?>
            <?php endif; ?>

            <!-- KARTU RINGKASAN DENDA -->
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <div class="card p-4 border-start border-success border-4">
                        <h6 class="text-muted">Total Denda Lunas (Terkumpul)</h6>
                        <h3 class="fw-bold text-success mt-2">Rp <?= number_format((float)($rekap['total_lunas'] ?? 0), 0, ',', '.') ?></h3>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card p-4 border-start border-danger border-4">
                        <h6 class="text-muted">Total Denda Belum Lunas (Tunggakan)</h6>
                        <h3 class="fw-bold text-danger mt-2">Rp <?= number_format((float)($rekap['total_belum_lunas'] ?? 0), 0, ',', '.') ?></h3>
                    </div>
                </div>
            </div>

            <!-- TABEL DATA DENDA -->
            <div class="card p-4">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Nama Siswa</th>
                                <th>Judul Buku</th>
                                <th>Terlambat</th>
                                <th>Jumlah Denda</th>
                                <th>Status Pembayaran</th>
                                <th class="text-end">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                                <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><strong><?= htmlspecialchars($row['nama_anggota']) ?></strong></td>
                                    <td><?= htmlspecialchars($row['judul_buku']) ?></td>
                                    <td><span class="badge bg-danger"><?= (int)$row['terlambat_hari'] ?> hari</span></td>
                                    <td><strong class="text-danger">Rp <?= number_format((float)$row['total_denda'], 0, ',', '.') ?></strong></td>
                                    <td>
                                        <?php if (($row['status_denda'] ?? 'Belum Lunas') == 'Lunas'): ?>
                                            <span class="badge bg-success">Lunas</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">Belum Lunas</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if (($row['status_denda'] ?? 'Belum Lunas') != 'Lunas'): ?>
                                            <a href="proses_bayar_denda.php?id=<?= $row['id_peminjaman'] ?>" 
                                               class="btn btn-success btn-sm fw-bold"
                                               onclick="return confirm('Konfirmasi pembayaran denda untuk siswa ini?')">
                                                <i class="fa-solid fa-check-circle"></i> Lunasi
                                            </a>
                                        <?php else: ?>
                                            <a href="proses_bayar_denda.php?id=<?= $row['id_peminjaman'] ?>&status=batal" 
                                               class="btn btn-outline-secondary btn-sm"
                                               onclick="return confirm('Ubah status kembali menjadi belum lunas?')">
                                                Batalkan
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">Belum ada data denda keterlambatan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>