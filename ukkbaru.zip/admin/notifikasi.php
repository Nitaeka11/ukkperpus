<?php
session_start();

// --- KONEKSI DATABASE ---
$host = "localhost";
$user = "root";
$pass = "";
$db   = "perpusku";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

$admin_login = isset($_SESSION['nama_admin']) ? $_SESSION['nama_admin'] : 'Administrator';
$inisial = 'AD';
$current_page = basename($_SERVER['PHP_SELF']);

/* ---------------------------------------------------------
   Helper: deteksi nama kolom yang benar-benar ada di tabel,
   supaya tidak error kalau nama kolomnya beda tiap proyek.
--------------------------------------------------------- */
function deteksi_kolom($koneksi, $tabel, $kandidat) {
    $ada = [];
    $r = mysqli_query($koneksi, "SHOW COLUMNS FROM `$tabel`");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $ada[] = $row['Field'];
    foreach ($kandidat as $k) {
        if (in_array($k, $ada)) return $k;
    }
    return null;
}

// --- Proses hapus ulasan (kalau tombol Hapus diklik) ---
if (isset($_GET['hapus_ulasan'])) {
    $id_hapus = (int) $_GET['hapus_ulasan'];
    mysqli_query($koneksi, "DELETE FROM ulasan WHERE id_ulasan = $id_hapus");
    header("Location: notifikasi.php");
    exit();
}

// --- Ambil daftar ulasan terbaru + nama anggota + judul buku ---
$kolom_nama_anggota = deteksi_kolom($koneksi, 'anggota', ['nama_anggota', 'nama_lengkap', 'nama', 'username']) ?? 'id_anggota';

$notifikasi_list = [];
$cek_tabel_ulasan = mysqli_query($koneksi, "SHOW TABLES LIKE 'ulasan'");
if ($cek_tabel_ulasan && mysqli_num_rows($cek_tabel_ulasan) > 0) {
    $query_notif = mysqli_query($koneksi, "
        SELECT u.id_ulasan, u.rating, u.komentar, u.tanggal,
               a.`$kolom_nama_anggota` AS nama_anggota,
               b.judul_buku
        FROM ulasan u
        LEFT JOIN anggota a ON u.id_anggota = a.id_anggota
        LEFT JOIN buku b ON u.id_buku = b.id_buku
        ORDER BY u.tanggal DESC
        LIMIT 20
    ");
    if ($query_notif) {
        while ($row = mysqli_fetch_assoc($query_notif)) {
            $notifikasi_list[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi Admin - Sistem Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-bg: #121629;
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --bg-body: #f4f5f7;
        }
        body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; overflow-x: hidden; }
        .sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; padding-top: 20px; overflow-y: auto; }
        .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
        .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
        .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
        .sidebar a:hover, .sidebar a.active { color: #fff; background: var(--primary-color); }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; transition: 0.2s; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; padding: 30px; }
        @media (max-width: 768px) {
            .sidebar { width: 220px; }
            .main-content { margin-left: 220px; padding: 20px; }
        }
        .top-navbar { background: white; padding: 15px 30px; border-radius: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); border-radius: 15px; background: white; }

        /* ==== Kartu ulasan gaya gelap sesuai contoh ==== */
        .ulasan-panel { background: #161f2b; border-radius: 15px; padding: 10px; }
        .ulasan-item { background: #1c2734; border-radius: 10px; padding: 18px 20px; margin-bottom: 14px; position: relative; }
        .ulasan-item:last-child { margin-bottom: 0; }
        .ulasan-nama { color: #fff; font-weight: 700; font-size: 15px; }
        .ulasan-arrow { color: #64748b; margin: 0 6px; font-weight: 400; }
        .ulasan-judul-buku { color: #94a3b8; font-weight: 500; font-size: 14px; }
        .ulasan-bintang { color: #fbbf24; font-size: 13px; margin: 6px 0; letter-spacing: 2px; }
        .ulasan-bintang .kosong { color: #3f4b5c; }
        .ulasan-komentar { color: #e2e8f0; font-size: 14.5px; margin-bottom: 6px; }
        .ulasan-tanggal { color: #64748b; font-size: 12px; }
        .btn-hapus-ulasan { position: absolute; top: 16px; right: 18px; color: #f87171; font-size: 13px; font-weight: 600; text-decoration: none; background: none; border: none; }
        .btn-hapus-ulasan:hover { color: #ef4444; text-decoration: underline; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div>
            <h4><i class="fa-solid fa-shield-halved text-warning"></i> ADMIN PANEL</h4>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
                <a href="buku.php" class="<?= $current_page == 'buku.php' ? 'active' : '' ?>"><i class="fas fa-book"></i> Data Buku</a>
                <a href="anggota.php" class="<?= $current_page == 'anggota.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> Data Anggota</a>
                <a href="petugas.php" class="<?= $current_page == 'petugas.php' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Data Petugas</a>
                <a href="transaksi.php" class="<?= $current_page == 'transaksi.php' ? 'active' : '' ?>"><i class="fas fa-exchange-alt"></i> Transaksi</a>
                <a href="denda.php" class="<?= $current_page == 'denda.php' ? 'active' : '' ?>"><i class="fas fa-money-bill-wave"></i> Manajemen Denda</a>
                <a href="notifikasi.php" class="<?= $current_page == 'notifikasi.php' ? 'active' : '' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
                <a href="laporan.php" class="<?= $current_page == 'laporan.php' ? 'active' : '' ?>"><i class="fas fa-file-alt"></i> Laporan</a>
            </div>
        </div>
        <div class="sidebar-footer">
             <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
    </div>

    <div class="main-content">

        <div class="top-navbar">
            <div>
                <h4 class="fw-bold text-dark mb-0">Notifikasi Sistem</h4>
                <small class="text-muted">Ulasan &amp; rating buku terbaru dari anggota</small>
            </div>
            <div class="d-flex align-items-center gap-3">
                <div class="dropdown">
                    <button class="btn btn-light d-flex align-items-center gap-2 rounded-pill px-3 py-1 border" type="button">
                        <span class="badge bg-primary rounded-circle p-2"><?php echo $inisial; ?></span>
                        <span class="fw-bold text-dark small"><?php echo $admin_login; ?></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h5 class="fw-bold text-dark m-0">Ulasan &amp; Rating Buku</h5>
                    <small class="text-muted">Masukan terbaru dari anggota mengenai buku yang mereka baca</small>
                </div>
            </div>

            <div class="ulasan-panel">
                <?php if (count($notifikasi_list) > 0): ?>
                    <?php foreach ($notifikasi_list as $notif):
                        $rating = (int) ($notif['rating'] ?? 0);
                    ?>
                        <div class="ulasan-item">
                            <a href="?hapus_ulasan=<?php echo (int) $notif['id_ulasan']; ?>"
                               class="btn-hapus-ulasan"
                               onclick="return confirm('Hapus ulasan ini?');">Hapus</a>

                            <div>
                                <span class="ulasan-nama"><?php echo htmlspecialchars($notif['nama_anggota'] ?? 'Anggota'); ?></span>
                                <span class="ulasan-arrow">&rarr;</span>
                                <span class="ulasan-judul-buku"><?php echo htmlspecialchars($notif['judul_buku'] ?? '-'); ?></span>
                            </div>

                            <div class="ulasan-bintang">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?php if ($i <= $rating): ?>
                                        <i class="fas fa-star"></i>
                                    <?php else: ?>
                                        <i class="fas fa-star kosong"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>

                            <div class="ulasan-komentar">
                                <?php echo !empty($notif['komentar']) ? htmlspecialchars($notif['komentar']) : '<span class="text-muted fst-italic">Tidak ada komentar</span>'; ?>
                            </div>

                            <div class="ulasan-tanggal">
                                <?php echo date('Y-m-d H:i:s', strtotime($notif['tanggal'])); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="fas fa-star-half-alt fa-2x mb-2 text-secondary"></i>
                        <p class="mb-0 text-white-50">Belum ada ulasan dari anggota.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>