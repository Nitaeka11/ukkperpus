<?php
session_start();
// Cek apakah sudah login dan rolenya admin
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login" || $_SESSION['role'] != "admin") {
    header("location: ../login.php?pesan=belum_login");
    exit();
}

include "../config/koneksi.php";

// Ambil data statistik untuk ringkasan di dashboard
$jml_buku     = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM buku"));
$jml_anggota  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM anggota"));
$jml_petugas  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM petugas"));
$jml_pinjam   = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM peminjaman WHERE status='dipinjam' OR status='Dipinjam'"));
$jml_kembali  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM peminjaman WHERE status='dikembalikan' OR status='Dikembalikan'"));

$nama_admin = $_SESSION['nama'] ?? 'Administrator';
$current_page = basename($_SERVER['PHP_SELF']);

// =========================================================
// TAMBAHAN: TREND PEMINJAMAN BULANAN (6 bulan terakhir)
// Tidak mengubah query/variabel statistik yang sudah ada di atas.
// =========================================================
$trend_label  = [];
$trend_jumlah = [];
$cek_tabel_peminjaman = mysqli_query($conn, "SHOW TABLES LIKE 'peminjaman'");
if (mysqli_num_rows($cek_tabel_peminjaman) > 0) {
    $q_trend = mysqli_query($conn, "SELECT DATE_FORMAT(tgl_pinjam, '%Y-%m') AS bulan, COUNT(*) AS jml
                                     FROM peminjaman
                                     WHERE tgl_pinjam >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                                     GROUP BY bulan
                                     ORDER BY bulan ASC");
    if ($q_trend) {
        while ($t = mysqli_fetch_assoc($q_trend)) {
            $trend_label[]  = date('M Y', strtotime($t['bulan'] . '-01'));
            $trend_jumlah[] = (int) $t['jml'];
        }
    }
}
// Kalau belum ada data sama sekali, kasih array kosong biar chart tetap render (kosong)
if (empty($trend_label)) {
    $trend_label  = [];
    $trend_jumlah = [];
}

// =========================================================
// TAMBAHAN: KATEGORI BUKU PALING POPULER (berdasar jumlah peminjaman)
// =========================================================
$kategori_label  = [];
$kategori_jumlah = [];
$cek_tabel_kategori = mysqli_query($conn, "SHOW TABLES LIKE 'kategori'");
if (mysqli_num_rows($cek_tabel_peminjaman) > 0 && mysqli_num_rows($cek_tabel_kategori) > 0) {
    $q_kategori = mysqli_query($conn, "SELECT k.nama_kategori, COUNT(p.id_peminjaman) AS jml
                                        FROM peminjaman p
                                        JOIN buku b ON p.id_buku = b.id_buku
                                        JOIN kategori k ON b.id_kategori = k.id_kategori
                                        GROUP BY k.id_kategori, k.nama_kategori
                                        ORDER BY jml DESC
                                        LIMIT 5");
    if ($q_kategori) {
        while ($k = mysqli_fetch_assoc($q_kategori)) {
            $kategori_label[]  = $k['nama_kategori'];
            $kategori_jumlah[] = (int) $k['jml'];
        }
    }
}

// =========================================================
// TAMBAHAN: BUKU TERPOPULER (Top 5 paling sering dipinjam)
// =========================================================
$buku_populer_label  = [];
$buku_populer_jumlah = [];
if (mysqli_num_rows($cek_tabel_peminjaman) > 0) {
    $q_buku_populer = mysqli_query($conn, "SELECT b.judul_buku, COUNT(p.id_peminjaman) AS jml
                                            FROM peminjaman p
                                            JOIN buku b ON p.id_buku = b.id_buku
                                            GROUP BY b.id_buku, b.judul_buku
                                            ORDER BY jml DESC
                                            LIMIT 5");
    if ($q_buku_populer) {
        while ($bp = mysqli_fetch_assoc($q_buku_populer)) {
            $buku_populer_label[]  = $bp['judul_buku'];
            $buku_populer_jumlah[] = (int) $bp['jml'];
        }
    }
}

// =========================================================
// TAMBAHAN: DISTRIBUSI BUKU PER LOKASI RAK
// =========================================================
$lokasi_label  = [];
$lokasi_jumlah = [];
$q_lokasi = mysqli_query($conn, "SELECT 
                                    CASE WHEN lokasi_rak IS NULL OR lokasi_rak = '' OR lokasi_rak = '0' THEN 'Belum diisi' ELSE lokasi_rak END AS lokasi,
                                    COUNT(*) AS jml
                                  FROM buku
                                  GROUP BY lokasi
                                  ORDER BY jml DESC");
if ($q_lokasi) {
    while ($lk = mysqli_fetch_assoc($q_lokasi)) {
        $lokasi_label[]  = $lk['lokasi'];
        $lokasi_jumlah[] = (int) $lk['jml'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Perpustakaan Digital SMP N 2 Sanden</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #0284C7;
            --primary-dark: #0369A1;
            --bg-main: #f8fafc;
            --text-dark: #0f172a;
            --text-muted: #64748b;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-main);
            color: var(--text-dark);
            min-height: 100vh;
        }
        /* Sidebar (seragam di semua halaman admin) */
        .sidebar {
            width: 260px;
            height: 100vh;
            background-color: #121629;
            position: fixed;
            top: 0;
            left: 0;
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            z-index: 1000;
            padding-top: 20px;
            overflow-y: auto;
        }
        .sidebar h4 {
            color: #fff;
            text-align: center;
            font-weight: bold;
            margin-bottom: 30px;
            font-size: 1.1rem;
            padding: 0 15px;
        }
        .sidebar-menu {
            padding: 0 15px;
            flex-grow: 1;
            list-style: none;
            margin: 0;
        }
        .sidebar a {
            padding: 12px 15px;
            text-decoration: none;
            font-size: 15px;
            color: #94a3b8;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: 0.3s;
            border-radius: 10px;
            margin-bottom: 5px;
            font-weight: 500;
        }
        .sidebar a:hover, .sidebar a.active {
            color: #fff;
            background: #4f46e5;
        }
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }
        .sidebar-footer a {
            color: #94a3b8;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 15px;
            border-radius: 10px;
        }
        .sidebar-footer a:hover {
            background-color: rgba(239, 68, 68, 0.1);
            color: #ef4444;
        }
        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }
        @media (max-width: 768px) {
            .sidebar { width: 220px; }
            .main-content { margin-left: 220px; padding: 20px; }
        }
        .navbar-top {
            background: #ffffff;
            padding: 15px 30px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #ffffff;
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03);
            display: flex;
            align-items: center;
            gap: 20px;
            border: 1px solid #e2e8f0;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-4px);
        }
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
        }
        .stat-info h3 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 2px;
            color: var(--text-dark);
        }
        .stat-info p {
            font-size: 0.82rem;
            color: var(--text-muted);
            margin-bottom: 0;
            font-weight: 500;
        }
        .chart-card {
            background: #ffffff;
            border-radius: 20px;
            padding: 25px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03);
        }
    </style>
</head>
<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div>
            <h4><i class="fa-solid fa-shield-halved text-warning"></i> ADMIN PANEL</h4>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
                <a href="buku.php" class="<?= $current_page == 'buku.php' ? 'active' : '' ?>"><i class="fas fa-book"></i> Data Buku</a>
                <a href="anggota.php" class="<?= $current_page == 'anggota.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> Data Anggota</a>
                <a href="petugas.php" class="<?= $current_page == 'petugas.php' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Data Petugas</a>
                <a href="transaksi.php" class="<?= $current_page == 'transaksi.php' ? 'active' : '' ?>"><i class="fas fa-exchange-alt"></i> Transaksi</a>
                <a href="denda.php" class="<?= $current_page == 'denda.php' ? 'active' : '' ?>"><i class="fas fa-money-bill-wave"></i> Manajemen Denda</a>
                <a href="notifikasi.php" class="<?= $current_page == 'notifikasi.php' ? 'active' : '' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
                <a href="laporan.php" class="<?= $current_page == 'laporan.php' ? 'active' : '' ?>"><i class="fas fa-file-alt"></i> Laporan</a>
            </div>
        </div>
        <div class="sidebar-footer">
            <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="navbar-top">
            <div>
                <h5 class="mb-0 fw-bold">Dashboard Administrator</h5>
                <small class="text-muted">Selamat datang kembali, <?php echo htmlspecialchars($nama_admin); ?>!</small>
            </div>
            <div class="d-flex align-items-center gap-3">
                <div class="bg-light px-3 py-2 rounded-pill border fw-semibold fs-7 text-primary">
                    <i class="bi bi-shield-check me-1"></i> Admin SMPN 2 Sanden
                </div>
            </div>
        </div>

        <!-- STATS SECTION -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-info bg-opacity-10 text-info">
                        <i class="bi bi-journal-text"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $jml_buku; ?></h3>
                        <p>Total Buku</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-success bg-opacity-10 text-success">
                        <i class="bi bi-people"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $jml_anggota; ?></h3>
                        <p>Total Anggota</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                        <i class="bi bi-person-badge"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $jml_petugas; ?></h3>
                        <p>Total Petugas</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-danger bg-opacity-10 text-danger">
                        <i class="bi bi-arrow-repeat"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $jml_pinjam; ?></h3>
                        <p>Sedang Dipinjam</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- GRAFIK SECTION -->
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="chart-card">
                    <h5 class="fw-bold text-dark mb-3">Statistik Data Perpustakaan</h5>
                    <canvas id="barChart" height="130"></canvas>
                    <div class="d-flex flex-wrap gap-3 mt-3 pt-3 border-top">
                        <span class="small text-muted"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#0ea5e9;margin-right:6px;"></span>Biru = Total Buku</span>
                        <span class="small text-muted"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#22c55e;margin-right:6px;"></span>Hijau = Total Anggota</span>
                        <span class="small text-muted"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#f59e0b;margin-right:6px;"></span>Oranye = Total Petugas</span>
                        <span class="small text-muted"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#ef4444;margin-right:6px;"></span>Merah = Sedang Dipinjam</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="chart-card">
                    <h5 class="fw-bold text-dark mb-3">Status Peminjaman</h5>
                    <canvas id="doughnutChart" height="130"></canvas>
                    <div class="d-flex flex-wrap gap-3 mt-3 pt-3 border-top">
                        <span class="small text-muted"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#ef4444;margin-right:6px;"></span>Merah = Sedang Dipinjam</span>
                        <span class="small text-muted"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#22c55e;margin-right:6px;"></span>Hijau = Sudah Dikembalikan</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- GRAFIK TAMBAHAN: TREND BULANAN & KATEGORI POPULER -->
        <div class="row g-4 mt-1">
            <div class="col-lg-8">
                <div class="chart-card">
                    <h5 class="fw-bold text-dark mb-3">Trend Peminjaman Bulanan (6 Bulan Terakhir)</h5>
                    <canvas id="trendChart" height="130"></canvas>
                    <div class="d-flex flex-wrap gap-3 mt-3 pt-3 border-top">
                        <span class="small text-muted"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#0284C7;margin-right:6px;"></span>Biru = Jumlah Peminjaman per Bulan</span>
                    </div>
                    <?php if (empty($trend_label)): ?>
                        <p class="text-muted small mt-2 mb-0">Belum ada data peminjaman pada 6 bulan terakhir.</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="chart-card">
                    <h5 class="fw-bold text-dark mb-3">Kategori Buku Populer</h5>
                    <canvas id="kategoriChart" height="130"></canvas>
                    <div class="d-flex flex-wrap gap-2 mt-3 pt-3 border-top">
                        <span class="small text-muted">Diurutkan dari kategori paling sering dipinjam</span>
                    </div>
                    <?php if (empty($kategori_label)): ?>
                        <p class="text-muted small mt-2 mb-0">Belum ada data peminjaman untuk dihitung per kategori.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- GRAFIK TAMBAHAN: BUKU TERPOPULER & DISTRIBUSI LOKASI -->
        <div class="row g-4 mt-1">
            <div class="col-lg-6">
                <div class="chart-card">
                    <h5 class="fw-bold text-dark mb-3">Buku Terpopuler (Top 5 Paling Sering Dipinjam)</h5>
                    <canvas id="bukuPopulerChart" height="150"></canvas>
                    <div class="d-flex flex-wrap gap-2 mt-3 pt-3 border-top">
                        <span class="small text-muted">Diurutkan dari jumlah peminjaman terbanyak</span>
                    </div>
                    <?php if (empty($buku_populer_label)): ?>
                        <p class="text-muted small mt-2 mb-0">Belum ada data peminjaman untuk dihitung.</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="chart-card">
                    <h5 class="fw-bold text-dark mb-3">Distribusi Buku per Lokasi Rak</h5>
                    <canvas id="lokasiChart" height="150"></canvas>
                    <div class="d-flex flex-wrap gap-2 mt-3 pt-3 border-top">
                        <span class="small text-muted">Jumlah judul buku pada tiap lokasi rak</span>
                    </div>
                    <?php if (empty($lokasi_label)): ?>
                        <p class="text-muted small mt-2 mb-0">Belum ada data lokasi rak.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart.js Library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Grafik Batang (Bar Chart)
        const ctxBar = document.getElementById('barChart').getContext('2d');
        new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: ['Buku', 'Anggota', 'Petugas', 'Sedang Dipinjam'],
                datasets: [{
                    label: 'Jumlah Data',
                    data: [<?php echo $jml_buku; ?>, <?php echo $jml_anggota; ?>, <?php echo $jml_petugas; ?>, <?php echo $jml_pinjam; ?>],
                    backgroundColor: ['#0ea5e9', '#22c55e', '#f59e0b', '#ef4444'],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });

        // Grafik Donat (Doughnut Chart)
        const ctxDoughnut = document.getElementById('doughnutChart').getContext('2d');
        new Chart(ctxDoughnut, {
            type: 'doughnut',
            data: {
                labels: ['Sedang Dipinjam', 'Sudah Dikembalikan'],
                datasets: [{
                    data: [<?php echo $jml_pinjam; ?>, <?php echo $jml_kembali; ?>],
                    backgroundColor: ['#ef4444', '#22c55e'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, font: { family: 'Poppins', size: 11 } } }
                }
            }
        });

        // TAMBAHAN: Grafik Trend Peminjaman Bulanan
        const ctxTrend = document.getElementById('trendChart').getContext('2d');
        new Chart(ctxTrend, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($trend_label); ?>,
                datasets: [{
                    label: 'Jumlah Peminjaman',
                    data: <?php echo json_encode($trend_jumlah); ?>,
                    borderColor: '#0284C7',
                    backgroundColor: 'rgba(2, 132, 199, 0.15)',
                    fill: true,
                    tension: 0.3,
                    pointBackgroundColor: '#0284C7'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });

        // TAMBAHAN: Grafik Kategori Buku Populer
        const ctxKategori = document.getElementById('kategoriChart').getContext('2d');
        new Chart(ctxKategori, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($kategori_label); ?>,
                datasets: [{
                    label: 'Jumlah Dipinjam',
                    data: <?php echo json_encode($kategori_jumlah); ?>,
                    backgroundColor: ['#0ea5e9', '#22c55e', '#f59e0b', '#ef4444', '#a855f7'],
                    borderRadius: 8
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });

        // TAMBAHAN: Grafik Buku Terpopuler
        const ctxBukuPopuler = document.getElementById('bukuPopulerChart').getContext('2d');
        new Chart(ctxBukuPopuler, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($buku_populer_label); ?>,
                datasets: [{
                    label: 'Jumlah Dipinjam',
                    data: <?php echo json_encode($buku_populer_jumlah); ?>,
                    backgroundColor: '#0284C7',
                    borderRadius: 8
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });

        // TAMBAHAN: Grafik Distribusi Buku per Lokasi Rak
        const ctxLokasi = document.getElementById('lokasiChart').getContext('2d');
        new Chart(ctxLokasi, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($lokasi_label); ?>,
                datasets: [{
                    data: <?php echo json_encode($lokasi_jumlah); ?>,
                    backgroundColor: ['#0ea5e9', '#22c55e', '#f59e0b', '#ef4444', '#a855f7', '#64748b'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, font: { family: 'Poppins', size: 11 } } }
                }
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>