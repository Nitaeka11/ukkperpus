<?php
/* =========================================================
   KATALOG.PHP — Katalog Buku Anggota (Tema Selaras)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_anggota'])) {
    header("Location: ../login.php");
    exit();
}

$id_anggota = $_SESSION['id_anggota'];
$current_page = basename($_SERVER['PHP_SELF']);

function deteksi_kolom($conn, $tabel, $kandidat) {
    $ada = [];
    $r = mysqli_query($conn, "SHOW COLUMNS FROM `$tabel`");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $ada[] = $row['Field'];
    foreach ($kandidat as $k) {
        if (in_array($k, $ada)) return $k;
    }
    return null;
}

$kolom_nama_anggota = deteksi_kolom($conn, 'anggota', ['nama_anggota', 'nama_lengkap', 'nama', 'username']) ?? 'id_anggota';
$nama_anggota = 'Anggota';
$stmt_nama = mysqli_prepare($conn, "SELECT `$kolom_nama_anggota` AS nama FROM anggota WHERE id_anggota = ?");
mysqli_stmt_bind_param($stmt_nama, "i", $id_anggota);
mysqli_stmt_execute($stmt_nama);
$hasil_nama = mysqli_stmt_get_result($stmt_nama);
if ($rown = mysqli_fetch_assoc($hasil_nama)) {
    $nama_anggota = $rown['nama'];
}

$pencarian = trim($_GET['cari'] ?? '');
if ($pencarian !== '') {
    $keyword = "%" . $pencarian . "%";
    $query = "SELECT * FROM buku WHERE judul_buku LIKE ? OR pengarang LIKE ? OR kode_buku LIKE ? ORDER BY id_buku DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sss", $keyword, $keyword, $keyword);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $query = "SELECT * FROM buku ORDER BY id_buku DESC";
    $result = mysqli_query($conn, $query);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Buku - Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-bg: #121629;
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --bg-body: #f4f5f7;
        }
        body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #1e293b; overflow-x: hidden; }
        .sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; padding-top: 20px; box-shadow: 4px 0 10px rgba(0,0,0,0.05); }
        .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
        .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
        .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
        .sidebar a:hover, .sidebar a.active { color: #fff; background: var(--primary-color); }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; transition: 0.2s; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; padding: 30px; }
        
        .card-custom { background: #ffffff; border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); color: #1e293b; transition: 0.2s; }
        .card-custom:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05); }
        .card-custom h5 { color: #1e293b !important; font-weight: 700; font-size: 1rem; }
        .text-muted { color: #64748b !important; }
        
        .book-cover { width: 100%; height: 210px; background: #f1f5f9; border-radius: 10px; overflow: hidden; display: flex; align-items: center; justify-content: center; margin-bottom: 14px; border: 1px solid #e2e8f0; }
        .book-cover img { width: 100%; height: 100%; object-fit: cover; }
        
        .badge-tersedia { background:#dcfce7; color:#166534; font-size:11px; padding:4px 10px; border-radius:20px; font-weight:600; }
        .badge-habis { background:#fee2e2; color:#7f1d1d; font-size:11px; padding:4px 10px; border-radius:20px; font-weight:600; }
        
        .search-box { background:#ffffff; border:1px solid #cbd5e1; color:#1e293b; border-radius:10px; padding:10px 16px; }
        .search-box:focus { background:#ffffff; border-color:var(--primary-color); box-shadow:none; color:#1e293b; }
        
        .btn-pinjam { background:#f59e0b; border:none; color:#1e293b; font-weight:700; border-radius:8px; }
        .btn-pinjam:hover { background:#d97706; color:#1e293b; }
        .btn-booking { background:transparent; border:1px solid #cbd5e1; color:#475569; font-weight:600; border-radius:8px; }
        .btn-booking:hover { background:#f1f5f9; color:#1e293b; }
        
        h2 { color: #0f172a; font-weight: bold; }
    </style>
</head>
<body>

    <!-- SIDEBAR NAVIGATION -->
    <div class="sidebar">
        <div>
            <h4><i class="fa-solid fa-book-reader text-warning"></i> <?= htmlspecialchars($nama_anggota) ?></h4>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="<?= $current_page=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-house"></i> Dashboard</a>
                <a href="katalog.php" class="<?= $current_page=='katalog.php'?'active':'' ?>"><i class="fa-solid fa-book"></i> Katalog Buku</a>
                <a href="peminjaman.php" class="<?= $current_page=='peminjaman.php'?'active':'' ?>"><i class="fa-solid fa-book-open"></i> Peminjaman</a>
            </div>
        </div>
        <div class="sidebar-footer">
            <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            
            <div class="row align-items-center mb-4">
                <div class="col-md-6">
                    <h2>Katalog Buku</h2>
                    <p class="text-muted mb-0">Temukan buku favoritmu dan lakukan peminjaman atau booking.</p>
                </div>
                <div class="col-md-6">
                    <form method="GET" action="" class="d-flex gap-2 justify-content-md-end mt-3 mt-md-0">
                        <input type="text" name="cari" class="form-control search-box" placeholder="Cari judul, penulis, atau kode buku..." value="<?= htmlspecialchars($pencarian) ?>">
                        <button type="submit" class="btn btn-dark px-4"><i class="fa-solid fa-search"></i></button>
                    </form>
                </div>
            </div>

            <?php if (isset($_SESSION['pesan'])): ?>
                <div class="alert alert-<?= $_SESSION['pesan_tipe'] == 'success' ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($_SESSION['pesan']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['pesan'], $_SESSION['pesan_tipe']); ?>
            <?php endif; ?>

            <div class="row g-4">
                <?php if (mysqli_num_rows($result) === 0): ?>
                    <div class="col-12 text-center py-5">
                        <i class="fa-solid fa-face-sad-tear fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">Buku tidak ditemukan dalam katalog.</h5>
                    </div>
                <?php else: ?>
                    <?php while ($b = mysqli_fetch_assoc($result)): ?>
                        <div class="col-md-4 col-lg-3">
                            <div class="card card-custom p-3 h-100 d-flex flex-column">
                                
                                <div class="book-cover">
                                    <?php 
                                    $nama_file_gambar = $b['id_cover'] ?? '';
                                    $path_gambar = "";

                                    if (!empty($nama_file_gambar)) {
                                        $folder_root = dirname(__DIR__);
                                        if (file_exists($folder_root . "/assets/cover/" . $nama_file_gambar)) {
                                            $path_gambar = "../assets/cover/" . $nama_file_gambar;
                                        } elseif (file_exists($folder_root . "/admin/uploads/" . $nama_file_gambar)) {
                                            $path_gambar = "../admin/uploads/" . $nama_file_gambar;
                                        } elseif (file_exists($folder_root . "/gambar/" . $nama_file_gambar)) {
                                            $path_gambar = "../gambar/" . $nama_file_gambar;
                                        }
                                    }
                                    
                                    if (!empty($path_gambar)): 
                                    ?>
                                        <img src="<?= $path_gambar ?>" alt="Cover Buku">
                                    <?php else: ?>
                                        <div class="text-center text-muted">
                                            <i class="fa-solid fa-book fa-3x mb-1"></i>
                                            <div class="small">No Cover</div>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <h5 class="mb-1 text-truncate" title="<?= htmlspecialchars($b['judul_buku']) ?>">
                                    <?= htmlspecialchars($b['judul_buku']) ?>
                                </h5>
                                <div class="text-muted small mb-3 text-truncate">
                                    <?= htmlspecialchars($b['pengarang'] ?? 'Penulis tidak diketahui') ?>
                                </div>

                                <div class="mt-auto">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <span class="small text-muted">Stok: <strong><?= $b['stok'] ?></strong></span>
                                        <?php if ((int)$b['stok'] > 0): ?>
                                            <span class="badge-tersedia">Tersedia</span>
                                        <?php else: ?>
                                            <span class="badge-habis">Habis</span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="d-flex gap-2">
                                        <form action="proses_peminjaman.php" method="POST" class="flex-grow-1">
                                            <input type="hidden" name="id_buku" value="<?= $b['id_buku'] ?>">
                                            <input type="hidden" name="aksi" value="pinjam">
                                            <button type="submit" class="btn btn-pinjam w-100 btn-sm py-2" <?= (int)$b['stok'] <= 0 ? 'disabled' : '' ?>>
                                                <i class="fa-solid fa-book-open"></i> Pinjam
                                            </button>
                                        </form>

                                        <form action="proses_peminjaman.php" method="POST" class="flex-grow-1">
                                            <input type="hidden" name="id_buku" value="<?= $b['id_buku'] ?>">
                                            <input type="hidden" name="aksi" value="booking">
                                            <button type="submit" class="btn btn-booking w-100 btn-sm py-2">
                                                <i class="fa-solid fa-clock"></i> Booking
                                            </button>
                                        </form>
                                    </div>

                                    <button type="button" class="btn btn-link btn-sm w-100 mt-2 text-decoration-none" style="color:#f59e0b; font-weight:600;"
                                        data-bs-toggle="modal" data-bs-target="#modalUlasan<?= $b['id_buku'] ?>">
                                        <i class="fa-regular fa-star"></i> Beri Ulasan
                                    </button>
                                </div>

                            </div>
                        </div>

                        <!-- Modal Beri Ulasan -->
                        <div class="modal fade" id="modalUlasan<?= $b['id_buku'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="proses_ulasan.php">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Beri Ulasan: <?= htmlspecialchars($b['judul_buku']) ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <input type="hidden" name="id_buku" value="<?= $b['id_buku'] ?>">
                                            <label class="form-label fw-semibold">Rating</label>
                                            <select name="rating" class="form-select mb-3" required>
                                                <option value="5">&#9733;&#9733;&#9733;&#9733;&#9733; (5 - Sangat Bagus)</option>
                                                <option value="4">&#9733;&#9733;&#9733;&#9733; (4 - Bagus)</option>
                                                <option value="3">&#9733;&#9733;&#9733; (3 - Cukup)</option>
                                                <option value="2">&#9733;&#9733; (2 - Kurang)</option>
                                                <option value="1">&#9733; (1 - Buruk)</option>
                                            </select>
                                            <label class="form-label fw-semibold">Komentar</label>
                                            <textarea name="ulasan" class="form-control" rows="3" placeholder="Bagaimana pendapatmu tentang buku ini?" required></textarea>
                                            <small class="text-muted d-block mt-2">Ulasan kamu akan tampil di halaman utama perpustakaan.</small>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-pinjam">Kirim Ulasan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>