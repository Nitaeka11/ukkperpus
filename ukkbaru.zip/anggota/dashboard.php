<?php
/* =========================================================
   DASHBOARD.PHP — Dashboard Anggota/Siswa (Tema Selaras)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_anggota'])) {
    header("Location: ../login.php");
    exit();
}

$id_anggota = $_SESSION['id_anggota'];

function deteksi_kolom($conn, $tabel, $kandidat) {
    $ada = [];
    $r = mysqli_query($conn, "SHOW COLUMNS FROM `$tabel`");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $ada[] = $row['Field'];
    foreach ($kandidat as $k) {
        if (in_array($k, $ada)) return $k;
    }
    return null;
}

$kolom_nama_anggota = deteksi_kolom($conn, 'anggota', ['nama_anggota', 'nama_lengkap', 'nama', 'username']) ?? 'id_anggota';

$nama_anggota = 'Anggota';
$stmt = mysqli_prepare($conn, "SELECT `$kolom_nama_anggota` AS nama FROM anggota WHERE id_anggota = ?");
mysqli_stmt_bind_param($stmt, "i", $id_anggota);
mysqli_stmt_execute($stmt);
$hasil = mysqli_stmt_get_result($stmt);
if ($row = mysqli_fetch_assoc($hasil)) {
    $nama_anggota = $row['nama'];
}

$sedang_dipinjam = 0;
$riwayat_booking = 0;
$total_pengembalian = 0;

$q = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM peminjaman WHERE id_anggota = ? AND status = 'Dipinjam'");
mysqli_stmt_bind_param($q, "i", $id_anggota);
mysqli_stmt_execute($q);
$r = mysqli_stmt_get_result($q);
if ($r) $sedang_dipinjam = mysqli_fetch_assoc($r)['total'];

$q = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM booking WHERE id_anggota = ?");
mysqli_stmt_bind_param($q, "i", $id_anggota);
mysqli_stmt_execute($q);
$r = mysqli_stmt_get_result($q);
if ($r) $riwayat_booking = mysqli_fetch_assoc($r)['total'];

$q = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM peminjaman WHERE id_anggota = ? AND status IN ('Dikembalikan','Selesai')");
mysqli_stmt_bind_param($q, "i", $id_anggota);
mysqli_stmt_execute($q);
$r = mysqli_stmt_get_result($q);
if ($r) $total_pengembalian = mysqli_fetch_assoc($r)['total'];

$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Anggota - Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-bg: #121629;
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --bg-body: #f4f5f7;
        }
        body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #1e293b; overflow-x: hidden; }
        .sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; padding-top: 20px; box-shadow: 4px 0 10px rgba(0,0,0,0.05); }
        .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
        .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
        .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
        .sidebar a:hover, .sidebar a.active { color: #fff; background: var(--primary-color); }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; transition: 0.2s; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card-custom { background: #ffffff; border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); color: #1e293b; }
        .card-custom h3, .card-custom h4, .card-custom h5, .card-custom h6 { color: #1e293b; }
        .text-muted { color: #64748b !important; }
        h2 { color: #0f172a; font-weight: bold; }
    </style>
</head>
<body>

    <!-- SIDEBAR NAVIGATION -->
    <div class="sidebar">
        <div>
            <h4><i class="fa-solid fa-book-reader text-warning"></i> <?= htmlspecialchars($nama_anggota) ?></h4>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="<?= $current_page=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-house"></i> Dashboard</a>
                <a href="katalog.php" class="<?= $current_page=='katalog.php'?'active':'' ?>"><i class="fa-solid fa-book"></i> Katalog Buku</a>
                <a href="peminjaman.php" class="<?= $current_page=='peminjaman.php'?'active':'' ?>"><i class="fa-solid fa-book-open"></i> Peminjaman</a>
            </div>
        </div>
        <div class="sidebar-footer">
            <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Dashboard Anggota</h2>
                <div class="text-end">
                    <span class="badge bg-warning text-dark p-2 px-3 fw-bold">Siswa / Anggota</span>
                </div>
            </div>

            <!-- ========================================================= -->
            <!-- KODE NOTIFIKASI PERINGATAN PENGEMBALIAN BUKU (H-0 & H-1) -->
            <!-- ========================================================= -->
            <?php
            $today = date('Y-m-d');
            $tomorrow = date('Y-m-d', strtotime('+1 day'));

            $sql_notif = "SELECT p.tgl_hrs_kembali, b.judul_buku 
                          FROM peminjaman p 
                          JOIN buku b ON p.id_buku = b.id_buku
                          WHERE p.id_anggota = ? 
                          AND p.status = 'Dipinjam' 
                          AND (p.tgl_hrs_kembali = '$today' OR p.tgl_hrs_kembali = '$tomorrow')";
            
            $stmt_notif = mysqli_prepare($conn, $sql_notif);
            mysqli_stmt_bind_param($stmt_notif, "i", $id_anggota);
            mysqli_stmt_execute($stmt_notif);
            $result_notif = mysqli_stmt_get_result($stmt_notif);

            if ($result_notif && mysqli_num_rows($result_notif) > 0):
            ?>
                <div class="alert alert-warning alert-dismissible fade show border-0 shadow-sm mb-4" style="background-color: #fff3cd; color: #856404; border-left: 5px solid #ffc107 !important; border-radius: 12px;" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="fa-solid fa-triangle-exclamation fa-2x me-3 text-warning">}</i>
                        <div>
                            <h5 class="alert-heading fw-bold mb-1">Peringatan Tenggat Pengembalian Buku!</h5>
                            <p class="mb-2">Halo <strong><?= htmlspecialchars($nama_anggota) ?></strong>, Anda memiliki peminjaman buku yang harus dikembalikan segera:</p>
                            <ul class="mb-0 ps-3">
                                <?php while ($row_n = mysqli_fetch_assoc($result_notif)): ?>
                                    <?php 
                                        $status_waktu = ($row_n['tgl_hrs_kembali'] == $today) ? '<span class="badge bg-danger">Hari Ini!</span>' : '<span class="badge bg-warning text-dark">Besok</span>';
                                    ?>
                                    <li>Judul Buku: <strong><?= htmlspecialchars($row_n['judul_buku']) ?></strong> — Batas Tempo: <?= $row_n['tgl_hrs_kembali'] ?> (<?= $status_waktu ?>)</li>
                                <?php endwhile; ?>
                            </ul>
                            <small class="d-block mt-2 text-secondary">Harap segera mengembalikan buku ke perpustakaan untuk menghindari denda.</small>
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <!-- ========================================================= -->

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card card-custom p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted">Buku Sedang Dipinjam</h6>
                                <h3 class="fw-bold mt-2"><?= $sedang_dipinjam ?></h3>
                            </div>
                            <i class="fa-solid fa-book fa-2x text-primary"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-custom p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted">Riwayat Booking</h6>
                                <h3 class="fw-bold mt-2"><?= $riwayat_booking ?></h3>
                            </div>
                            <i class="fa-solid fa-clock-rotate-left fa-2x text-warning"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-custom p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted">Total Pengembalian</h6>
                                <h3 class="fw-bold mt-2"><?= $total_pengembalian ?></h3>
                            </div>
                            <i class="fa-solid fa-circle-check fa-2x text-success"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card card-custom mt-4 p-4 border-start border-warning border-4">
                <h4 class="fw-bold text-dark">Selamat Datang, <?= htmlspecialchars($nama_anggota) ?>!</h4>
                <p class="text-muted mb-0">Silakan gunakan menu di samping untuk melihat katalog buku, status peminjaman, mengajukan booking, atau mengecek riwayat pengembalian buku perpustakaan.</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>