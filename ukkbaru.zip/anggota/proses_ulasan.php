<?php
/* =========================================================
   PROSES_ULASAN.PHP — Simpan Rating & Komentar Buku
   (Deteksi otomatis nama kolom, menyesuaikan skema tabel asli)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_anggota'])) {
    header("Location: ../login.php");
    exit();
}

$id_anggota = $_SESSION['id_anggota'];
$id_buku    = (int) ($_POST['id_buku'] ?? 0);
$rating     = (int) ($_POST['rating'] ?? 0);
$teks_ulasan = trim($_POST['ulasan'] ?? '');

function kembali_dengan_pesan($tipe, $pesan) {
    $_SESSION['pesan']      = $pesan;
    $_SESSION['pesan_tipe'] = $tipe;
    header("Location: katalog.php");
    exit();
}

if (!$id_buku || $rating < 1 || $rating > 5) {
    kembali_dengan_pesan('error', 'Rating tidak valid.');
}

// --- Deteksi kolom yang benar-benar ada di tabel ulasan ---
$kolom_ada = [];
$r = mysqli_query($conn, "SHOW COLUMNS FROM ulasan");
if ($r) while ($row = mysqli_fetch_assoc($r)) $kolom_ada[] = $row['Field'];

// Nama kolom teks ulasan: coba 'ulasan' dulu (sesuai index.php), fallback 'komentar'
$kolom_teks = in_array('ulasan', $kolom_ada) ? 'ulasan' : (in_array('komentar', $kolom_ada) ? 'komentar' : null);
$punya_id_buku = in_array('id_buku', $kolom_ada);
$punya_tanggal = in_array('tanggal', $kolom_ada);

if (!$kolom_teks) {
    kembali_dengan_pesan('error', 'Struktur tabel ulasan tidak dikenali (kolom teks ulasan tidak ditemukan).');
}

// --- Susun query INSERT secara dinamis sesuai kolom yang tersedia ---
$kolom_insert = ['id_anggota', 'rating', $kolom_teks];
$placeholder  = ['?', '?', '?'];
$tipe_data    = 'ii' . 's';
$nilai        = [$id_anggota, $rating, $teks_ulasan];

if ($punya_id_buku) {
    $kolom_insert[] = 'id_buku';
    $placeholder[]  = '?';
    $tipe_data     .= 'i';
    $nilai[]        = $id_buku;
}
if ($punya_tanggal) {
    $kolom_insert[] = 'tanggal';
    $placeholder[]  = 'NOW()';
}

// Cek apakah sudah pernah kasih ulasan untuk buku ini (kalau kolom id_buku ada)
if ($punya_id_buku) {
    $cek = mysqli_prepare($conn, "SELECT id_ulasan FROM ulasan WHERE id_anggota = ? AND id_buku = ?");
    mysqli_stmt_bind_param($cek, "ii", $id_anggota, $id_buku);
    mysqli_stmt_execute($cek);
    $ada = mysqli_fetch_assoc(mysqli_stmt_get_result($cek));

    if ($ada) {
        // Update ulasan yang sudah ada
        $set_tgl = $punya_tanggal ? ", tanggal = NOW()" : "";
        $stmt = mysqli_prepare($conn, "UPDATE ulasan SET rating = ?, `$kolom_teks` = ?$set_tgl WHERE id_ulasan = ?");
        mysqli_stmt_bind_param($stmt, "isi", $rating, $teks_ulasan, $ada['id_ulasan']);
        if (mysqli_stmt_execute($stmt)) {
            kembali_dengan_pesan('success', 'Ulasan kamu berhasil diperbarui. Terima kasih!');
        } else {
            kembali_dengan_pesan('error', 'Gagal memperbarui ulasan: ' . mysqli_error($conn));
        }
    }
}

$sql = "INSERT INTO ulasan (" . implode(', ', $kolom_insert) . ") VALUES (" . implode(', ', $placeholder) . ")";
$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    kembali_dengan_pesan('error', 'Gagal menyiapkan query ulasan: ' . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, $tipe_data, ...$nilai);

if (mysqli_stmt_execute($stmt)) {
    kembali_dengan_pesan('success', 'Terima kasih, ulasan kamu berhasil disimpan dan akan tampil di halaman utama.');
} else {
    kembali_dengan_pesan('error', 'Gagal menyimpan ulasan: ' . mysqli_error($conn));
}