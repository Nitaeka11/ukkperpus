<?php
/* =========================================================
   NOTIFIKASI.PHP — Kelola & Validasi Booking (Admin)
   Data diambil dari tabel `booking` (bukan `peminjaman`)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

$nama_admin = $_SESSION['nama'] ?? 'Administrator';
$current_page = basename($_SERVER['PHP_SELF']);

// Ambil daftar booking yang masih menunggu persetujuan
$query = mysqli_query($conn, "SELECT * FROM booking WHERE status = 'Menunggu' ORDER BY tanggal_booking DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi Admin - Sistem Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-bg: #121629;
            --primary-color: #4f46e5;
            --bg-body: #f4f5f7;
        }
        body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; padding-top: 20px; }
        .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
        .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
        .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
        .sidebar a:hover, .sidebar a.active { color: #fff; background: var(--primary-color); }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.03); border-radius: 15px; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div>
            <h4><i class="fa-solid fa-shield-halved text-warning"></i> Admin Panel</h4>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="<?= $current_page=='dashboard.php'?'active':'' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
                <a href="buku.php" class="<?= $current_page=='buku.php'?'active':'' ?>"><i class="fas fa-book"></i> Data Buku</a>
                <a href="anggota.php" class="<?= $current_page=='anggota.php'?'active':'' ?>"><i class="fas fa-users"></i> Data Anggota</a>
                <a href="notifikasi.php" class="<?= $current_page=='notifikasi.php'?'active':'' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
                <a href="laporan.php" class="<?= $current_page=='laporan.php'?'active':'' ?>"><i class="fas fa-file-alt"></i> Laporan</a>
            </div>
        </div>
        <div class="sidebar-footer">
            <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
    </div>

    <div class="main-content">
        <div class="container-fluid">
            <h3 class="fw-bold mb-1">Kelola & Validasi Booking Buku</h3>
            <p class="text-muted mb-4">Pengajuan booking dari anggota yang menunggu persetujuan.</p>

            <?php if (isset($_SESSION['pesan'])): ?>
                <div class="alert alert-<?= $_SESSION['pesan_tipe'] == 'success' ? 'success' : 'danger' ?> alert-dismissible fade show">
                    <?= htmlspecialchars($_SESSION['pesan']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['pesan'], $_SESSION['pesan_tipe']); ?>
            <?php endif; ?>

            <div class="card p-3">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Kode Booking</th>
                                <th>Nama Anggota</th>
                                <th>Judul Buku</th>
                                <th>Waktu Booking</th>
                                <th>Batas Ambil</th>
                                <th class="text-end">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($query && mysqli_num_rows($query) > 0): ?>
                                <?php $no = 1; while ($row = mysqli_fetch_assoc($query)): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><span class="badge bg-dark"><?= htmlspecialchars($row['kode_booking']) ?></span></td>
                                    <td><strong><?= htmlspecialchars($row['nama_anggota']) ?></strong></td>
                                    <td><?= htmlspecialchars($row['judul_buku']) ?></td>
                                    <td><?= htmlspecialchars($row['tanggal_booking']) ?></td>
                                    <td><?= htmlspecialchars($row['batas_ambil'] ?? '-') ?></td>
                                    <td class="text-end">
                                        <a href="proses_setujui_booking.php?id=<?= $row['id_booking'] ?>"
                                           class="btn btn-success btn-sm"
                                           onclick="return confirm('Setujui booking ini? Buku akan berpindah ke status Dipinjam.');">
                                            <i class="fa-solid fa-check"></i> Setujui
                                        </a>
                                        <a href="proses_tolak_booking.php?id=<?= $row['id_booking'] ?>"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Tolak booking ini?');">
                                            <i class="fa-solid fa-xmark"></i> Tolak
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">Belum ada pengajuan booking baru dari anggota.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>