<?php
/* =========================================================
   PEMINJAMAN.PHP — Peminjaman & Booking Aktif (Tema Selaras)
   Menggabungkan data dari 2 tabel: peminjaman (Dipinjam) + booking (Menunggu)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_anggota'])) {
    header("Location: ../login.php");
    exit();
}

$id_anggota = $_SESSION['id_anggota'];
$current_page = basename($_SERVER['PHP_SELF']);

function deteksi_kolom($conn, $tabel, $kandidat) {
    $ada = [];
    $r = mysqli_query($conn, "SHOW COLUMNS FROM `$tabel`");
    if ($r) while ($row = mysqli_fetch_assoc($r)) $ada[] = $row['Field'];
    foreach ($kandidat as $k) {
        if (in_array($k, $ada)) return $k;
    }
    return null;
}

$kolom_nama_anggota = deteksi_kolom($conn, 'anggota', ['nama_anggota', 'nama_lengkap', 'nama', 'username']) ?? 'id_anggota';
$nama_anggota = 'Anggota';
$stmt_nama = mysqli_prepare($conn, "SELECT `$kolom_nama_anggota` AS nama FROM anggota WHERE id_anggota = ?");
mysqli_stmt_bind_param($stmt_nama, "i", $id_anggota);
mysqli_stmt_execute($stmt_nama);
$hasil_nama = mysqli_stmt_get_result($stmt_nama);
if ($rown = mysqli_fetch_assoc($hasil_nama)) {
    $nama_anggota = $rown['nama'];
}

// --- 1. Buku sedang dipinjam (tabel peminjaman) ---
$daftar = [];

$q1 = mysqli_prepare($conn, "SELECT p.id_peminjaman, b.kode_buku, b.judul_buku, p.tgl_pinjam, p.tgl_hrs_kembali, 'Dipinjam' AS tipe
                              FROM peminjaman p
                              JOIN buku b ON p.id_buku = b.id_buku
                              WHERE p.id_anggota = ? AND p.status = 'Dipinjam'
                              ORDER BY p.id_peminjaman DESC");
mysqli_stmt_bind_param($q1, "i", $id_anggota);
mysqli_stmt_execute($q1);
$r1 = mysqli_stmt_get_result($q1);
while ($row = mysqli_fetch_assoc($r1)) $daftar[] = $row;

// --- 2. Booking menunggu (tabel booking terpisah) ---
$q2 = mysqli_prepare($conn, "SELECT id_booking, kode_buku, judul_buku, tanggal_booking AS tgl_pinjam, tanggal_jatuh_tempo AS tgl_hrs_kembali, 'Menunggu' AS tipe
                              FROM booking
                              WHERE id_anggota = ? AND status = 'Menunggu'
                              ORDER BY id_booking DESC");
mysqli_stmt_bind_param($q2, "i", $id_anggota);
mysqli_stmt_execute($q2);
$r2 = mysqli_stmt_get_result($q2);
while ($row = mysqli_fetch_assoc($r2)) $daftar[] = $row;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Aktif - Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-bg: #121629;
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --bg-body: #f4f5f7;
        }
        body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #1e293b; overflow-x: hidden; }
        .sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; padding-top: 20px; box-shadow: 4px 0 10px rgba(0,0,0,0.05); }
        .sidebar h4 { color: #fff; text-align: center; font-weight: bold; margin-bottom: 30px; font-size: 1.1rem; padding: 0 15px; }
        .sidebar-menu { padding: 0 15px; flex-grow: 1; list-style: none; margin: 0; }
        .sidebar a { padding: 12px 15px; text-decoration: none; font-size: 15px; color: #94a3b8; display: flex; align-items: center; gap: 12px; transition: 0.3s; border-radius: 10px; margin-bottom: 5px; font-weight: 500; }
        .sidebar a:hover, .sidebar a.active { color: #fff; background: var(--primary-color); }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; transition: 0.2s; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card-custom { background: #ffffff; border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); color: #1e293b; }
        .table { color: #1e293b; }
        .table td, .table th { border-color: #e2e8f0; background-color: transparent !important; color: #1e293b !important; }
        .text-muted { color: #64748b !important; }
        h2 { color: #0f172a; font-weight: bold; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div>
            <h4><i class="fa-solid fa-book-reader text-warning"></i> <?= htmlspecialchars($nama_anggota) ?></h4>
            <div class="sidebar-menu">
                <a href="dashboard.php" class="<?= $current_page=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-house"></i> Dashboard</a>
                <a href="katalog.php" class="<?= $current_page=='katalog.php'?'active':'' ?>"><i class="fa-solid fa-book"></i> Katalog Buku</a>
                <a href="peminjaman.php" class="<?= $current_page=='peminjaman.php'?'active':'' ?>"><i class="fa-solid fa-book-open"></i> Peminjaman</a>
            </div>
        </div>
        <div class="sidebar-footer">
            <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
    </div>

    <div class="main-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="mb-0">Buku Sedang Dipinjam & Booking Aktif</h2>
                <span class="badge bg-warning text-dark p-2 px-3 fw-bold">Siswa / Anggota</span>
            </div>
            <div class="card card-custom p-4">
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode Buku</th>
                                <th>Judul Buku</th>
                                <th>Tanggal</th>
                                <th>Batas / Jatuh Tempo</th>
                                <th>Status</th>
                                <th class="text-end">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($daftar) === 0): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">Tidak ada buku yang sedang dipinjam atau di-booking saat ini.</td>
                                </tr>
                            <?php else: ?>
                                <?php $no = 1; foreach ($daftar as $row): ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= htmlspecialchars($row['kode_buku']) ?></td>
                                        <td><?= htmlspecialchars($row['judul_buku']) ?></td>
                                        <td><?= htmlspecialchars(substr($row['tgl_pinjam'], 0, 10)) ?></td>
                                        <td><?= htmlspecialchars($row['tgl_hrs_kembali'] ?? '-') ?></td>
                                        <td>
                                            <?php if ($row['tipe'] == 'Dipinjam'): ?>
                                                <span class="badge bg-primary">Dipinjam</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">Menunggu Persetujuan</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <?php if ($row['tipe'] == 'Dipinjam'): ?>
                                                <form method="POST" action="proses_pengembalian.php" onsubmit="return confirm('Konfirmasi pengembalian buku ini?')">
                                                    <input type="hidden" name="id_peminjaman" value="<?= $row['id_peminjaman'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-warning fw-bold">
                                                        <i class="fa-solid fa-rotate-left"></i> Kembalikan
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-muted small">Menunggu petugas</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>