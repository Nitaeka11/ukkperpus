<?php
/* =========================================================
   PROSES_PEMINJAMAN.PHP — Aksi Pinjam & Booking dari Katalog
   Disesuaikan dengan skema asli:
   - Pinjam  -> INSERT ke tabel `peminjaman` (langsung dipinjam)
   - Booking -> INSERT ke tabel `booking` terpisah (menunggu diambil)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['id_anggota'])) {
    header("Location: ../login.php");
    exit();
}

$id_anggota = $_SESSION['id_anggota'];
$id_buku    = (int) ($_POST['id_buku'] ?? 0);
$aksi       = $_POST['aksi'] ?? '';

function kembali_dengan_pesan($tipe, $pesan) {
    $_SESSION['pesan']      = $pesan;
    $_SESSION['pesan_tipe'] = $tipe;
    header("Location: katalog.php");
    exit();
}

if (!$id_buku || !in_array($aksi, ['pinjam', 'booking'])) {
    kembali_dengan_pesan('error', 'Permintaan tidak valid.');
}

// Cek apakah anggota sudah punya peminjaman aktif untuk buku yang sama
$cek = mysqli_prepare($conn, "SELECT id_peminjaman FROM peminjaman WHERE id_anggota = ? AND id_buku = ? AND status = 'Dipinjam'");
mysqli_stmt_bind_param($cek, "ii", $id_anggota, $id_buku);
mysqli_stmt_execute($cek);
if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {
    kembali_dengan_pesan('error', 'Kamu sedang meminjam buku ini.');
}

// Cek apakah anggota sudah punya booking aktif (menunggu) untuk buku yang sama
$cek_booking = mysqli_prepare($conn, "SELECT id_booking FROM booking WHERE id_anggota = ? AND id_buku = ? AND status = 'Menunggu'");
mysqli_stmt_bind_param($cek_booking, "ii", $id_anggota, $id_buku);
mysqli_stmt_execute($cek_booking);
if (mysqli_num_rows(mysqli_stmt_get_result($cek_booking)) > 0) {
    kembali_dengan_pesan('error', 'Kamu sudah punya booking aktif untuk buku ini.');
}

// Ambil data buku
$cek_stok = mysqli_prepare($conn, "SELECT stok, judul_buku, kode_buku FROM buku WHERE id_buku = ?");
mysqli_stmt_bind_param($cek_stok, "i", $id_buku);
mysqli_stmt_execute($cek_stok);
$buku = mysqli_fetch_assoc(mysqli_stmt_get_result($cek_stok));

if (!$buku) {
    kembali_dengan_pesan('error', 'Buku tidak ditemukan.');
}

if ($aksi === 'pinjam') {

    if ((int) $buku['stok'] <= 0) {
        kembali_dengan_pesan('error', 'Stok buku sedang habis.');
    }

    mysqli_begin_transaction($conn);
    try {
        $tgl_pinjam      = date('Y-m-d');
        $tgl_hrs_kembali = date('Y-m-d', strtotime('+7 days')); // jatuh tempo 7 hari

        $stmt = mysqli_prepare($conn, "INSERT INTO peminjaman
            (id_anggota, id_buku, tgl_pinjam, tgl_hrs_kembali, status, kondisi_buku, denda_per_hari)
            VALUES (?, ?, ?, ?, 'Dipinjam', 'Baik', 1000)");
        mysqli_stmt_bind_param($stmt, "iiss", $id_anggota, $id_buku, $tgl_pinjam, $tgl_hrs_kembali);
        mysqli_stmt_execute($stmt);

        $update_stok = mysqli_prepare($conn, "UPDATE buku SET stok = stok - 1 WHERE id_buku = ? AND stok > 0");
        mysqli_stmt_bind_param($update_stok, "i", $id_buku);
        mysqli_stmt_execute($update_stok);

        mysqli_commit($conn);
        kembali_dengan_pesan('success', "Berhasil meminjam buku \"{$buku['judul_buku']}\". Batas kembali: " . date('d-m-Y', strtotime($tgl_hrs_kembali)) . ".");
    } catch (Throwable $e) {
        mysqli_rollback($conn);
        kembali_dengan_pesan('error', 'Gagal memproses peminjaman: ' . $e->getMessage());
    }

} else {
    // ==== BOOKING: masuk ke tabel `booking` terpisah, menunggu diambil ====

    // Ambil nama anggota untuk kolom denormalized nama_anggota
    $nama_anggota = 'Anggota';
    $q_nama = mysqli_prepare($conn, "SELECT nama_lengkap FROM anggota WHERE id_anggota = ?");
    mysqli_stmt_bind_param($q_nama, "i", $id_anggota);
    mysqli_stmt_execute($q_nama);
    $r_nama = mysqli_fetch_assoc(mysqli_stmt_get_result($q_nama));
    if ($r_nama) $nama_anggota = $r_nama['nama_lengkap'];

    $kode_booking      = 'BKG-' . date('YmdHis') . rand(10, 99);
    $tanggal_booking   = date('Y-m-d H:i:s');
    $batas_ambil       = date('Y-m-d', strtotime('+2 days'));   // batas waktu ambil buku setelah disetujui
    $tanggal_jatuh_tempo = date('Y-m-d', strtotime('+9 days')); // perkiraan batas kembali kalau nanti dipinjam

    try {
        $stmt = mysqli_prepare($conn, "INSERT INTO booking
            (kode_booking, id_anggota, nama_anggota, id_buku, kode_buku, judul_buku, tanggal_booking, batas_ambil, tanggal_jatuh_tempo, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Menunggu')");
        mysqli_stmt_bind_param($stmt, "sisisssss",
            $kode_booking, $id_anggota, $nama_anggota, $id_buku, $buku['kode_buku'], $buku['judul_buku'],
            $tanggal_booking, $batas_ambil, $tanggal_jatuh_tempo
        );
        mysqli_stmt_execute($stmt);

        // Notifikasi otomatis untuk petugas: ada booking baru masuk
        $cek_notif = mysqli_query($conn, "SHOW TABLES LIKE 'notifikasi'");
        if (mysqli_num_rows($cek_notif) == 0) {
            mysqli_query($conn, "CREATE TABLE notifikasi (
                id_notif INT AUTO_INCREMENT PRIMARY KEY,
                judul VARCHAR(255) NOT NULL,
                pesan TEXT,
                tipe VARCHAR(50) DEFAULT 'umum',
                status VARCHAR(50) DEFAULT 'belum_dibaca',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
        $judul_notif = 'Booking Baru Masuk';
        $pesan_notif = "$nama_anggota mengajukan booking untuk buku \"{$buku['judul_buku']}\" (kode: $kode_booking).";
        $stmt_notif = mysqli_prepare($conn, "INSERT INTO notifikasi (judul, pesan, tipe, status, created_at) VALUES (?, ?, 'booking', 'belum_dibaca', NOW())");
        mysqli_stmt_bind_param($stmt_notif, "ss", $judul_notif, $pesan_notif);
        mysqli_stmt_execute($stmt_notif);

        kembali_dengan_pesan('success', "Booking untuk \"{$buku['judul_buku']}\" berhasil diajukan (kode: $kode_booking). Menunggu persetujuan petugas.");
    } catch (Throwable $e) {
        kembali_dengan_pesan('error', 'Gagal mengajukan booking: ' . $e->getMessage());
    }
}