<?php
session_start();
include '../config/koneksi.php';

// Pastikan petugas sudah login
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("Location: ../login.php");
    exit;
}

$koneksi = $conn; // alias supaya query di bawah (yang sudah pakai $koneksi) tetap jalan tanpa diubah semua

// Auto-create tabel notifikasi jika belum ada
$cek_notif = mysqli_query($koneksi, "SHOW TABLES LIKE 'notifikasi'");
if (mysqli_num_rows($cek_notif) == 0) {
    mysqli_query($koneksi, "CREATE TABLE notifikasi (
        id_notif INT AUTO_INCREMENT PRIMARY KEY,
        judul VARCHAR(255) NOT NULL,
        pesan TEXT,
        tipe VARCHAR(50) DEFAULT 'umum',
        status VARCHAR(50) DEFAULT 'belum_dibaca',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

// Cek apakah tabel pesan_bantuan punya kolom id_petugas
$cek_kolom = mysqli_query($koneksi, "SHOW COLUMNS FROM pesan_bantuan LIKE 'id_petugas'");
if (mysqli_num_rows($cek_kolom) == 0) {
    mysqli_query($koneksi, "ALTER TABLE pesan_bantuan ADD COLUMN id_petugas INT NULL AFTER status");
}

if (isset($_GET['id'])) {
    $id_pesan = intval($_GET['id']);
    $id_petugas = $_SESSION['id_petugas'] ?? 0;
    $nama_petugas = $_SESSION['nama'] ?? 'Petugas';

    // Ambil data pesan untuk notifikasi
    $q_pesan = mysqli_query($koneksi, "SELECT * FROM pesan_bantuan WHERE id_pesan = $id_pesan");
    $data_pesan = mysqli_fetch_assoc($q_pesan);

    // Update status dan id_petugas
    $query = "UPDATE pesan_bantuan SET status = 'Diproses', id_petugas = $id_petugas WHERE id_pesan = $id_pesan";

    if (mysqli_query($koneksi, $query)) {
        // ✅ INSERT NOTIFIKASI
        if ($data_pesan) {
            $nama_pengirim = $data_pesan['nama'] ?? 'Seseorang';
            $notif_judul = "Pesan Bantuan Diproses";
            $notif_pesan = "Pesan bantuan dari $nama_pengirim telah ditindaklanjuti oleh $nama_petugas. Status: Diproses.";
            mysqli_query($koneksi, "INSERT INTO notifikasi (judul, pesan, tipe, status, created_at) VALUES ('$notif_judul', '$notif_pesan', 'bantuan', 'belum_dibaca', NOW())");
        }

        header("Location: admin_pesan.php?status=sukses");
        exit;
    } else {
        echo "Gagal memperbarui data: " . mysqli_error($koneksi);
    }
} else {
    header("Location: admin_pesan.php");
    exit;
}
?>