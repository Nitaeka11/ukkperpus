<?php
/* =========================================================
   TRANSAKSI.PHP — Riwayat Transaksi Peminjaman (Petugas)
   FIX: Tombol Kembalikan jalan, update tanggal_dikembalikan,
        struktur sidebar rapi, semua styling asli tetap.
   ========================================================= */

session_start();
include "../config/koneksi.php";

// --- 1. Proteksi login ---
if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}
$nama_petugas = $_SESSION['nama_petugas'] ?? 'Petugas';
$current_page = basename($_SERVER['PHP_SELF']);

// Auto-create tabel notifikasi jika belum ada
$cek_notif = mysqli_query($conn, "SHOW TABLES LIKE 'notifikasi'");
if (mysqli_num_rows($cek_notif) == 0) {
    mysqli_query($conn, "CREATE TABLE notifikasi (
        id_notif INT AUTO_INCREMENT PRIMARY KEY,
        judul VARCHAR(255) NOT NULL,
        pesan TEXT,
        tipe VARCHAR(50) DEFAULT 'umum',
        status VARCHAR(50) DEFAULT 'belum_dibaca',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

// --- 2. PROSES KEMBALIKAN BUKU ---
if (isset($_GET['aksi']) && $_GET['aksi'] === 'kembalikan' && isset($_GET['id'])) {
    $id_peminjaman = intval($_GET['id']);

    // Ambil data untuk notifikasi
    $q_data = mysqli_query($conn, "SELECT p.*, a.nama_lengkap, b.judul_buku 
        FROM peminjaman p 
        LEFT JOIN anggota a ON p.id_anggota = a.id_anggota 
        LEFT JOIN buku b ON p.id_buku = b.id_buku 
        WHERE p.id_peminjaman = $id_peminjaman");
    $data = mysqli_fetch_assoc($q_data);

    // FIX: Update status + tanggal_dikembalikan
    $update = mysqli_query($conn, "UPDATE peminjaman 
        SET status = 'Dikembalikan', tanggal_dikembalikan = NOW() 
        WHERE id_peminjaman = $id_peminjaman");

    if ($update) {
        // INSERT NOTIFIKASI pengembalian
        if ($data) {
            $nama = $data['nama_lengkap'] ?? 'Anggota';
            $judul_buku = $data['judul_buku'] ?? 'Buku';
            mysqli_query($conn, "INSERT INTO notifikasi (judul, pesan, tipe, status, created_at) 
                VALUES ('Buku Dikembalikan', '$nama telah mengembalikan buku \"$judul_buku\".', 'pengembalian', 'belum_dibaca', NOW())");
        }
        header("Location: transaksi.php?status=Dikembalikan&notif=sukses_kembali");
        exit();
    }
}

// --- 3. Deteksi otomatis nama kolom "nama" di tabel anggota ---
$kolom_nama_anggota = null;
$kandidat_kolom = ['nama_anggota', 'nama_lengkap', 'nama', 'username'];
$hasil_kolom = mysqli_query($conn, "SHOW COLUMNS FROM anggota");
$kolom_tersedia = [];
if ($hasil_kolom) {
    while ($k = mysqli_fetch_assoc($hasil_kolom)) {
        $kolom_tersedia[] = $k['Field'];
    }
}
foreach ($kandidat_kolom as $kandidat) {
    if (in_array($kandidat, $kolom_tersedia)) {
        $kolom_nama_anggota = $kandidat;
        break;
    }
}
$select_nama_anggota = $kolom_nama_anggota ? "a.`$kolom_nama_anggota` AS nama_anggota" : "a.id_anggota AS nama_anggota";

// --- 4. Filter status ---
$filter_status = $_GET['status'] ?? '';
$sql = "SELECT p.*, $select_nama_anggota, b.judul_buku
        FROM peminjaman p
        LEFT JOIN anggota a ON p.id_anggota = a.id_anggota
        LEFT JOIN buku b ON p.id_buku = b.id_buku";
$params = [];
$types  = '';
if ($filter_status !== '') {
    $sql .= " WHERE p.status = ?";
    $params[] = $filter_status;
    $types .= 's';
}
$sql .= " ORDER BY p.tgl_pinjam DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$data_transaksi = mysqli_stmt_get_result($stmt);

// --- 5. Hitung notifikasi belum dibaca untuk badge ---
$q_notif_belum = mysqli_query($conn, "SELECT COUNT(*) as jml FROM notifikasi WHERE status = 'belum_dibaca'");
$notif_belum_dibaca = mysqli_fetch_assoc($q_notif_belum)['jml'] ?? 0;

// Inisial nama petugas
$words = explode(" ", $nama_petugas);
$inisial = strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transaksi - Petugas Perpustakaan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --bg-sidebar: #151B2D; --accent: #6366f1; --bg-content: #F5F7FB;
    --card-bg: #FFFFFF; --text-main: #1E293B; --text-muted-custom: #94A3B8; --border-light: #F1F5F9;
}
* { box-sizing: border-box; }
body { background: var(--bg-content); color: var(--text-main); font-family:'Segoe UI',Arial,sans-serif; margin:0; }
.sidebar { width:260px; height:100vh; position:fixed; top:0; left:0; background:var(--bg-sidebar); padding:24px 16px; display:flex; flex-direction:column; z-index:1000; overflow-y:auto; }
.sidebar .brand { display:flex; align-items:center; gap:12px; padding:8px 12px; margin-bottom:26px; }
.sidebar .brand-icon { width:42px; height:42px; background:var(--accent); border-radius:12px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:1.2rem; }
.sidebar .brand h6 { color:#fff; margin-bottom:0; }
.sidebar .brand small { color:var(--text-muted-custom); }
.sidebar .nav.flex-column { list-style:none; padding:0; margin:0; flex-grow:1; }
.sidebar .nav-item { margin-bottom:6px; list-style:none; }
.sidebar .nav-item a { display:flex; align-items:center; gap:14px; padding:13px 16px; color:var(--text-muted-custom); text-decoration:none; font-size:14.5px; font-weight:500; border-radius:12px; transition:.2s; }
.sidebar .nav-item a:hover { background:rgba(99,102,241,.15); color:#fff; }
.sidebar .nav-item a.active { background:var(--accent); color:#fff; box-shadow:0 4px 15px rgba(79,70,229,.4); }
.sidebar .logout-btn { color:#f87171 !important; }
.sidebar .logout-btn:hover { background:rgba(239,68,68,.15) !important; }
.main-content { margin-left:260px; padding:30px 34px; min-height:100vh; }
.content-card { background:var(--card-bg); border-radius:16px; padding:24px; box-shadow:0 4px 20px rgba(0,0,0,.03); border:1px solid var(--border-light); margin-bottom:25px; }
.table-light-custom thead th { background:#f8fafc; color:#475569; font-size:11.5px; text-transform:uppercase; letter-spacing:.03em; padding:12px 15px; border-bottom:2px solid var(--border-light); }
.table-light-custom tbody td { padding:14px 15px; color:var(--text-main); border-bottom:1px solid var(--border-light); font-size:14px; vertical-align:middle; }
.form-select-custom { border-radius:10px; border:1px solid #E2E8F0; padding:8px 14px; font-size:13.5px; min-width:170px; }
.id-badge { background:#0f172a; color:#f8fafc; padding:5px 10px; border-radius:6px; font-size:12.5px; font-weight:700; }

/* Notifikasi Bell */
.notif-bell-wrapper { position: relative; }
.badge-notif-count {
    position: absolute; top: -8px; right: -8px;
    background: #ef4444; color: #fff;
    font-size: 10px; font-weight: 700;
    min-width: 18px; height: 18px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    border: 2px solid #fff;
    animation: pulseNotif 2s infinite;
}
@keyframes pulseNotif { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.15); } }

/* FIX: Tombol Kembalikan styling */
.btn-kembalikan {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 16px; border-radius: 50px;
    border: 1px solid #22c55e; background: #fff;
    color: #16a34a; font-size: 13px; font-weight: 500;
    text-decoration: none; transition: all .2s;
}
.btn-kembalikan:hover { background: #22c55e; color: #fff; }
.btn-kembalikan i { font-size: 12px; }

@media (max-width:900px){ .sidebar{width:220px;} .main-content{margin-left:220px; padding:20px;} }
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="brand">
        <div class="brand-icon"><i class="fa-solid fa-book-open"></i></div>
        <div><h6 class="mb-0 fw-bold">Petugas</h6><small>Perpustakaan</small></div>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a></li>
        <li class="nav-item"><a href="kondisi.php"><i class="fa-solid fa-clipboard-check"></i> Cek Kondisi Buku</a></li>
        <li class="nav-item"><a href="transaksi.php" class="<?= $current_page=='transaksi.php'?'active':'' ?>"><i class="fa-solid fa-right-left"></i> Transaksi</a></li>
        <li class="nav-item"><a href="booking.php"><i class="fa-solid fa-calendar-days"></i> Kelola Booking</a></li>
        <li class="nav-item">
            <a href="notifikasi.php">
                <i class="fa-solid fa-bell"></i> Notifikasi
                <?php if ($notif_belum_dibaca > 0): ?>
                <span class="badge bg-danger rounded-pill ms-1" style="font-size:10px;"><?= $notif_belum_dibaca ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li class="nav-item"><a href="profil.php"><i class="fa-solid fa-user"></i> Profil Saya</a></li>
    </ul>
    <!-- FIX: Logout di luar <ul> supaya struktur rapi -->
    <div class="mt-auto">
        <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');" class="logout-btn d-flex align-items-center gap-3 text-decoration-none" style="padding:13px 16px; font-size:14.5px; font-weight:500; border-radius:12px;">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
        </a>
    </div>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">

    <!-- Top bar -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Riwayat Transaksi</h2>
            <p class="small mb-0" style="color:var(--text-muted-custom);">
                Semua transaksi peminjaman buku — menunggu, sedang dipinjam, maupun sudah selesai.
            </p>
        </div>
        <div class="d-flex align-items-center gap-3">
            <!-- Notifikasi Bell -->
            <div class="notif-bell-wrapper">
                <a href="notifikasi.php" class="text-dark text-decoration-none fs-4 position-relative">
                    <i class="far fa-bell"></i>
                    <?php if ($notif_belum_dibaca > 0): ?>
                    <span class="badge-notif-count"><?= $notif_belum_dibaca ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <!-- Profile -->
            <div class="d-flex align-items-center gap-2">
                <span class="badge bg-primary rounded-circle p-2"><?= $inisial ?></span>
                <span class="fw-bold text-dark small"><?= htmlspecialchars($nama_petugas) ?></span>
            </div>
        </div>
    </div>

    <!-- Notifikasi Sukses -->
    <?php if (isset($_GET['notif']) && $_GET['notif'] === 'sukses_kembali'): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-3" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> Buku berhasil dikembalikan! Notifikasi telah dicatat.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="content-card">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
            <div>
                <h5 class="fw-bold mb-1">Daftar Transaksi</h5>
                <p class="small mb-0 text-muted">Klik tombol "Kembalikan" untuk menandai buku sudah dikembalikan.</p>
            </div>
            <form method="GET">
                <select name="status" class="form-select form-select-custom" onchange="this.form.submit()">
                    <option value="">Semua Status</option>
                    <option value="Menunggu" <?= $filter_status=='Menunggu'?'selected':'' ?>>Menunggu</option>
                    <option value="Dipinjam" <?= $filter_status=='Dipinjam'?'selected':'' ?>>Dipinjam</option>
                    <option value="Ditolak" <?= $filter_status=='Ditolak'?'selected':'' ?>>Ditolak</option>
                    <option value="Dikembalikan" <?= $filter_status=='Dikembalikan'?'selected':'' ?>>Dikembalikan</option>
                </select>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-light-custom align-middle mb-0">
                <thead>
                    <tr>
                        <th>No Transaksi</th>
                        <th>Anggota</th>
                        <th>Buku</th>
                        <th>Tanggal Pinjam</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($data_transaksi && mysqli_num_rows($data_transaksi) > 0): ?>
                    <?php while ($p = mysqli_fetch_assoc($data_transaksi)):
                        $id_trx = $p['no_peminjaman'] ?? $p['id_peminjaman'];
                        $status = $p['status'] ?? '-';
                        $badge = 'secondary';
                        if ($status == 'Dipinjam') $badge = 'success';
                        elseif ($status == 'Menunggu' || $status == 'Pending') $badge = 'warning';
                        elseif ($status == 'Ditolak') $badge = 'danger';
                        elseif ($status == 'Dikembalikan' || $status == 'Selesai') $badge = 'info';
                    ?>
                    <tr>
                        <td><span class="id-badge"><?= htmlspecialchars($id_trx) ?></span></td>
                        <td><?= htmlspecialchars($p['nama_anggota'] ?? ('ID ' . $p['id_anggota'])) ?></td>
                        <td><?= htmlspecialchars($p['judul_buku'] ?? ('ID ' . $p['id_buku'])) ?></td>
                        <td><?= !empty($p['tgl_pinjam']) ? date('d-m-Y', strtotime($p['tgl_pinjam'])) : '-' ?></td>
                        <td><span class="badge bg-<?= $badge ?> px-2 py-1"><?= htmlspecialchars($status) ?></span></td>
                        <td class="text-center">
                            <!-- FIX: Tombol Kembalikan pakai link langsung + confirm -->
                            <?php if ($status == 'Dipinjam'): ?>
                            <a href="?aksi=kembalikan&id=<?= $p['id_peminjaman'] ?>" 
                               onclick="return confirm('Yakin buku ini sudah dikembalikan?')"
                               class="btn-kembalikan">
                                <i class="fa-solid fa-rotate-left"></i> Kembalikan
                            </a>
                            <?php else: ?>
                            <span class="text-muted small">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php else: ?>
                    <tr><td colspan="6" class="text-center py-4 text-muted">Belum ada data transaksi.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>