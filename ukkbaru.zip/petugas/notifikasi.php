<?php
session_start();
// --- KONEKSI DATABASE ---
$host = "localhost";
$user = "root";
$pass = "";
$db   = "perpusku";
$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

$petugas_login = isset($_SESSION['nama_petugas']) ? $_SESSION['nama_petugas'] : 'Siti Fatimah';
$words = explode(" ", $petugas_login);
$inisial = strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));

// Auto-create tabel notifikasi jika belum ada
$cek_notif = mysqli_query($koneksi, "SHOW TABLES LIKE 'notifikasi'");
if (mysqli_num_rows($cek_notif) == 0) {
    mysqli_query($koneksi, "CREATE TABLE notifikasi (
        id_notif INT AUTO_INCREMENT PRIMARY KEY,
        judul VARCHAR(255) NOT NULL,
        pesan TEXT,
        tipe VARCHAR(50) DEFAULT 'umum',
        status VARCHAR(50) DEFAULT 'belum_dibaca',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

// PROSES: Tandai semua sudah dibaca
if (isset($_GET['aksi']) && $_GET['aksi'] === 'tandai_semua') {
    mysqli_query($koneksi, "UPDATE notifikasi SET status = 'dibaca' WHERE status = 'belum_dibaca'");
    header("Location: notifikasi.php");
    exit();
}

// PROSES: Tandai satu sudah dibaca
if (isset($_GET['aksi']) && $_GET['aksi'] === 'baca' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    mysqli_query($koneksi, "UPDATE notifikasi SET status = 'dibaca' WHERE id_notif = $id");
    header("Location: notifikasi.php");
    exit();
}

// PROSES: Hapus notifikasi
if (isset($_GET['aksi']) && $_GET['aksi'] === 'hapus' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    mysqli_query($koneksi, "DELETE FROM notifikasi WHERE id_notif = $id");
    header("Location: notifikasi.php");
    exit();
}

// PROSES: Hapus semua yang sudah dibaca
if (isset($_GET['aksi']) && $_GET['aksi'] === 'hapus_dibaca') {
    mysqli_query($koneksi, "DELETE FROM notifikasi WHERE status = 'dibaca'");
    header("Location: notifikasi.php");
    exit();
}

// AMBIL DATA NOTIFIKASI DARI DATABASE
$filter = $_GET['filter'] ?? 'semua'; // semua, belum_dibaca, sudah_dibaca

$where_clause = "";
if ($filter === 'belum_dibaca') {
    $where_clause = "WHERE status = 'belum_dibaca'";
} elseif ($filter === 'sudah_dibaca') {
    $where_clause = "WHERE status = 'dibaca'";
}

$query_notif = mysqli_query($koneksi, "SELECT * FROM notifikasi $where_clause ORDER BY created_at DESC");

// Hitung statistik
$q_total = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM notifikasi");
$total_notif = mysqli_fetch_assoc($q_total)['jml'] ?? 0;

$q_belum = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM notifikasi WHERE status = 'belum_dibaca'");
$jumlah_belum_dibaca = mysqli_fetch_assoc($q_belum)['jml'] ?? 0;

$q_sudah = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM notifikasi WHERE status = 'dibaca'");
$jumlah_sudah_dibaca = mysqli_fetch_assoc($q_sudah)['jml'] ?? 0;

// Fungsi format waktu relatif
function waktuRelatif($datetime) {
    $now = new DateTime();
    $then = new DateTime($datetime);
    $diff = $now->diff($then);

    if ($diff->y > 0) return $diff->y . ' tahun yang lalu';
    if ($diff->m > 0) return $diff->m . ' bulan yang lalu';
    if ($diff->d > 0) return $diff->d . ' hari yang lalu';
    if ($diff->h > 0) return $diff->h . ' jam yang lalu';
    if ($diff->i > 0) return $diff->i . ' menit yang lalu';
    return 'Baru saja';
}

// Fungsi icon & warna berdasarkan tipe
function getNotifStyle($tipe) {
    switch ($tipe) {
        case 'booking':
            return ['icon' => 'fa-calendar-check', 'bg' => 'bg-primary-subtle', 'color' => 'text-primary'];
        case 'peminjaman':
            return ['icon' => 'fa-book-open', 'bg' => 'bg-success-subtle', 'color' => 'text-success'];
        case 'bantuan':
            return ['icon' => 'fa-circle-question', 'bg' => 'bg-warning-subtle', 'color' => 'text-warning'];
        case 'pengembalian':
            return ['icon' => 'fa-undo-alt', 'bg' => 'bg-info-subtle', 'color' => 'text-info'];
        default:
            return ['icon' => 'fa-bell', 'bg' => 'bg-secondary-subtle', 'color' => 'text-secondary'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifikasi Petugas - Sistem Perpustakaan SMP N 2 Sanden</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --sidebar-bg: #121629;
    --primary-color: #4f46e5;
    --primary-hover: #4338ca;
    --bg-body: #f4f5f7;
}
body {
    background-color: var(--bg-body);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    overflow-x: hidden;
}
.sidebar {
    width: 260px;
    height: 100vh;
    background-color: var(--sidebar-bg);
    position: fixed;
    top: 0;
    left: 0;
    color: #fff;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    z-index: 1000;
}
.sidebar-brand {
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}
.sidebar-brand .logo-icon {
    background-color: var(--primary-color);
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    color: white;
    font-size: 1.2rem;
}
.nav-menu {
    padding: 10px 15px;
    list-style: none;
    margin: 0;
    flex-grow: 1;
}
.nav-menu li a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 15px;
    color: #94a3b8;
    text-decoration: none;
    border-radius: 10px;
    font-weight: 500;
    transition: all 0.2s ease;
    margin-bottom: 5px;
}
.nav-menu li a:hover, .nav-menu li a.active {
    background-color: var(--primary-color);
    color: white;
}
.sidebar-footer {
    padding: 20px;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}
.sidebar-footer a {
    color: #94a3b8;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 15px;
    border-radius: 10px;
    transition: 0.2s;
}
.sidebar-footer a:hover {
    background-color: rgba(239, 68, 68, 0.1);
    color: #ef4444;
}
.main-content {
    margin-left: 260px;
    padding: 30px;
}
.top-navbar {
    background: white;
    padding: 15px 30px;
    border-radius: 15px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.02);
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}
.card {
    border: none;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
    border-radius: 15px;
    background: white;
}
.notif-item {
    transition: background-color 0.2s;
    border-left: 4px solid transparent;
}
.notif-item.unread {
    background-color: #f0f9ff;
    border-left-color: var(--primary-color);
}
.notif-item:hover {
    background-color: #f1f5f9;
}
.icon-box {
    width: 45px;
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    font-size: 1.1rem;
    flex-shrink: 0;
}
.btn-primary {
    background-color: var(--primary-color);
    border: none;
}
.btn-primary:hover {
    background-color: var(--primary-hover);
}
/* Badge notifikasi di navbar */
.notif-bell-wrapper {
    position: relative;
    cursor: pointer;
}
.badge-notif-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: #ef4444;
    color: #fff;
    font-size: 10px;
    font-weight: 700;
    min-width: 18px;
    height: 18px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid #fff;
    animation: pulseNotif 2s infinite;
}
@keyframes pulseNotif {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.15); }
}
/* Filter tabs */
.filter-tab {
    padding: 8px 20px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 600;
    text-decoration: none;
    color: #64748b;
    background: #f1f5f9;
    transition: all 0.2s;
    border: none;
}
.filter-tab:hover {
    background: #e2e8f0;
    color: #334155;
}
.filter-tab.active {
    background: var(--primary-color);
    color: #fff;
}
.filter-tab .count {
    background: rgba(255,255,255,0.3);
    padding: 1px 7px;
    border-radius: 10px;
    font-size: 0.75rem;
    margin-left: 4px;
}
.filter-tab.active .count {
    background: rgba(255,255,255,0.3);
}
</style>
</head>
<body>
<!-- SIDEBAR -->
<div class="sidebar">
<div>
<div class="sidebar-brand">
<div class="logo-icon"><i class="fas fa-book-reader"></i></div>
<div>
<h6 class="mb-0 text-white fw-bold">Petugas</h6>
<small class="text-muted" style="font-size: 11px;">Perpustakaan</small>
</div>
</div>
<ul class="nav-menu">
<li><a href="dashboard.php"><i class="fas fa-th-large"></i> Dashboard</a></li>
<li><a href="kondisi.php"><i class="fas fa-book-medical"></i> Cek Kondisi Buku</a></li>
<li><a href="transaksi.php"><i class="fas fa-exchange-alt"></i> Transaksi</a></li>
<li><a href="booking.php"><i class="fas fa-calendar-check"></i> Kelola Booking</a></li>
<li><a href="notifikasi.php" class="active"><i class="fas fa-bell"></i> Notifikasi <?php if ($jumlah_belum_dibaca > 0): ?><span class="badge bg-danger rounded-pill ms-1" style="font-size:10px;"><?= $jumlah_belum_dibaca ?></span><?php endif; ?></a></li>
<li><a href="profil.php"><i class="fas fa-user"></i> Profil Saya</a></li>
</ul>
</div>
<div class="sidebar-footer">
                <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');" class="text-danger mt-4"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">
<!-- TOP NAVBAR -->
<div class="top-navbar">
<div>
<h4 class="fw-bold text-dark mb-0">Notifikasi Sistem</h4>
<small class="text-muted">Pemberitahuan pengajuan, booking, dan pesan bantuan terbaru</small>
</div>
<div class="d-flex align-items-center gap-3">
<!-- Notifikasi Bell dengan Badge -->
<div class="notif-bell-wrapper">
<a href="notifikasi.php" class="text-dark text-decoration-none fs-5">
<i class="far fa-bell"></i>
<?php if ($jumlah_belum_dibaca > 0): ?>
<span class="badge-notif-count"><?= $jumlah_belum_dibaca ?></span>
<?php endif; ?>
</a>
</div>
<div class="dropdown">
<button class="btn btn-light d-flex align-items-center gap-2 rounded-pill px-3 py-1 border" type="button">
<span class="badge bg-primary rounded-circle p-2"><?= $inisial ?></span>
<span class="fw-bold text-dark small"><?= htmlspecialchars($petugas_login) ?></span>
</button>
</div>
</div>
</div>

<!-- KONTEN UTAMA NOTIFIKASI -->
<div class="card p-4">
<!-- Header dengan Filter -->
<div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3 flex-wrap gap-3">
<div>
<h5 class="fw-bold text-dark m-0"><i class="fas fa-bell text-primary me-2"></i> Daftar Pemberitahuan</h5>
<small class="text-muted">Total: <strong><?= $total_notif ?></strong> notifikasi | Belum dibaca: <strong class="text-primary"><?= $jumlah_belum_dibaca ?></strong></small>
</div>
<div class="d-flex gap-2 align-items-center flex-wrap">
<!-- Filter Tabs -->
<a href="notifikasi.php?filter=semua" class="filter-tab <?= $filter === 'semua' ? 'active' : '' ?>">
Semua <span class="count"><?= $total_notif ?></span>
</a>
<a href="notifikasi.php?filter=belum_dibaca" class="filter-tab <?= $filter === 'belum_dibaca' ? 'active' : '' ?>">
Belum Dibaca <span class="count"><?= $jumlah_belum_dibaca ?></span>
</a>
<a href="notifikasi.php?filter=sudah_dibaca" class="filter-tab <?= $filter === 'sudah_dibaca' ? 'active' : '' ?>">
Sudah Dibaca <span class="count"><?= $jumlah_sudah_dibaca ?></span>
</a>
</div>
</div>

<!-- Tombol Aksi Massal -->
<?php if ($jumlah_belum_dibaca > 0): ?>
<div class="d-flex gap-2 mb-3">
<a href="notifikasi.php?aksi=tandai_semua" class="btn btn-sm btn-outline-primary rounded-pill" onclick="return confirm('Tandai semua notifikasi sebagai sudah dibaca?')">
<i class="fas fa-check-double me-1"></i> Tandai Semua Dibaca
</a>
</div>
<?php endif; ?>
<?php if ($jumlah_sudah_dibaca > 0): ?>
<div class="d-flex gap-2 mb-3">
<a href="notifikasi.php?aksi=hapus_dibaca" class="btn btn-sm btn-outline-danger rounded-pill" onclick="return confirm('Hapus semua notifikasi yang sudah dibaca?')">
<i class="fas fa-trash-alt me-1"></i> Hapus yang Sudah Dibaca
</a>
</div>
<?php endif; ?>

<!-- List Notifikasi dari Database -->
<div class="list-group list-group-flush">
<?php if (mysqli_num_rows($query_notif) > 0): ?>
<?php while ($notif = mysqli_fetch_assoc($query_notif)):
    $style = getNotifStyle($notif['tipe'] ?? 'umum');
    $is_unread = ($notif['status'] === 'belum_dibaca');
?>
<div class="list-group-item notif-item p-3 rounded mb-2 <?= $is_unread ? 'unread' : '' ?>">
<div class="d-flex align-items-start gap-3">
<!-- Icon berdasarkan Tipe -->
<div class="icon-box <?= $style['bg'] ?> <?= $style['color'] ?>">
<i class="fas <?= $style['icon'] ?>"></i>
</div>
<!-- Isi Notifikasi -->
<div class="flex-grow-1">
<div class="d-flex justify-content-between align-items-start mb-1">
<div>
<h6 class="mb-0 fw-bold text-dark">
<?= htmlspecialchars($notif['judul']) ?>
<?php if ($is_unread): ?>
<span class="badge bg-primary ms-2" style="font-size: 10px;">Baru</span>
<?php endif; ?>
</h6>
<small class="text-muted">
<i class="far fa-clock me-1"></i> <?= waktuRelatif($notif['created_at']) ?>
<span class="mx-1">•</span>
<?= date('d/m/Y H:i', strtotime($notif['created_at'])) ?>
</small>
</div>
<div class="d-flex gap-1">
<?php if ($is_unread): ?>
<a href="notifikasi.php?aksi=baca&id=<?= $notif['id_notif'] ?>" class="btn btn-sm btn-outline-primary rounded-pill" title="Tandai Dibaca">
<i class="fas fa-check"></i>
</a>
<?php endif; ?>
<a href="notifikasi.php?aksi=hapus&id=<?= $notif['id_notif'] ?>" class="btn btn-sm btn-outline-danger rounded-pill" title="Hapus" onclick="return confirm('Hapus notifikasi ini?')">
<i class="fas fa-trash"></i>
</a>
</div>
</div>
<p class="text-muted mb-2 small"><?= htmlspecialchars($notif['pesan']) ?></p>
<!-- Tombol Tindak Lanjuti berdasarkan tipe -->
<div>
<?php if (($notif['tipe'] ?? '') === 'booking' || ($notif['tipe'] ?? '') === 'peminjaman'): ?>
<a href="booking.php" class="btn btn-sm btn-light border text-primary fw-bold rounded-pill">
<i class="fas fa-arrow-right me-1"></i> Kelola Booking
</a>
<?php elseif (($notif['tipe'] ?? '') === 'bantuan'): ?>
<a href="../index.php#bantuan" class="btn btn-sm btn-light border text-warning fw-bold rounded-pill">
<i class="fas fa-arrow-right me-1"></i> Lihat Pesan Bantuan
</a>
<?php elseif (($notif['tipe'] ?? '') === 'pengembalian'): ?>
<a href="transaksi.php" class="btn btn-sm btn-light border text-success fw-bold rounded-pill">
<i class="fas fa-arrow-right me-1"></i> Lihat Transaksi
</a>
<?php endif; ?>
</div>
</div>
</div>
</div>
<?php endwhile; ?>
<?php else: ?>
<div class="text-center py-5">
<i class="far fa-bell-slash fa-3x text-muted mb-3 d-block"></i>
<h5 class="fw-bold text-muted">Tidak ada notifikasi</h5>
<p class="text-muted small">
<?php if ($filter === 'belum_dibaca'): ?>
Semua notifikasi sudah dibaca. Kerja bagus! 
<?php elseif ($filter === 'sudah_dibaca'): ?>
Belum ada notifikasi yang sudah dibaca.
<?php else: ?>
Belum ada notifikasi dalam sistem. Notifikasi akan muncul ketika ada aktivitas baru.
<?php endif; ?>
</p>
</div>
<?php endif; ?>
</div>
</div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>