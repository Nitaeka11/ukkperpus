<?php
session_start();

// --- KONEKSI DATABASE ---
$host = "localhost";
$user = "root";
$pass = "";
$db   = "perpusku";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

$petugas_login = isset($_SESSION['nama_petugas']) ? $_SESSION['nama_petugas'] : 'Siti Fatimah';
$inisial = 'SF';

$pesan_sukses = "";
$pesan_error = "";

// --- AUTO-CREATE/CHECK KOLOM DATABASE ---
// Cek dan buat kolom 'kondisi' jika belum ada
$cek_kolom_kondisi = mysqli_query($koneksi, "SHOW COLUMNS FROM buku LIKE 'kondisi'");
if (mysqli_num_rows($cek_kolom_kondisi) == 0) {
    mysqli_query($koneksi, "ALTER TABLE buku ADD COLUMN kondisi VARCHAR(50) DEFAULT 'Baik'");
}

// Cek dan buat kolom 'catatan' jika belum ada
$cek_kolom_catatan = mysqli_query($koneksi, "SHOW COLUMNS FROM buku LIKE 'catatan'");
if (mysqli_num_rows($cek_kolom_catatan) == 0) {
    mysqli_query($koneksi, "ALTER TABLE buku ADD COLUMN catatan TEXT NULL");
}

// Cek otomatis nama kolom judul di tabel buku
$kolom_judul = 'judul';
$cek_kolom = mysqli_query($koneksi, "SHOW COLUMNS FROM buku LIKE 'judul_buku'");
if (mysqli_num_rows($cek_kolom) > 0) {
    $kolom_judul = 'judul_buku';
} else {
    $cek_kolom2 = mysqli_query($koneksi, "SHOW COLUMNS FROM buku LIKE 'nama_buku'");
    if (mysqli_num_rows($cek_kolom2) > 0) {
        $kolom_judul = 'nama_buku';
    }
}

// Cek otomatis nama kolom rak di tabel buku
$kolom_rak = 'rak';
$cek_rak = mysqli_query($koneksi, "SHOW COLUMNS FROM buku LIKE 'lokasi_rak'");
if (mysqli_num_rows($cek_rak) > 0) {
    $kolom_rak = 'lokasi_rak';
}

// Tangkap keyword pencarian
$pencarian = isset($_GET['cari']) ? mysqli_real_escape_string($koneksi, $_GET['cari']) : '';

// --- PROSES TAMBAH BUKU & KONDISI ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tambah_buku'])) {
    $kode_buku = mysqli_real_escape_string($koneksi, $_POST['kode_buku']);
    $val_judul = mysqli_real_escape_string($koneksi, $_POST['judul']);
    $val_rak   = mysqli_real_escape_string($koneksi, $_POST['rak']);
    $kondisi   = mysqli_real_escape_string($koneksi, $_POST['kondisi']);
    $catatan   = mysqli_real_escape_string($koneksi, $_POST['catatan']);
    
    $catatan_sql = empty($catatan) ? "NULL" : "'$catatan'";

    $query = "INSERT INTO buku (kode_buku, $kolom_judul, $kolom_rak, kondisi, catatan) VALUES ('$kode_buku', '$val_judul', '$val_rak', '$kondisi', $catatan_sql)";
    if (mysqli_query($koneksi, $query)) {
        $pesan_sukses = "Data buku dan kondisi berhasil ditambahkan!";
    } else {
        $pesan_error = "Gagal menambah data: " . mysqli_error($koneksi);
    }
}

// --- PROSES EDIT KONDISI & DATA BUKU ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_kondisi'])) {
    $id_buku   = mysqli_real_escape_string($koneksi, $_POST['id_buku']);
    $kode_buku = mysqli_real_escape_string($koneksi, $_POST['kode_buku']);
    $val_judul = mysqli_real_escape_string($koneksi, $_POST['judul']);
    $val_rak   = mysqli_real_escape_string($koneksi, $_POST['rak']);
    $kondisi   = mysqli_real_escape_string($koneksi, $_POST['kondisi']);
    $catatan   = mysqli_real_escape_string($koneksi, $_POST['catatan']);
    
    $catatan_sql = empty($catatan) ? "NULL" : "'$catatan'";

    $query = "UPDATE buku SET kode_buku='$kode_buku', $kolom_judul='$val_judul', $kolom_rak='$val_rak', kondisi='$kondisi', catatan=$catatan_sql WHERE id_buku='$id_buku'";
    if (mysqli_query($koneksi, $query)) {
        $pesan_sukses = "Kondisi buku berhasil diperbarui!";
    } else {
        $pesan_error = "Gagal memperbarui data: " . mysqli_error($koneksi);
    }
}

// --- PROSES HAPUS DATA BUKU ---
if (isset($_GET['hapus'])) {
    $id_buku = mysqli_real_escape_string($koneksi, $_GET['hapus']);
    mysqli_query($koneksi, "DELETE FROM buku WHERE id_buku='$id_buku'");
    header("Location: kondisi.php");
    exit();
}

// Query Pencarian Data
$where_sql = "";
if (!empty($pencarian)) {
    $where_sql = "WHERE kode_buku LIKE '%$pencarian%' OR $kolom_judul LIKE '%$pencarian%' OR $kolom_rak LIKE '%$pencarian%'";
}

$result = mysqli_query($koneksi, "SELECT * FROM buku $where_sql ORDER BY id_buku DESC");

// Hitung Statistik Keseluruhan
$q_all = mysqli_query($koneksi, "SELECT * FROM buku");
$total_buku = mysqli_num_rows($q_all);
$kondisi_baik = 0;
$rusak_ringan = 0;
$perlu_perbaikan = 0;
$rusak_berat = 0;
$hilang = 0;

while ($row_stat = mysqli_fetch_assoc($q_all)) {
    $kond = isset($row_stat['kondisi']) ? trim($row_stat['kondisi']) : 'Baik';
    if ($kond == 'Baik') {
        $kondisi_baik++;
    } elseif ($kond == 'Rusak Ringan') {
        $rusak_ringan++;
    } elseif ($kond == 'Perlu Perbaikan' || $kond == 'Rusak Sedang') {
        $perlu_perbaikan++;
    } elseif ($kond == 'Rusak Berat') {
        $rusak_berat++;
    } elseif ($kond == 'Hilang') {
        $hilang++;
    }
}

$data_buku = [];
while ($row = mysqli_fetch_assoc($result)) {
    $row['tampil_judul'] = isset($row[$kolom_judul]) ? $row[$kolom_judul] : '';
    $row['tampil_rak'] = isset($row[$kolom_rak]) ? $row[$kolom_rak] : '';
    $data_buku[] = $row;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Kondisi Buku - Sistem Perpustakaan</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-bg: #121629;
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --bg-body: #f4f5f7;
        }
        body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; overflow-x: hidden; }
        .sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; }
        .sidebar-brand { padding: 20px; display: flex; align-items: center; gap: 12px; }
        .sidebar-brand .logo-icon { background-color: var(--primary-color); width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 10px; color: white; font-size: 1.2rem; }
        .nav-menu { padding: 10px 15px; list-style: none; margin: 0; flex-grow: 1; }
        .nav-menu li a { display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: #94a3b8; text-decoration: none; border-radius: 10px; font-weight: 500; transition: all 0.2s ease; margin-bottom: 5px; }
        .nav-menu li a:hover, .nav-menu li a.active { background-color: var(--primary-color); color: white; }
        .sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
        .sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; transition: 0.2s; }
        .sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .main-content { margin-left: 260px; padding: 30px; }
        .top-navbar { background: white; padding: 15px 30px; border-radius: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .card, .stat-card { border: none; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); border-radius: 15px; background: white; }
        .stat-card { padding: 20px; }
        .btn-primary { background-color: var(--primary-color); border: none; }
        .btn-primary:hover { background-color: var(--primary-hover); }
    </style>
</head>
<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div>
            <div class="sidebar-brand">
                <div class="logo-icon"><i class="fas fa-book-reader"></i></div>
                <div>
                    <h6 class="mb-0 text-white fw-bold">Petugas</h6>
                    <small class="text-muted" style="font-size: 11px;">Perpustakaan</small>
                </div>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-th-large"></i> Dashboard</a></li>
                <li><a href="kondisi.php" class="active"><i class="fas fa-book-medical"></i> Cek Kondisi Buku</a></li>
                <li><a href="transaksi.php"><i class="fas fa-exchange-alt"></i> Transaksi</a></li>
                <li><a href="booking.php"><i class="fas fa-calendar-check"></i> Kelola Booking</a></li>
                <li><a href="notifikasi.php"><i class="fas fa-bell"></i> Notifikasi</a></li>
                <li><a href="profil.php"><i class="fas fa-user"></i> Profil Saya</a></li>
            </ul>
        </div>
        <div class="sidebar-footer">
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        
        <!-- TOP NAVBAR -->
        <div class="top-navbar">
            <div>
                <h4 class="fw-bold text-dark mb-0">Cek Kondisi Buku</h4>
                <small class="text-muted">Kelola pemeriksaan fisik koleksi perpustakaan</small>
            </div>
            <div class="d-flex align-items-center gap-3">
                <a href="notifikasi.php" class="text-dark position-relative text-decoration-none fs-5"><i class="far fa-bell"></i></a>
                <div class="dropdown">
                    <button class="btn btn-light d-flex align-items-center gap-2 rounded-pill px-3 py-1 border" type="button">
                        <span class="badge bg-primary rounded-circle p-2"><?php echo $inisial; ?></span>
                        <span class="fw-bold text-dark small"><?php echo $petugas_login; ?></span>
                    </button>
                </div>
            </div>
        </div>

        <!-- NOTIFIKASI -->
        <?php if (!empty($pesan_sukses)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i> <?php echo $pesan_sukses; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if (!empty($pesan_error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $pesan_error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- STATISTIK KARTU -->
        <div class="row g-3 mb-4">
            <div class="col">
                <div class="stat-card">
                    <span class="text-muted small" style="font-size: 11px;">Total Buku</span>
                    <h4 class="fw-bold text-dark mb-0 mt-1"><?php echo $total_buku; ?></h4>
                </div>
            </div>
            <div class="col">
                <div class="stat-card">
                    <span class="text-muted small" style="font-size: 11px;">Baik</span>
                    <h4 class="fw-bold text-success mb-0 mt-1"><?php echo $kondisi_baik; ?></h4>
                </div>
            </div>
            <div class="col">
                <div class="stat-card">
                    <span class="text-muted small" style="font-size: 11px;">Rusak Ringan</span>
                    <h4 class="fw-bold text-warning mb-0 mt-1" style="color: #d97706 !important;"><?php echo $rusak_ringan; ?></h4>
                </div>
            </div>
            <div class="col">
                <div class="stat-card">
                    <span class="text-muted small" style="font-size: 11px;">Perlu Perbaikan</span>
                    <h4 class="fw-bold text-danger mb-0 mt-1" style="color: #b45309 !important;"><?php echo $perlu_perbaikan; ?></h4>
                </div>
            </div>
            <div class="col">
                <div class="stat-card">
                    <span class="text-muted small" style="font-size: 11px;">Rusak Berat</span>
                    <h4 class="fw-bold text-danger mb-0 mt-1"><?php echo $rusak_berat; ?></h4>
                </div>
            </div>
            <div class="col">
                <div class="stat-card">
                    <span class="text-muted small" style="font-size: 11px;">Hilang</span>
                    <h4 class="fw-bold text-secondary mb-0 mt-1"><?php echo $hilang; ?></h4>
                </div>
            </div>
        </div>

        <!-- TABEL UTAMA -->
        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                <div>
                    <h5 class="fw-bold text-dark m-0">Daftar Pemeriksaan Buku</h5>
                    <small class="text-muted">Data pemeriksaan kondisi fisik koleksi perpustakaan</small>
                </div>
                
                <div class="d-flex align-items-center gap-2">
                    <form method="GET" action="" class="d-flex">
                        <div class="input-group input-group-sm" style="width: 220px;">
                            <input type="text" name="cari" class="form-control" placeholder="Cari kode/judul buku..." value="<?php echo htmlspecialchars($pencarian); ?>">
                            <button class="btn btn-outline-secondary" type="submit"><i class="fas fa-search"></i></button>
                        </div>
                    </form>
                    <button type="button" class="btn btn-primary btn-sm px-3" data-bs-toggle="modal" data-bs-target="#modalTambah">
                        <i class="fas fa-plus me-1"></i> Tambah
                    </button>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table align-middle table-hover">
                    <thead class="table-light">
                        <tr>
                            <th class="py-3">KODE BUKU</th>
                            <th class="py-3">JUDUL</th>
                            <th class="py-3">RAK</th>
                            <th class="py-3">KONDISI</th>
                            <th class="py-3">CATATAN</th>
                            <th class="py-3 text-center">AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($data_buku) > 0): ?>
                            <?php foreach ($data_buku as $row): ?>
                                <tr>
                                    <td><span class="fw-bold text-primary"><?php echo htmlspecialchars($row['kode_buku'] ?? ''); ?></span></td>
                                    <td><?php echo htmlspecialchars($row['tampil_judul']); ?></td>
                                    <td><span class="badge bg-light text-dark border px-2 py-1"><?php echo htmlspecialchars($row['tampil_rak']); ?></span></td>
                                    <td>
                                        <?php 
                                            $kondisi_teks = isset($row['kondisi']) ? trim($row['kondisi']) : 'Baik';
                                            if ($kondisi_teks == 'Baik') {
                                                echo '<span class="badge bg-success bg-opacity-10 text-success px-2 py-1"><i class="fas fa-circle me-1" style="font-size:6px;"></i> Baik</span>';
                                            } elseif ($kondisi_teks == 'Rusak Ringan') {
                                                echo '<span class="badge bg-warning bg-opacity-10 text-warning px-2 py-1" style="color: #d97706 !important; background-color: rgba(217, 119, 6, 0.1) !important;"><i class="fas fa-circle me-1" style="font-size:6px;"></i> Rusak Ringan</span>';
                                            } elseif ($kondisi_teks == 'Perlu Perbaikan' || $kondisi_teks == 'Rusak Sedang') {
                                                echo '<span class="badge px-2 py-1" style="color: #b45309; background-color: rgba(180, 83, 9, 0.1);"><i class="fas fa-circle me-1" style="font-size:6px;"></i> ' . $kondisi_teks . '</span>';
                                            } elseif ($kondisi_teks == 'Rusak Berat') {
                                                echo '<span class="badge bg-danger bg-opacity-10 text-danger px-2 py-1"><i class="fas fa-circle me-1" style="font-size:6px;"></i> Rusak Berat</span>';
                                            } elseif ($kondisi_teks == 'Hilang') {
                                                echo '<span class="badge bg-secondary bg-opacity-10 text-secondary px-2 py-1"><i class="fas fa-circle me-1" style="font-size:6px;"></i> Hilang</span>';
                                            } else {
                                                echo '<span class="badge bg-dark bg-opacity-10 text-dark px-2 py-1"><i class="fas fa-circle me-1" style="font-size:6px;"></i> ' . $kondisi_teks . '</span>';
                                            }
                                        ?>
                                    </td>
                                    <td><?php echo !empty($row['catatan']) ? htmlspecialchars($row['catatan']) : '-'; ?></td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-light text-primary border me-1 btn-edit" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#modalEdit"
                                            data-id="<?php echo $row['id_buku'] ?? ''; ?>"
                                            data-kode="<?php echo $row['kode_buku'] ?? ''; ?>"
                                            data-judul="<?php echo htmlspecialchars($row['tampil_judul']); ?>"
                                            data-rak="<?php echo htmlspecialchars($row['tampil_rak']); ?>"
                                            data-kondisi="<?php echo $row['kondisi'] ?? 'Baik'; ?>"
                                            data-catatan="<?php echo $row['catatan'] ?? ''; ?>">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                        <a href="kondisi.php?hapus=<?php echo $row['id_buku']; ?>" class="btn btn-sm btn-light text-danger border" onclick="return confirm('Yakin ingin menghapus buku ini?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">Data buku tidak ditemukan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- MODAL TAMBAH -->
    <div class="modal fade" id="modalTambah" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold"><i class="fas fa-plus-circle text-primary me-2"></i> Tambah Buku Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Kode Buku</label>
                            <input type="text" class="form-control" name="kode_buku" placeholder="Contoh: BK-006" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Judul Buku</label>
                            <input type="text" class="form-control" name="judul" placeholder="Masukkan judul buku" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Nomor Rak</label>
                            <input type="text" class="form-control" name="rak" placeholder="Contoh: C2" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Kondisi Fisik</label>
                            <select class="form-select" name="kondisi" required>
                                <option value="Baik">Baik (Hijau)</option>
                                <option value="Rusak Ringan">Rusak Ringan (Kuning/Jingga)</option>
                                <option value="Perlu Perbaikan">Perlu Perbaikan / Rusak Sedang (Kuning Tua)</option>
                                <option value="Rusak Berat">Rusak Berat (Merah)</option>
                                <option value="Hilang">Hilang (Hitam/Abu-abu)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Catatan (Opsional)</label>
                            <textarea class="form-control" name="catatan" rows="2" placeholder="Catatan tambahan kondisi buku"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="tambah_buku" class="btn btn-primary btn-sm">Simpan Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- MODAL EDIT -->
    <div class="modal fade" id="modalEdit" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold"><i class="fas fa-pen text-primary me-2"></i> Edit Kondisi Buku</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="id_buku" id="edit_id">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Kode Buku</label>
                            <input type="text" class="form-control" name="kode_buku" id="edit_kode" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Judul Buku</label>
                            <input type="text" class="form-control" name="judul" id="edit_judul" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Nomor Rak</label>
                            <input type="text" class="form-control" name="rak" id="edit_rak" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Kondisi Fisik</label>
                            <select class="form-select" name="kondisi" id="edit_kondisi" required>
                                <option value="Baik">Baik</option>
                                <option value="Rusak Ringan">Rusak Ringan</option>
                                <option value="Perlu Perbaikan">Perlu Perbaikan / Rusak Sedang</option>
                                <option value="Rusak Berat">Rusak Berat</option>
                                <option value="Hilang">Hilang</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Catatan</label>
                            <textarea class="form-control" name="catatan" id="edit_catatan" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="edit_kondisi" class="btn btn-primary btn-sm">Perbarui Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS & Script Modal Edit -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const modalEdit = document.getElementById('modalEdit');
        modalEdit.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            document.getElementById('edit_id').value = button.getAttribute('data-id');
            document.getElementById('edit_kode').value = button.getAttribute('data-kode');
            document.getElementById('edit_judul').value = button.getAttribute('data-judul');
            document.getElementById('edit_rak').value = button.getAttribute('data-rak');
            document.getElementById('edit_kondisi').value = button.getAttribute('data-kondisi');
            let catatan = button.getAttribute('data-catatan');
            document.getElementById('edit_catatan').value = (catatan !== 'null' && catatan !== '') ? catatan : '';
        });
    </script>
</body>
</html>