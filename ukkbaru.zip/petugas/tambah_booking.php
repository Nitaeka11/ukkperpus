<?php
/* =========================================================
   TAMBAH_BOOKING.PHP — Petugas Input Booking Manual
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_anggota = (int) $_POST['id_anggota'];
    $id_buku    = (int) $_POST['id_buku'];

    $q_anggota = mysqli_prepare($conn, "SELECT nama_lengkap FROM anggota WHERE id_anggota = ?");
    mysqli_stmt_bind_param($q_anggota, "i", $id_anggota);
    mysqli_stmt_execute($q_anggota);
    $anggota = mysqli_fetch_assoc(mysqli_stmt_get_result($q_anggota));

    $q_buku = mysqli_prepare($conn, "SELECT kode_buku, judul_buku FROM buku WHERE id_buku = ?");
    mysqli_stmt_bind_param($q_buku, "i", $id_buku);
    mysqli_stmt_execute($q_buku);
    $buku = mysqli_fetch_assoc(mysqli_stmt_get_result($q_buku));

    if (!$anggota || !$buku) {
        $error = 'Anggota atau buku tidak ditemukan. Cek kembali ID-nya.';
    } else {
        $kode_booking        = 'BKG-' . date('YmdHis') . rand(10, 99);
        $tanggal_booking     = date('Y-m-d H:i:s');
        $batas_ambil         = date('Y-m-d', strtotime('+2 days'));
        $tanggal_jatuh_tempo = date('Y-m-d', strtotime('+9 days'));

        $stmt = mysqli_prepare($conn, "INSERT INTO booking
            (kode_booking, id_anggota, nama_anggota, id_buku, kode_buku, judul_buku, tanggal_booking, batas_ambil, tanggal_jatuh_tempo, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Menunggu')");
        mysqli_stmt_bind_param($stmt, "sisisssss",
            $kode_booking, $id_anggota, $anggota['nama_lengkap'], $id_buku, $buku['kode_buku'], $buku['judul_buku'],
            $tanggal_booking, $batas_ambil, $tanggal_jatuh_tempo
        );
        mysqli_stmt_execute($stmt);

        $_SESSION['pesan'] = "Booking manual untuk {$anggota['nama_lengkap']} berhasil dibuat (kode: $kode_booking).";
        $_SESSION['pesan_tipe'] = 'success';
        header("Location: booking.php");
        exit();
    }
}

$daftar_anggota = mysqli_query($conn, "SELECT id_anggota, nama_lengkap, kode_anggota FROM anggota ORDER BY nama_lengkap");
$daftar_buku = mysqli_query($conn, "SELECT id_buku, kode_buku, judul_buku, stok FROM buku WHERE stok > 0 ORDER BY judul_buku");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Booking - Petugas</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
  body { background:#F5F7FB; font-family:'Segoe UI',Arial,sans-serif; padding:40px; }
  .form-card { max-width:560px; margin:0 auto; background:#fff; border-radius:16px; padding:30px; box-shadow:0 4px 20px rgba(0,0,0,.05); }
</style>
</head>
<body>
<div class="form-card">
    <h4 class="fw-bold mb-1">+ Tambah Booking Manual</h4>
    <p class="text-muted mb-4">Untuk anggota yang mengajukan booking langsung ke petugas.</p>

    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label fw-semibold">Anggota</label>
            <select name="id_anggota" class="form-select" required>
                <option value="">-- Pilih Anggota --</option>
                <?php mysqli_data_seek($daftar_anggota, 0); while ($a = mysqli_fetch_assoc($daftar_anggota)): ?>
                    <option value="<?= $a['id_anggota'] ?>"><?= htmlspecialchars($a['nama_lengkap']) ?> (<?= htmlspecialchars($a['kode_anggota']) ?>)</option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-4">
            <label class="form-label fw-semibold">Buku</label>
            <select name="id_buku" class="form-select" required>
                <option value="">-- Pilih Buku --</option>
                <?php mysqli_data_seek($daftar_buku, 0); while ($b = mysqli_fetch_assoc($daftar_buku)): ?>
                    <option value="<?= $b['id_buku'] ?>"><?= htmlspecialchars($b['judul_buku']) ?> (Stok: <?= $b['stok'] ?>)</option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="d-flex gap-2">
            <a href="booking.php" class="btn btn-secondary">Batal</a>
            <button type="submit" class="btn btn-primary" style="background:#6366f1; border:none;">Simpan Booking</button>
        </div>
    </form>
</div>
</body>
</html>