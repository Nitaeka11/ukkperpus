<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

$koneksi = $conn; // alias supaya query di bawah (yang sudah pakai $koneksi) tetap jalan tanpa diubah semua

$petugas_login = $_SESSION['nama'] ?? 'Petugas';
$words = explode(" ", $petugas_login);
$inisial = strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));

// Statistik
$total_anggota = 3;
$cek_tabel_anggota = mysqli_query($koneksi, "SHOW TABLES LIKE 'anggota'");
if (mysqli_num_rows($cek_tabel_anggota) > 0) {
    $q_ang = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM anggota");
    $d_ang = mysqli_fetch_assoc($q_ang);
    $total_anggota = $d_ang['jml'];
}

$peminjaman_aktif = 0;
$cek_tabel_booking = mysqli_query($koneksi, "SHOW TABLES LIKE 'booking'");
$cek_tabel_peminjaman = mysqli_query($koneksi, "SHOW TABLES LIKE 'peminjaman'");
if (mysqli_num_rows($cek_tabel_peminjaman) > 0) {
    $q_pinjam = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM peminjaman WHERE status = 'Dipinjam'");
    $d_pinjam = mysqli_fetch_assoc($q_pinjam);
    $peminjaman_aktif = $d_pinjam['jml'];
}

$booking_menunggu = 0;
if (mysqli_num_rows($cek_tabel_booking) > 0) {
    $q_book = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM booking WHERE status = 'Menunggu'");
    $d_book = mysqli_fetch_assoc($q_book);
    $booking_menunggu = $d_book['jml'];
}

$total_buku = 0;
$cek_tabel_buku = mysqli_query($koneksi, "SHOW TABLES LIKE 'buku'");
if (mysqli_num_rows($cek_tabel_buku) > 0) {
    $q_buku = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM buku");
    $d_buku = mysqli_fetch_assoc($q_buku);
    $total_buku = $d_buku['jml'];
}

$jml_menunggu = $booking_menunggu;
$jml_dipinjam = $peminjaman_aktif;
$jml_selesai = 0;
if (mysqli_num_rows($cek_tabel_peminjaman) > 0) {
    $q_selesai = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM peminjaman WHERE status = 'Selesai' OR status = 'Dikembalikan'");
    $d_selesai = mysqli_fetch_assoc($q_selesai);
    $jml_selesai = $d_selesai['jml'];
}

// Hitung notifikasi belum dibaca
$q_notif = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM notifikasi WHERE status = 'belum_dibaca'");
$notif_belum = mysqli_fetch_assoc($q_notif)['jml'] ?? 0;

// Ambil notifikasi terbaru
$q_notif_list = mysqli_query($koneksi, "SELECT * FROM notifikasi ORDER BY created_at DESC LIMIT 5");
$notif_list = [];
while ($n = mysqli_fetch_assoc($q_notif_list)) { $notif_list[] = $n; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Petugas - Sistem Perpustakaan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --sidebar-bg: #121629;
    --primary-color: #4f46e5;
    --primary-hover: #4338ca;
    --bg-body: #f4f5f7;
}
body { background-color: var(--bg-body); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; overflow-x: hidden; }
.sidebar { width: 260px; height: 100vh; background-color: var(--sidebar-bg); position: fixed; top: 0; left: 0; color: #fff; display: flex; flex-direction: column; justify-content: space-between; z-index: 1000; }
.sidebar-brand { padding: 20px; display: flex; align-items: center; gap: 12px; }
.sidebar-brand .logo-icon { background-color: var(--primary-color); width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 10px; color: white; font-size: 1.2rem; }
.nav-menu { padding: 10px 15px; list-style: none; margin: 0; flex-grow: 1; }
.nav-menu li a { display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: #94a3b8; text-decoration: none; border-radius: 10px; font-weight: 500; transition: all 0.2s ease; margin-bottom: 5px; }
.nav-menu li a:hover, .nav-menu li a.active { background-color: var(--primary-color); color: white; }
.sidebar-footer { padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05); }
.sidebar-footer a { color: #94a3b8; text-decoration: none; display: flex; align-items: center; gap: 12px; padding: 10px 15px; border-radius: 10px; transition: 0.2s; }
.sidebar-footer a:hover { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
.main-content { margin-left: 260px; padding: 30px; }
.top-navbar { background: white; padding: 15px 30px; border-radius: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
.card, .stat-card { border: none; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); border-radius: 15px; background: white; }
.stat-card { padding: 20px; }
.chart-bar-container { display: flex; align-items: flex-end; justify-content: space-around; height: 220px; padding-top: 20px; border-bottom: 2px solid #e2e8f0; }
.chart-column { display: flex; flex-direction: column; align-items: center; gap: 8px; width: 30%; }
.bar { width: 50px; border-radius: 8px 8px 0 0; transition: height 0.4s ease; }

/* Notifikasi Bell */
.notif-bell { position: relative; cursor: pointer; }
.notif-bell .badge-notif {
    position: absolute; top: -8px; right: -8px;
    background: #ef4444; color: #fff;
    font-size: 10px; font-weight: 700;
    min-width: 18px; height: 18px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    border: 2px solid #fff;
    animation: pulse 2s infinite;
}
@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}
.notif-dropdown {
    position: absolute; top: 50px; right: 0;
    width: 350px; max-height: 400px; overflow-y: auto;
    background: #fff; border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.15);
    display: none; z-index: 9999;
}
.notif-dropdown.show { display: block; }
.notif-dropdown .notif-header {
    padding: 15px; border-bottom: 1px solid #f1f5f9;
    display: flex; justify-content: space-between; align-items: center;
}
.notif-dropdown .notif-item {
    padding: 12px 15px; border-bottom: 1px solid #f8fafc;
    cursor: pointer; transition: background 0.2s;
}
.notif-dropdown .notif-item:hover { background: #f8fafc; }
.notif-dropdown .notif-item.unread { background: #f0f9ff; border-left: 3px solid #4f46e5; }
.notif-dropdown .notif-item .notif-title { font-weight: 600; font-size: 0.85rem; color: #1e293b; }
.notif-dropdown .notif-item .notif-msg { font-size: 0.8rem; color: #64748b; margin-top: 2px; }
.notif-dropdown .notif-item .notif-time { font-size: 0.7rem; color: #94a3b8; margin-top: 4px; }
.notif-dropdown .notif-empty { padding: 30px; text-align: center; color: #94a3b8; }

/* Toast Popup Notifikasi (pop up di samping/pojok kanan) */
.toast-notif-container {
    position: fixed; top: 20px; right: 20px; z-index: 99999;
    display: flex; flex-direction: column; gap: 12px;
    width: 340px; max-width: calc(100vw - 40px);
}
.toast-notif {
    background: #fff; border-radius: 14px; padding: 14px 16px;
    box-shadow: 0 10px 35px rgba(0,0,0,0.18);
    border-left: 4px solid #4f46e5;
    display: flex; align-items: flex-start; gap: 12px;
    animation: toastIn 0.35s ease forwards;
    cursor: pointer;
}
.toast-notif.hide { animation: toastOut 0.3s ease forwards; }
.toast-notif .toast-icon {
    width: 36px; height: 36px; min-width: 36px; border-radius: 10px;
    background: #eef2ff; color: #4f46e5;
    display: flex; align-items: center; justify-content: center; font-size: 15px;
}
.toast-notif .toast-body { flex: 1; }
.toast-notif .toast-title { font-weight: 700; font-size: 0.85rem; color: #1e293b; margin-bottom: 2px; }
.toast-notif .toast-msg { font-size: 0.78rem; color: #64748b; line-height: 1.4; }
.toast-notif .toast-close {
    background: none; border: none; color: #94a3b8; font-size: 14px;
    cursor: pointer; padding: 0; line-height: 1;
}
@keyframes toastIn {
    from { opacity: 0; transform: translateX(40px); }
    to   { opacity: 1; transform: translateX(0); }
}
@keyframes toastOut {
    from { opacity: 1; transform: translateX(0); }
    to   { opacity: 0; transform: translateX(40px); }
}
</style>
</head>
<body>

<!-- Container Toast Notifikasi -->
<div class="toast-notif-container" id="toastContainer"></div>

<!-- Suara Notifikasi -->
<audio id="notifSound" preload="auto">
    <source src="https://cdn.jsdelivr.net/gh/naptha/sound-assets@main/notification-ping.mp3" type="audio/mpeg">
</audio>

<!-- SIDEBAR -->
<div class="sidebar">
<div>
<div class="sidebar-brand">
<div class="logo-icon"><i class="fas fa-book-reader"></i></div>
<div><h6 class="mb-0 text-white fw-bold">Petugas</h6><small class="text-muted" style="font-size: 11px;">Perpustakaan</small></div>
</div>
<ul class="nav-menu">
<li><a href="dashboard.php" class="active"><i class="fas fa-th-large"></i> Dashboard</a></li>
<li><a href="kondisi.php"><i class="fas fa-book-medical"></i> Cek Kondisi Buku</a></li>
<li><a href="transaksi.php"><i class="fas fa-exchange-alt"></i> Transaksi</a></li>
<li><a href="booking.php"><i class="fas fa-calendar-check"></i> Kelola Booking</a></li>
<li><a href="notifikasi.php"><i class="fas fa-bell"></i> Notifikasi</a></li>
<li><a href="profil.php"><i class="fas fa-user"></i> Profil Saya</a></li>
</ul>
</div>
<div class="sidebar-footer">
<a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');" class="text-danger mt-4"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">
<!-- TOP NAVBAR -->
<div class="top-navbar">
<div>
<h4 class="fw-bold text-dark mb-0">Panel Petugas Aktif</h4>
<small class="text-muted">Kelola dan setujui pengajuan peminjaman buku perpustakaan</small>
</div>
<div class="d-flex align-items-center gap-3">
<!-- NOTIFIKASI BELL -->
<div class="notif-bell" id="notifBell" style="position:relative;">
<i class="far fa-bell fs-5 text-dark"></i>
<span class="badge-notif" id="notifCount" style="display: <?= $notif_belum > 0 ? 'flex' : 'none' ?>;"><?= $notif_belum ?></span>
<!-- Dropdown Notifikasi -->
<div class="notif-dropdown" id="notifDropdown">
<div class="notif-header">
<strong class="text-dark">Notifikasi</strong>
<a href="notifikasi.php" class="text-primary small text-decoration-none">Lihat Semua</a>
</div>
<div id="notifList">
<?php if (count($notif_list) > 0): ?>
<?php foreach ($notif_list as $n): ?>
<div class="notif-item <?= $n['status'] === 'belum_dibaca' ? 'unread' : '' ?>">
<div class="notif-title"><?= htmlspecialchars($n['judul']) ?></div>
<div class="notif-msg"><?= htmlspecialchars(substr($n['pesan'], 0, 60)) ?>...</div>
<div class="notif-time"><i class="far fa-clock"></i> <?= $n['created_at'] ?></div>
</div>
<?php endforeach; ?>
<?php else: ?>
<div class="notif-empty"><i class="far fa-bell-slash fa-2x mb-2 d-block"></i>Tidak ada notifikasi</div>
<?php endif; ?>
</div>
</div>
</div>

<div class="dropdown">
<button class="btn btn-light d-flex align-items-center gap-2 rounded-pill px-3 py-1 border" type="button">
<span class="badge bg-primary rounded-circle p-2"><?php echo $inisial; ?></span>
<span class="fw-bold text-dark small"><?php echo $petugas_login; ?></span>
</button>
</div>
</div>
</div>

<!-- 4 KARTU STATISTIK -->
<div class="row g-3 mb-4">
<div class="col-md-3">
<div class="stat-card">
<span class="text-muted small">Total Anggota</span>
<h3 class="fw-bold text-dark mb-0 mt-1"><?php echo $total_anggota; ?></h3>
</div>
</div>
<div class="col-md-3">
<div class="stat-card">
<span class="text-muted small">Peminjaman Aktif</span>
<h3 class="fw-bold text-primary mb-0 mt-1"><?php echo $peminjaman_aktif; ?></h3>
</div>
</div>
<div class="col-md-3">
<div class="stat-card">
<span class="text-muted small">Booking Menunggu</span>
<h3 class="fw-bold text-warning mb-0 mt-1" style="color: #d97706 !important;"><?php echo $booking_menunggu; ?></h3>
</div>
</div>
<div class="col-md-3">
<div class="stat-card">
<span class="text-muted small">Total Koleksi Buku</span>
<h3 class="fw-bold text-success mb-0 mt-1"><?php echo $total_buku; ?></h3>
</div>
</div>
</div>

<!-- GRAFIK & INFO -->
<div class="row g-4">
<div class="col-lg-8">
<div class="card p-4 h-100">
<h5 class="fw-bold text-dark mb-3">Statistik Status Peminjaman Buku</h5>
<div class="chart-bar-container">
<div class="chart-column">
<span class="small fw-bold text-muted"><?php echo $jml_menunggu; ?></span>
<div class="bar bg-warning" style="height: <?php echo max(30, $jml_menunggu * 40); ?>px; background-color: #f59e0b !important;"></div>
<small class="text-muted text-center mt-2" style="font-size: 11px;">Menunggu Persetujuan</small>
</div>
<div class="chart-column">
<span class="small fw-bold text-muted"><?php echo $jml_dipinjam; ?></span>
<div class="bar bg-primary" style="height: <?php echo max(30, $jml_dipinjam * 40); ?>px;"></div>
<small class="text-muted text-center mt-2" style="font-size: 11px;">Sedang Dipinjam</small>
</div>
<div class="chart-column">
<span class="small fw-bold text-muted"><?php echo $jml_selesai; ?></span>
<div class="bar bg-success" style="height: <?php echo max(40, $jml_selesai * 40); ?>px;"></div>
<small class="text-muted text-center mt-2" style="font-size: 11px;">Sudah Dikembalikan</small>
</div>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="card p-4 h-100">
<h5 class="fw-bold text-dark mb-3"><i class="fas fa-info-circle text-primary me-2"></i> Informasi Sistem</h5>
<p class="text-muted small">Gunakan menu di sebelah kiri untuk mengelola cek kondisi buku, transaksi peminjaman, validasi booking, serta pengaturan profil.</p>
<div class="alert alert-primary bg-primary bg-opacity-10 border-0 text-primary small mt-3">
<i class="fas fa-user-shield me-1"></i> Anda masuk sebagai <strong><?php echo $petugas_login; ?></strong> dengan hak akses penuh modul petugas.
</div>
</div>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Notifikasi Bell Toggle
const notifBell = document.getElementById('notifBell');
const notifDropdown = document.getElementById('notifDropdown');

notifBell.addEventListener('click', function(e) {
    e.stopPropagation();
    notifDropdown.classList.toggle('show');
});

document.addEventListener('click', function(e) {
    if (!notifBell.contains(e.target)) {
        notifDropdown.classList.remove('show');
    }
});

// Polling notifikasi setiap 10 detik
let lastNotifId = <?= (int)($notif_list[0]['id_notif'] ?? 0) ?>;

// Suara notifikasi
function putarSuaraNotif() {
    const audio = document.getElementById('notifSound');
    audio.currentTime = 0;
    audio.play().catch(() => {}); // browser mungkin blokir autoplay sebelum ada interaksi user, aman diabaikan
}

// Tampilkan toast popup di pojok kanan
function tampilkanToastNotif(judul, pesan) {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast-notif';
    toast.innerHTML = `
        <div class="toast-icon"><i class="fas fa-bell"></i></div>
        <div class="toast-body">
            <div class="toast-title">${judul}</div>
            <div class="toast-msg">${pesan.length > 90 ? pesan.substring(0, 90) + '...' : pesan}</div>
        </div>
        <button class="toast-close" title="Tutup">&times;</button>
    `;
    container.appendChild(toast);

    const hapusToast = () => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 300);
    };

    toast.querySelector('.toast-close').addEventListener('click', (e) => {
        e.stopPropagation();
        hapusToast();
    });
    toast.addEventListener('click', () => { window.location.href = 'notifikasi.php'; });

    // Otomatis hilang setelah 6 detik
    setTimeout(hapusToast, 6000);
}

function checkNotifikasi() {
    fetch('get_notifikasi.php?action=check&last_id=' + lastNotifId)
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            const countEl = document.getElementById('notifCount');
            if (data.belum_dibaca > 0) {
                countEl.textContent = data.belum_dibaca;
                countEl.style.display = 'flex';
            } else {
                countEl.style.display = 'none';
            }

            if (data.ada_baru && data.data.length > 0) {
                const idTerakhirSebelumnya = lastNotifId;
                lastNotifId = data.max_id;

                // Tampilkan notifikasi baru di dropdown + toast popup + suara
                const notifList = document.getElementById('notifList');
                let adaNotifBaru = false;
                data.data.forEach(n => {
                    if (n.id_notif > idTerakhirSebelumnya) {
                        adaNotifBaru = true;
                        const item = document.createElement('div');
                        item.className = 'notif-item unread';
                        item.innerHTML = `
                            <div class="notif-title">${n.judul}</div>
                            <div class="notif-msg">${n.pesan.substring(0, 60)}...</div>
                            <div class="notif-time"><i class="far fa-clock"></i> ${n.created_at}</div>
                        `;
                        notifList.insertBefore(item, notifList.firstChild);

                        // Popup toast di samping + bunyi untuk tiap notifikasi baru
                        tampilkanToastNotif(n.judul, n.pesan);
                    }
                });
                if (adaNotifBaru) {
                    putarSuaraNotif();
                }
            }
        }
    })
    .catch(err => console.log('Notifikasi error:', err));
}

// Polling setiap 10 detik
setInterval(checkNotifikasi, 10000);
</script>
</body>
</html>