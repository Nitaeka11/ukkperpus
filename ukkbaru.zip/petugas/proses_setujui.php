<?php
/* =========================================================
   PROSES_SETUJUI_BOOKING.PHP — Admin/Petugas Menyetujui Booking
   Memindahkan data dari `booking` ke `peminjaman` (jadi Dipinjam)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

function kembali_dengan_pesan($tipe, $pesan) {
    $_SESSION['pesan']      = $pesan;
    $_SESSION['pesan_tipe'] = $tipe;
    header("Location: booking.php");
    exit();
}

// Auto-create tabel notifikasi jika belum ada
$cek_notif = mysqli_query($conn, "SHOW TABLES LIKE 'notifikasi'");
if (mysqli_num_rows($cek_notif) == 0) {
    mysqli_query($conn, "CREATE TABLE notifikasi (
        id_notif INT AUTO_INCREMENT PRIMARY KEY,
        judul VARCHAR(255) NOT NULL,
        pesan TEXT,
        tipe VARCHAR(50) DEFAULT 'umum',
        status VARCHAR(50) DEFAULT 'belum_dibaca',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

$id_booking = (int) ($_GET['id'] ?? 0);
if (!$id_booking) {
    kembali_dengan_pesan('error', 'ID booking tidak valid.');
}

// Ambil data booking
$stmt = mysqli_prepare($conn, "SELECT * FROM booking WHERE id_booking = ? AND status = 'Menunggu'");
mysqli_stmt_bind_param($stmt, "i", $id_booking);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking) {
    kembali_dengan_pesan('error', 'Data booking tidak ditemukan atau sudah diproses.');
}

// Cek stok buku dulu sebelum menyetujui
$cek_stok = mysqli_prepare($conn, "SELECT stok FROM buku WHERE id_buku = ?");
mysqli_stmt_bind_param($cek_stok, "i", $booking['id_buku']);
mysqli_stmt_execute($cek_stok);
$buku = mysqli_fetch_assoc(mysqli_stmt_get_result($cek_stok));

if (!$buku || (int) $buku['stok'] <= 0) {
    kembali_dengan_pesan('error', 'Stok buku "' . $booking['judul_buku'] . '" sedang habis, tidak bisa disetujui.');
}

mysqli_begin_transaction($conn);
try {
    $tgl_pinjam      = date('Y-m-d');
    $tgl_hrs_kembali = date('Y-m-d', strtotime('+7 days'));

    // 1. Masukkan ke tabel peminjaman
    $insert = mysqli_prepare($conn, "INSERT INTO peminjaman
        (id_anggota, id_buku, tgl_booking, tgl_pinjam, tgl_hrs_kembali, status, kondisi_buku, denda_per_hari)
        VALUES (?, ?, ?, ?, ?, 'Dipinjam', 'Baik', 1000)");
    mysqli_stmt_bind_param($insert, "iisss",
        $booking['id_anggota'], $booking['id_buku'], $booking['tanggal_booking'], $tgl_pinjam, $tgl_hrs_kembali
    );
    mysqli_stmt_execute($insert);

    // 2. Kurangi stok buku
    $update_stok = mysqli_prepare($conn, "UPDATE buku SET stok = stok - 1 WHERE id_buku = ? AND stok > 0");
    mysqli_stmt_bind_param($update_stok, "i", $booking['id_buku']);
    mysqli_stmt_execute($update_stok);

    // 3. Tandai booking sebagai Dipinjam (bukan dihapus, supaya tetap ada riwayatnya)
    $update_booking = mysqli_prepare($conn, "UPDATE booking SET status = 'Dipinjam' WHERE id_booking = ?");
    mysqli_stmt_bind_param($update_booking, "i", $id_booking);
    mysqli_stmt_execute($update_booking);

    // ✅ Catat notifikasi bahwa booking sudah disetujui
    $judul_notif = 'Booking Disetujui';
    $pesan_notif = "Booking \"{$booking['judul_buku']}\" atas nama {$booking['nama_anggota']} telah disetujui.";
    $stmt_notif = mysqli_prepare($conn, "INSERT INTO notifikasi (judul, pesan, tipe, status, created_at) VALUES (?, ?, 'booking', 'belum_dibaca', NOW())");
    mysqli_stmt_bind_param($stmt_notif, "ss", $judul_notif, $pesan_notif);
    mysqli_stmt_execute($stmt_notif);

    mysqli_commit($conn);
    kembali_dengan_pesan('success', "Booking \"{$booking['judul_buku']}\" atas nama {$booking['nama_anggota']} berhasil disetujui.");
} catch (Throwable $e) {
    mysqli_rollback($conn);
    kembali_dengan_pesan('error', 'Gagal menyetujui booking: ' . $e->getMessage());
}