<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

// Auto-create tabel notifikasi jika belum ada
$cek_notif = mysqli_query($conn, "SHOW TABLES LIKE 'notifikasi'");
if (mysqli_num_rows($cek_notif) == 0) {
    mysqli_query($conn, "CREATE TABLE notifikasi (
        id_notif INT AUTO_INCREMENT PRIMARY KEY,
        judul VARCHAR(255) NOT NULL,
        pesan TEXT,
        tipe VARCHAR(50) DEFAULT 'umum',
        status VARCHAR(50) DEFAULT 'belum_dibaca',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

// Proses Setujui / Tolak
if (isset($_GET['aksi']) && isset($_GET['id'])) {
    $id_peminjaman = mysqli_real_escape_string($conn, $_GET['id']);
    $aksi = $_GET['aksi'];

    // Ambil data peminjaman untuk notifikasi
    $q_data = mysqli_query($conn, "SELECT p.*, a.nama_lengkap, b.judul_buku FROM peminjaman p JOIN anggota a ON p.id_anggota = a.id_anggota JOIN buku b ON p.id_buku = b.id_buku WHERE p.id_peminjaman = '$id_peminjaman'");
    $data_pinjam = mysqli_fetch_assoc($q_data);

    if ($aksi == 'setuju') {
        $update = mysqli_query($conn, "UPDATE peminjaman SET status = 'Dipinjam' WHERE id_peminjaman = '$id_peminjaman'");
        if ($update) {
            // ✅ Notifikasi booking disetujui
            $nama = $data_pinjam['nama_lengkap'] ?? 'Anggota';
            $judul = $data_pinjam['judul_buku'] ?? 'Buku';
            mysqli_query($conn, "INSERT INTO notifikasi (judul, pesan, tipe, status, created_at) VALUES ('Booking Disetujui', 'Peminjaman buku \"$judul\" oleh $nama telah disetujui.', 'peminjaman', 'belum_dibaca', NOW())");
            header("location: kelola_booking.php?notif=sukses_setuju");
            exit();
        }
    } elseif ($aksi == 'tolak') {
        $update = mysqli_query($conn, "UPDATE peminjaman SET status = 'Ditolak' WHERE id_peminjaman = '$id_peminjaman'");
        if ($update) {
            $nama = $data_pinjam['nama_lengkap'] ?? 'Anggota';
            $judul = $data_pinjam['judul_buku'] ?? 'Buku';
            mysqli_query($conn, "INSERT INTO notifikasi (judul, pesan, tipe, status, created_at) VALUES ('Booking Ditolak', 'Peminjaman buku \"$judul\" oleh $nama telah ditolak.', 'peminjaman', 'belum_dibaca', NOW())");
            header("location: kelola_booking.php?notif=sukses_tolak");
            exit();
        }
    }
}

$query_booking = mysqli_query($conn, "SELECT p.*, a.nama_lengkap, a.nis, b.judul_buku, b.kode_buku
FROM peminjaman p
JOIN anggota a ON p.id_anggota = a.id_anggota
JOIN buku b ON p.id_buku = b.id_buku
WHERE p.status = 'Menunggu Persetujuan'
ORDER BY p.tgl_booking DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Booking & Validasi - Petugas</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
body { font-family: 'Poppins', sans-serif; background-color: #f8fafc; }
.main-content { padding: 30px; }
.card-custom { border: none; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); background: #ffffff; }
.table tr td { vertical-align: middle; }
.badge-status { background-color: #fef3c7; color: #d97706; font-weight: 600; padding: 6px 12px; border-radius: 8px; font-size: 0.8rem; }
.btn-purple { background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%); color: white; border: none; }
.btn-purple:hover { background: linear-gradient(135deg, #6d28d9 0%, #9333ea 100%); color: white; }
</style>
</head>
<body>
<div class="container-fluid main-content">
<div class="d-flex justify-content-between align-items-center mb-4">
<div><h3 class="fw-bold text-dark mb-1">Kelola Booking & Validasi</h3><p class="text-muted mb-0" style="font-size:0.9rem;">Daftar buku yang diajukan pinjam/booking oleh anggota perpustakaan.</p></div>
<a href="dashboard.php" class="btn btn-outline-secondary btn-sm rounded-pill px-3"><i class="bi bi-arrow-left"></i> Kembali ke Dashboard</a>
</div>

<div class="card card-custom p-4">
<div class="table-responsive">
<table class="table table-hover">
<thead class="table-light">
<tr><th>No</th><th>Nama Anggota (NIS)</th><th>Kode & Judul Buku</th><th>Waktu Booking</th><th>Status</th><th class="text-center">Aksi Validasi</th></tr>
</thead>
<tbody>
<?php if (mysqli_num_rows($query_booking) > 0): ?>
<?php $no = 1; while ($row = mysqli_fetch_assoc($query_booking)): ?>
<tr>
<td><?php echo $no++; ?></td>
<td><div class="fw-bold text-dark"><?php echo htmlspecialchars($row['nama_lengkap']); ?></div><small class="text-muted">NIS: <?php echo htmlspecialchars($row['nis']); ?></small></td>
<td><div class="fw-bold" style="color:#7c3aed;"><?php echo htmlspecialchars($row['judul_buku']); ?></div><small class="text-muted">Kode: <?php echo htmlspecialchars($row['kode_buku']); ?></small></td>
<td><?php echo $row['tgl_booking']; ?></td>
<td><span class="badge-status"><i class="bi bi-clock-history"></i> <?php echo $row['status']; ?></span></td>
<td class="text-center">
<a href="kelola_booking.php?aksi=setuju&id=<?php echo $row['id_peminjaman']; ?>" class="btn btn-success btn-sm px-3 rounded-pill me-1" onclick="return confirm('Setujui peminjaman buku ini?')"><i class="bi bi-check-lg"></i> Setujui</a>
<a href="kelola_booking.php?aksi=tolak&id=<?php echo $row['id_peminjaman']; ?>" class="btn btn-danger btn-sm px-3 rounded-pill" onclick="return confirm('Tolak peminjaman buku ini?')"><i class="bi bi-x-lg"></i> Tolak</a>
</td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr><td colspan="6" class="text-center text-muted py-5"><i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>Belum ada pengajuan booking atau peminjaman baru saat ini.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>

<script>
const urlParams = new URLSearchParams(window.location.search);
const notif = urlParams.get('notif');
if (notif === 'sukses_setuju') {
    Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Peminjaman buku telah disetujui (Status: Dipinjam).', confirmButtonColor: '#7c3aed', timer: 2000 });
} else if (notif === 'sukses_tolak') {
    Swal.fire({ icon: 'info', title: 'Ditolak', text: 'Pengajuan peminjaman buku telah ditolak.', confirmButtonColor: '#ef4444', timer: 2000 });
}
</script>
</body>
</html>