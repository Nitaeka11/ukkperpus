<?php
/* =========================================================
   BOOKING.PHP — Kelola Booking (Petugas)
   Sumber data: tabel `booking`
   Status lifecycle: Menunggu -> Dipinjam (disetujui) / Ditolak
                      -> Dikembalikan (setelah buku dikembalikan)
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

$nama_petugas = $_SESSION['nama'] ?? 'Petugas';
$current_page = basename($_SERVER['PHP_SELF']);

// --- Statistik ---
$total_pengajuan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM booking"))['total'] ?? 0;
$menunggu        = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM booking WHERE status = 'Menunggu'"))['total'] ?? 0;
$selesai         = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM booking WHERE status = 'Dikembalikan'"))['total'] ?? 0;

// --- Filter tab & pencarian ---
$filter = $_GET['filter'] ?? 'Semua';
$cari   = trim($_GET['cari'] ?? '');

$where  = [];
$params = [];
$types  = '';

if ($filter !== 'Semua') {
    $where[] = "status = ?";
    $params[] = $filter;
    $types .= 's';
}
if ($cari !== '') {
    $where[] = "(nama_anggota LIKE ? OR kode_booking LIKE ? OR judul_buku LIKE ?)";
    $like = "%$cari%";
    array_push($params, $like, $like, $like);
    $types .= 'sss';
}

$sql = "SELECT * FROM booking";
if ($where) $sql .= " WHERE " . implode(' AND ', $where);
$sql .= " ORDER BY tanggal_booking DESC";

$stmt = mysqli_prepare($conn, $sql);
if ($params) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$daftar = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Booking - Sistem Perpustakaan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
  :root { --bg-sidebar:#14131f; --accent:#6366f1; --bg-content:#F5F7FB; --card-bg:#fff; --text-main:#1E293B; --text-muted-custom:#94A3B8; --border-light:#F1F5F9; }
  * { box-sizing:border-box; }
  body { background:var(--bg-content); color:var(--text-main); font-family:'Segoe UI',Arial,sans-serif; margin:0; }

  .sidebar { width:260px; height:100vh; position:fixed; top:0; left:0; background:var(--bg-sidebar); padding:24px 16px; display:flex; flex-direction:column; z-index:1000; overflow-y:auto; }
  .sidebar .brand { display:flex; align-items:center; gap:12px; padding:8px 12px; margin-bottom:26px; }
  .sidebar .brand-icon { width:42px; height:42px; background:var(--accent); border-radius:12px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:1.2rem; }
  .sidebar .brand h6 { color:#fff; margin-bottom:0; }
  .sidebar .brand small { color:var(--text-muted-custom); }
  .sidebar .nav.flex-column { list-style:none; padding:0; margin:0; flex-grow:1; }
  .sidebar .nav-item { margin-bottom:6px; list-style:none; }
  .sidebar .nav-item a { display:flex; align-items:center; gap:14px; padding:13px 16px; color:var(--text-muted-custom); text-decoration:none; font-size:14.5px; font-weight:500; border-radius:12px; transition:.2s; }
  .sidebar .nav-item a:hover { background:rgba(99,102,241,.15); color:#fff; }
  .sidebar .nav-item a.active { background:var(--accent); color:#fff; box-shadow:0 4px 15px rgba(79,70,229,.4); }
  .sidebar .logout-btn { color:#f87171 !important; }
  .sidebar .logout-btn:hover { background:rgba(239,68,68,.15) !important; }

  .main-content { margin-left:260px; padding:30px 34px; min-height:100vh; }
  .content-card { background:var(--card-bg); border-radius:16px; padding:24px; box-shadow:0 4px 20px rgba(0,0,0,.03); border:1px solid var(--border-light); }

  .card-stat { background:var(--card-bg); border-radius:16px; padding:20px 22px; box-shadow:0 4px 20px rgba(0,0,0,.03); border:1px solid var(--border-light); height:100%; }
  .card-stat .title-stat { font-size:13px; color:var(--text-muted-custom); font-weight:500; display:block; margin-bottom:8px; }
  .card-stat .value-stat { font-size:26px; font-weight:700; }
  .card-stat .sub-stat { font-size:12px; color:var(--text-muted-custom); }

  .tab-filter { display:flex; gap:8px; margin-bottom:20px; flex-wrap:wrap; }
  .tab-filter a { padding:9px 18px; border-radius:10px; font-size:13.5px; font-weight:600; text-decoration:none; color:#475569; background:#f1f5f9; }
  .tab-filter a.active { background:var(--accent); color:#fff; }

  .table-custom thead th { font-size:11.5px; text-transform:uppercase; letter-spacing:.03em; color:var(--text-muted-custom); border-bottom:2px solid var(--border-light); padding:12px 14px; background:transparent; }
  .table-custom tbody td { padding:14px; font-size:14px; vertical-align:middle; border-bottom:1px solid var(--border-light); }
  .kode-link { color:#6366f1; font-weight:700; text-decoration:none; }

  .badge-menunggu { background:#fef3c7; color:#b45309; font-size:12px; font-weight:600; padding:5px 12px; border-radius:20px; }
  .badge-dipinjam { background:#dbeafe; color:#1d4ed8; font-size:12px; font-weight:600; padding:5px 12px; border-radius:20px; }
  .badge-ditolak { background:#fee2e2; color:#b91c1c; font-size:12px; font-weight:600; padding:5px 12px; border-radius:20px; }
  .badge-dikembalikan { background:#dcfce7; color:#15803d; font-size:12px; font-weight:600; padding:5px 12px; border-radius:20px; }

  .aksi-cell { display:flex; justify-content:flex-end; align-items:center; gap:8px; flex-wrap:nowrap; }
  .btn-setuju, .btn-tolak { display:inline-flex; align-items:center; justify-content:center; gap:5px; white-space:nowrap; border:none; padding:7px 14px; border-radius:8px; font-size:12.5px; font-weight:600; line-height:1.4; text-decoration:none; }
  .btn-setuju { background:#22c55e; color:#fff; }
  .btn-setuju:hover { background:#16a34a; color:#fff; }
  .btn-tolak { background:#ef4444; color:#fff; }
  .btn-tolak:hover { background:#dc2626; color:#fff; }
  .table-custom td.text-end { min-width:190px; }
  .search-box { border-radius:10px; border:1px solid #E2E8F0; padding:9px 14px; font-size:13.5px; }
  .btn-tambah { background:var(--accent); color:#fff; border:none; padding:10px 18px; border-radius:10px; font-weight:600; font-size:13.5px; text-decoration:none; display:inline-flex; align-items:center; gap:6px; }

  @media (max-width:900px){ .sidebar{width:220px;} .main-content{margin-left:220px; padding:20px;} }
</style>
</head>
<body>

<div class="sidebar">
    <div class="brand">
        <div class="brand-icon"><i class="fa-solid fa-book-open"></i></div>
        <div><h6 class="mb-0 fw-bold">Petugas</h6><small>Perpustakaan</small></div>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="dashboard.php" class="<?= $current_page=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-house"></i> Dashboard</a></li>
        <li class="nav-item"><a href="kondisi.php" class="<?= $current_page=='kondisi.php'?'active':'' ?>"><i class="fa-solid fa-clipboard-check"></i> Cek Kondisi Buku</a></li>
        <li class="nav-item"><a href="transaksi.php" class="<?= $current_page=='transaksi.php'?'active':'' ?>"><i class="fa-solid fa-right-left"></i> Transaksi</a></li>
        <li class="nav-item"><a href="booking.php" class="<?= $current_page=='booking.php'?'active':'' ?>"><i class="fa-solid fa-calendar-days"></i> Kelola Booking</a></li>
        <li class="nav-item"><a href="notifikasi.php" class="<?= $current_page=='notifikasi.php'?'active':'' ?>"><i class="fa-solid fa-bell"></i> Notifikasi</a></li>
        <li class="nav-item"><a href="profil.php" class="<?= $current_page=='profil.php'?'active':'' ?>"><i class="fa-solid fa-user"></i> Profil Saya</a></li>
    </ul>
    <a href="../logout.php" class="nav-item" style="display:flex;align-items:center;gap:14px;padding:13px 16px;text-decoration:none;" onclick="return confirm('Yakin ingin keluar?');">
        <span class="logout-btn" style="display:flex;align-items:center;gap:14px;"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</span>
    </a>
</div>

<div class="main-content">
    <h4 class="fw-bold mb-1">Kelola Booking</h4>
    <p class="mb-4" style="color:var(--text-muted-custom);">Kelola dan setujui pengajuan pemesanan buku perpustakaan.</p>

    <?php if (isset($_SESSION['pesan'])): ?>
        <div class="alert alert-<?= $_SESSION['pesan_tipe'] == 'success' ? 'success' : 'danger' ?> alert-dismissible fade show">
            <?= htmlspecialchars($_SESSION['pesan']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['pesan'], $_SESSION['pesan_tipe']); ?>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card-stat">
                <div class="title-stat">Total Pengajuan</div>
                <div class="value-stat"><?= $total_pengajuan ?></div>
                <div class="sub-stat">Semua Transaksi</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-stat">
                <div class="title-stat">Menunggu Persetujuan</div>
                <div class="value-stat" style="color:#f59e0b;"><?= $menunggu ?></div>
                <div class="sub-stat">Perlu Tindakan</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-stat">
                <div class="title-stat">Sudah Dikembalikan / Selesai</div>
                <div class="value-stat" style="color:#22c55e;"><?= $selesai ?></div>
                <div class="sub-stat">Selesai</div>
            </div>
        </div>
    </div>

    <div class="content-card">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3">
            <div>
                <h5 class="fw-bold mb-1">Daftar Persetujuan Peminjaman</h5>
                <small style="color:var(--text-muted-custom);">Kelola status pemesanan buku dari anggota</small>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <form method="GET" class="d-flex gap-2">
                    <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                    <input type="text" name="cari" class="form-control search-box" placeholder="Cari nama / kode..." value="<?= htmlspecialchars($cari) ?>">
                    <button type="submit" class="btn btn-light border"><i class="fa-solid fa-search"></i></button>
                </form>
                <a href="tambah_booking.php" class="btn-tambah"><i class="fa-solid fa-plus"></i> Tambah Booking</a>
            </div>
        </div>

        <div class="tab-filter">
            <?php foreach (['Semua','Menunggu','Dipinjam','Dikembalikan'] as $tab): ?>
                <a href="?filter=<?= $tab ?>&cari=<?= urlencode($cari) ?>" class="<?= $filter==$tab?'active':'' ?>"><?= $tab ?></a>
            <?php endforeach; ?>
        </div>

        <div class="table-responsive">
            <table class="table table-custom align-middle mb-0">
                <thead>
                    <tr><th>Kode Booking</th><th>Nama Anggota</th><th>Judul Buku</th><th>Tgl Booking</th><th>Batas Ambil</th><th>Status</th><th class="text-end">Aksi</th></tr>
                </thead>
                <tbody>
                    <?php if ($daftar && mysqli_num_rows($daftar) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($daftar)):
                            $status = $row['status'];
                            $kelas_badge = [
                                'Menunggu' => 'badge-menunggu',
                                'Dipinjam' => 'badge-dipinjam',
                                'Ditolak' => 'badge-ditolak',
                                'Dikembalikan' => 'badge-dikembalikan',
                            ][$status] ?? 'badge-menunggu';
                        ?>
                        <tr>
                            <td><a href="#" class="kode-link"><?= htmlspecialchars($row['kode_booking']) ?></a></td>
                            <td>
                                <div class="fw-semibold"><?= htmlspecialchars($row['nama_anggota']) ?></div>
                                <div class="small" style="color:var(--text-muted-custom);">ID: <?= $row['id_anggota'] ?></div>
                            </td>
                            <td>
                                <?= htmlspecialchars($row['judul_buku']) ?>
                                <div class="small" style="color:var(--text-muted-custom);">Kode: <?= htmlspecialchars($row['kode_buku']) ?></div>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['tanggal_booking'])) ?></td>
                            <td><?= !empty($row['batas_ambil']) ? date('d/m/Y', strtotime($row['batas_ambil'])) : '-' ?></td>
                            <td><span class="<?= $kelas_badge ?>"><?= htmlspecialchars($status) ?></span></td>
                            <td class="text-end">
                                <?php if ($status === 'Menunggu'): ?>
                                    <div class="aksi-cell">
                                        <a href="proses_setujui.php?id=<?= $row['id_booking'] ?>" class="btn-setuju" onclick="return confirm('Setujui booking ini? Buku akan pindah ke status Dipinjam.');"><i class="fa-solid fa-check"></i> Setujui</a>
                                        <a href="proses_tolak.php?id=<?= $row['id_booking'] ?>" class="btn-tolak" onclick="return confirm('Tolak booking ini?');"><i class="fa-solid fa-xmark"></i> Tolak</a>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">Tidak ada data booking.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>