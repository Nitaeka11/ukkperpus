<?php
session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

$koneksi = $conn; // alias supaya query di bawah (yang sudah pakai $koneksi) tetap jalan tanpa diubah semua

// Ambil id_petugas dari session yang sudah login (bukan default ke ID 2 lagi)
if (!isset($_SESSION['id_petugas'])) {
    header("location: ../login.php");
    exit();
}
$id_petugas_login = $_SESSION['id_petugas'];
$pesan_sukses = "";
$pesan_error = "";

// Auto-create tabel notifikasi jika belum ada
$cek_notif = mysqli_query($koneksi, "SHOW TABLES LIKE 'notifikasi'");
if (mysqli_num_rows($cek_notif) == 0) {
    mysqli_query($koneksi, "CREATE TABLE notifikasi (
        id_notif INT AUTO_INCREMENT PRIMARY KEY,
        judul VARCHAR(255) NOT NULL,
        pesan TEXT,
        tipe VARCHAR(50) DEFAULT 'umum',
        status VARCHAR(50) DEFAULT 'belum_dibaca',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

// Hitung notifikasi belum dibaca untuk badge
$q_notif_belum = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM notifikasi WHERE status = 'belum_dibaca'");
$notif_belum_dibaca = mysqli_fetch_assoc($q_notif_belum)['jml'] ?? 0;

// PROSES UPDATE PROFIL
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profil'])) {
    $nama_petugas = mysqli_real_escape_string($koneksi, $_POST['nama_petugas']);
    $email        = mysqli_real_escape_string($koneksi, $_POST['email']);
    $no_hp        = mysqli_real_escape_string($koneksi, $_POST['no_hp']);
    $query_update = "UPDATE petugas SET nama_petugas = '$nama_petugas', email = '$email', no_hp = '$no_hp' WHERE id_petugas = '$id_petugas_login'";
    if (mysqli_query($koneksi, $query_update)) {
        $pesan_sukses = "Profil berhasil diperbarui!";
    } else {
        $pesan_error = "Gagal memperbarui profil: " . mysqli_error($koneksi);
    }
}

// AMBIL DATA PETUGAS DARI DATABASE
$query = mysqli_query($koneksi, "SELECT * FROM petugas WHERE id_petugas = '$id_petugas_login'");
$petugas = mysqli_fetch_assoc($query);

// Inisial nama untuk avatar
$words = explode(" ", $petugas['nama_petugas']);
$inisial = strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil Saya - Sistem Perpustakaan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --sidebar-bg: #121629;
    --primary-color: #4f46e5;
    --primary-hover: #4338ca;
    --bg-body: #f4f5f7;
}
body {
    background-color: var(--bg-body);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    overflow-x: hidden;
}
.sidebar {
    width: 260px;
    height: 100vh;
    background-color: var(--sidebar-bg);
    position: fixed;
    top: 0;
    left: 0;
    color: #fff;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    z-index: 1000;
}
.sidebar-brand {
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}
.sidebar-brand .logo-icon {
    background-color: var(--primary-color);
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    color: white;
    font-size: 1.2rem;
}
.nav-menu {
    padding: 10px 15px;
    list-style: none;
    margin: 0;
    flex-grow: 1;
}
.nav-menu li a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 15px;
    color: #94a3b8;
    text-decoration: none;
    border-radius: 10px;
    font-weight: 500;
    transition: all 0.2s ease;
    margin-bottom: 5px;
}
.nav-menu li a:hover, .nav-menu li a.active {
    background-color: var(--primary-color);
    color: white;
}
.sidebar-footer {
    padding: 20px;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}
.sidebar-footer a {
    color: #94a3b8;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 15px;
    border-radius: 10px;
    transition: 0.2s;
}
.sidebar-footer a:hover {
    background-color: rgba(239, 68, 68, 0.1);
    color: #ef4444;
}
.main-content {
    margin-left: 260px;
    padding: 30px;
}
.top-navbar {
    background: white;
    padding: 15px 30px;
    border-radius: 15px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.02);
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}
.card {
    border: none;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
    border-radius: 15px;
    background: white;
}
.profile-header-card {
    background: linear-gradient(135deg, var(--primary-color) 0%, #6366f1 100%);
    color: white;
    padding: 30px 20px;
    border-radius: 15px 15px 0 0;
    text-align: center;
}
.profile-avatar-placeholder {
    width: 90px;
    height: 90px;
    background: rgba(255, 255, 255, 0.2);
    border: 3px solid #fff;
    color: white;
    font-size: 2rem;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    margin: 0 auto 15px auto;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}
.btn-primary {
    background-color: var(--primary-color);
    border: none;
}
.btn-primary:hover {
    background-color: var(--primary-hover);
}
/* Notifikasi Bell */
.notif-bell-wrapper { position: relative; }
.badge-notif-count {
    position: absolute; top: -8px; right: -8px;
    background: #ef4444; color: #fff;
    font-size: 10px; font-weight: 700;
    min-width: 18px; height: 18px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    border: 2px solid #fff;
    animation: pulseNotif 2s infinite;
}
@keyframes pulseNotif { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.15); } }
</style>
</head>
<body>
<!-- SIDEBAR -->
<div class="sidebar">
<div>
<div class="sidebar-brand">
<div class="logo-icon"><i class="fas fa-book-reader"></i></div>
<div>
<h6 class="mb-0 text-white fw-bold">Petugas</h6>
<small class="text-muted" style="font-size: 11px;">Perpustakaan</small>
</div>
</div>
<ul class="nav-menu">
<li><a href="dashboard.php"><i class="fas fa-th-large"></i> Dashboard</a></li>
<li><a href="kondisi.php"><i class="fas fa-book-medical"></i> Cek Kondisi Buku</a></li>
<li><a href="transaksi.php"><i class="fas fa-exchange-alt"></i> Transaksi</a></li>
<li><a href="booking.php"><i class="fas fa-calendar-check"></i> Kelola Booking</a></li>
<li><a href="notifikasi.php">
<i class="fas fa-bell"></i> Notifikasi
<?php if ($notif_belum_dibaca > 0): ?>
<span class="badge bg-danger rounded-pill ms-1" style="font-size:10px;"><?= $notif_belum_dibaca ?></span>
<?php endif; ?>
</a></li>
<li><a href="profil.php" class="active"><i class="fas fa-user"></i> Profil Saya</a></li>
</ul>
</div>
<div class="sidebar-footer">
                <a href="../logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?');" class="text-danger mt-4"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">
<!-- TOP NAVBAR -->
<div class="top-navbar">
<div>
<h4 class="fw-bold text-dark mb-0">Database Perpusku</h4>
<small class="text-muted">Panel Pengaturan Profil Petugas Aktif</small>
</div>
<div class="d-flex align-items-center gap-3">
<!-- Notifikasi Bell dengan Badge -->
<div class="notif-bell-wrapper">
<a href="notifikasi.php" class="text-dark text-decoration-none fs-4 position-relative">
<i class="far fa-bell"></i>
<?php if ($notif_belum_dibaca > 0): ?>
<span class="badge-notif-count"><?= $notif_belum_dibaca ?></span>
<?php endif; ?>
</a>
</div>
<div class="dropdown">
<button class="btn btn-light d-flex align-items-center gap-2 rounded-pill px-3 py-1 border" type="button">
<span class="badge bg-primary rounded-circle p-2"><?= $inisial ?></span>
<span class="fw-bold text-dark small"><?= htmlspecialchars($petugas['nama_petugas']); ?></span>
</button>
</div>
</div>
</div>

<!-- NOTIFIKASI ALERT -->
<?php if (!empty($pesan_sukses)): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
<i class="fas fa-check-circle me-2"></i> <?php echo $pesan_sukses; ?>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if (!empty($pesan_error)): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
<i class="fas fa-exclamation-circle me-2"></i> <?php echo $pesan_error; ?>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<!-- KONTEN PROFIL -->
<div class="row g-4">
<div class="col-lg-4">
<div class="card mb-4">
<div class="profile-header-card">
<div class="profile-avatar-placeholder"><?= $inisial ?></div>
<h5 class="mb-1 fw-bold"><?= htmlspecialchars($petugas['nama_petugas']); ?></h5>
<p class="text-light opacity-75 mb-2 small"><i class="fas fa-id-badge me-1"></i> ID Petugas: <?= $petugas['id_petugas']; ?></p>
<span class="badge bg-white text-success px-3 py-1 rounded-pill">
<i class="fas fa-circle text-success me-1" style="font-size: 7px;"></i> Aktif
</span>
</div>
<div class="card-body p-4">
<h6 class="text-muted text-uppercase fs-7 fw-bold mb-3" style="font-size: 11px;">Informasi Akun</h6>
<ul class="list-unstyled mb-0 small">
<li class="mb-3"><i class="fas fa-user-shield text-primary me-2"></i> <strong>Username:</strong><br><span class="text-muted ms-4"><?= htmlspecialchars($petugas['username']); ?></span></li>
<li class="mb-3"><i class="fas fa-calendar-alt text-primary me-2"></i> <strong>Terdaftar Sejak:</strong><br><span class="text-muted ms-4"><?= $petugas['created_at']; ?></span></li>
<li class="mb-0"><i class="fas fa-clock text-primary me-2"></i> <strong>Terakhir Update:</strong><br><span class="text-muted ms-4"><?= $petugas['updated_at']; ?></span></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-8">
<div class="card p-4 h-100">
<div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
<h5 class="fw-bold text-dark m-0"><i class="fas fa-user-edit text-primary me-2"></i> Pengaturan Profil Petugas</h5>
<span class="text-muted small">Tabel: <code>petugas</code></span>
</div>
<form action="" method="POST">
<div class="row mb-3">
<div class="col-md-6">
<label class="form-label text-muted small fw-bold">ID Petugas (Read-only)</label>
<input type="text" class="form-control bg-light" value="<?= $petugas['id_petugas']; ?>" readonly>
</div>
<div class="col-md-6">
<label class="form-label text-muted small fw-bold">Username (Read-only)</label>
<input type="text" class="form-control bg-light" value="<?= htmlspecialchars($petugas['username']); ?>" readonly>
</div>
</div>
<div class="mb-3">
<label class="form-label text-muted small fw-bold">Nama Lengkap (`nama_petugas`)</label>
<input type="text" class="form-control" name="nama_petugas" value="<?= htmlspecialchars($petugas['nama_petugas']); ?>" required>
</div>
<div class="row mb-3">
<div class="col-md-6">
<label class="form-label text-muted small fw-bold">Alamat Email (`email`)</label>
<input type="email" class="form-control" name="email" value="<?= htmlspecialchars($petugas['email'] ?? ''); ?>" placeholder="email@domain.com">
</div>
<div class="col-md-6">
<label class="form-label text-muted small fw-bold">Nomor HP / WhatsApp (`no_hp`)</label>
<input type="text" class="form-control" name="no_hp" value="<?= htmlspecialchars($petugas['no_hp'] ?? ''); ?>" placeholder="08xxxxxxxxxx">
</div>
</div>
<div class="mt-4 text-end">
<button type="submit" name="update_profil" class="btn btn-primary px-4 py-2">
<i class="fas fa-save me-1"></i> Simpan Perubahan
</button>
</div>
</form>
</div>
</div>
</div>

</div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>