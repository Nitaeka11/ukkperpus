<?php
/* =========================================================
   PROSES_TOLAK_BOOKING.PHP — Admin/Petugas Menolak Booking
   ========================================================= */

session_start();
include "../config/koneksi.php";

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location: ../login.php");
    exit();
}

function kembali_dengan_pesan($tipe, $pesan) {
    $_SESSION['pesan']      = $pesan;
    $_SESSION['pesan_tipe'] = $tipe;
    header("Location: booking.php");
    exit();
}

// Auto-create tabel notifikasi jika belum ada
$cek_notif = mysqli_query($conn, "SHOW TABLES LIKE 'notifikasi'");
if (mysqli_num_rows($cek_notif) == 0) {
    mysqli_query($conn, "CREATE TABLE notifikasi (
        id_notif INT AUTO_INCREMENT PRIMARY KEY,
        judul VARCHAR(255) NOT NULL,
        pesan TEXT,
        tipe VARCHAR(50) DEFAULT 'umum',
        status VARCHAR(50) DEFAULT 'belum_dibaca',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

$id_booking = (int) ($_GET['id'] ?? 0);
if (!$id_booking) {
    kembali_dengan_pesan('error', 'ID booking tidak valid.');
}

// Ambil data booking dulu untuk keperluan pesan notifikasi
$q_data = mysqli_prepare($conn, "SELECT * FROM booking WHERE id_booking = ? AND status = 'Menunggu'");
mysqli_stmt_bind_param($q_data, "i", $id_booking);
mysqli_stmt_execute($q_data);
$data_booking = mysqli_fetch_assoc(mysqli_stmt_get_result($q_data));

$stmt = mysqli_prepare($conn, "UPDATE booking SET status = 'Ditolak' WHERE id_booking = ? AND status = 'Menunggu'");
mysqli_stmt_bind_param($stmt, "i", $id_booking);

if (mysqli_stmt_execute($stmt) && mysqli_affected_rows($conn) > 0) {
    // ✅ Catat notifikasi bahwa booking ditolak
    if ($data_booking) {
        $judul_notif = 'Booking Ditolak';
        $pesan_notif = "Booking \"{$data_booking['judul_buku']}\" atas nama {$data_booking['nama_anggota']} telah ditolak.";
        $stmt_notif = mysqli_prepare($conn, "INSERT INTO notifikasi (judul, pesan, tipe, status, created_at) VALUES (?, ?, 'booking', 'belum_dibaca', NOW())");
        mysqli_stmt_bind_param($stmt_notif, "ss", $judul_notif, $pesan_notif);
        mysqli_stmt_execute($stmt_notif);
    }
    kembali_dengan_pesan('success', 'Booking berhasil ditolak.');
} else {
    kembali_dengan_pesan('error', 'Booking tidak ditemukan atau sudah diproses.');
}