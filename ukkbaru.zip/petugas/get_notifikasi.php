<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$host = "localhost";
$user = "root";
$pass = "";
$db   = "perpusku";
$koneksi = new mysqli($host, $user, $pass, $db);

if ($koneksi->connect_error) {
    die(json_encode(["status" => "error", "message" => "Koneksi database gagal: " . $koneksi->connect_error]));
}

$koneksi->set_charset("utf8mb4");

// Pastikan tabel notifikasi ada
$cek_tabel = $koneksi->query("SHOW TABLES LIKE 'notifikasi'");
if (mysqli_num_rows($cek_tabel) == 0) {
    $koneksi->query("CREATE TABLE notifikasi (
        id_notif INT AUTO_INCREMENT PRIMARY KEY,
        judul VARCHAR(255) NOT NULL,
        pesan TEXT,
        tipe VARCHAR(50) DEFAULT 'umum',
        status VARCHAR(50) DEFAULT 'belum_dibaca',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

// Ambil parameter
$last_id = isset($_GET['last_id']) ? intval($_GET['last_id']) : 0;
$action  = $_GET['action'] ?? 'check';

// ACTION: check - Cek notifikasi baru
if ($action === 'check') {
    $sql_check = "SELECT MAX(id_notif) as max_id FROM notifikasi";
    $result_check = $koneksi->query($sql_check);
    $row_check = $result_check->fetch_assoc();
    $current_max_id = intval($row_check['max_id'] ?? 0);

    $ada_baru = ($current_max_id > $last_id);

    // Hitung notifikasi belum dibaca
    $q_belum = $koneksi->query("SELECT COUNT(*) as jml FROM notifikasi WHERE status = 'belum_dibaca'");
    $belum_dibaca = intval($q_belum->fetch_assoc()['jml'] ?? 0);

    // Ambil 10 notifikasi terbaru
    $sql = "SELECT * FROM notifikasi ORDER BY created_at DESC LIMIT 10";
    $result = $koneksi->query($sql);
    $notifikasi = [];
    while ($row = $result->fetch_assoc()) {
        $notifikasi[] = $row;
    }

    echo json_encode([
        "status" => "success",
        "ada_baru" => $ada_baru,
        "max_id" => $current_max_id,
        "belum_dibaca" => $belum_dibaca,
        "data" => $notifikasi
    ]);
}

// ACTION: mark_read - Tandai semua sudah dibaca
elseif ($action === 'mark_read') {
    $koneksi->query("UPDATE notifikasi SET status = 'dibaca' WHERE status = 'belum_dibaca'");
    echo json_encode(["status" => "success", "message" => "Semua notifikasi ditandai sudah dibaca"]);
}

// ACTION: count - Hitung belum dibaca saja
elseif ($action === 'count') {
    $q = $koneksi->query("SELECT COUNT(*) as jml FROM notifikasi WHERE status = 'belum_dibaca'");
    $count = intval($q->fetch_assoc()['jml'] ?? 0);
    echo json_encode(["status" => "success", "count" => $count]);
}

// ACTION: delete - Hapus notifikasi
elseif ($action === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $koneksi->query("DELETE FROM notifikasi WHERE id_notif = $id");
    echo json_encode(["status" => "success", "message" => "Notifikasi dihapus"]);
}

else {
    echo json_encode(["status" => "error", "message" => "Action tidak valid"]);
}

$koneksi->close();
?>