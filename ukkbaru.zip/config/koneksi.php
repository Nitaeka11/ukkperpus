<?php
$host     = "localhost";
$user     = "root";
$pass     = "";
$database = "perpusku"; // ganti sesuai nama database kamu

$conn = mysqli_connect($host, $user, $pass, $database);
$koneksi = $conn; // backward compatibility

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>